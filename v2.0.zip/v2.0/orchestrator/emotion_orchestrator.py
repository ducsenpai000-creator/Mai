"""EmotionOrchestrator — glue Tầng 1→3 + tick loop 10Hz (Phase 7.5.C).

Spec EMOTION_SIMULATION Mục 5: mọi event → classifier → appraisal → modifier
→ saturate → MoodEngine. Background tick loop 10Hz đảm bảo mood decay/spring
chạy liên tục ngay cả khi không có event.

Buffer per-tick: nếu nhiều event fire trong cùng 1 tick window (spam, donation
mass) → combine targets and saturate once to avoid overshoot.

Cờ tone (force_gentle_tone/force_deflect) lưu ở `_active_flags` sau khi event
có flag; Prompt/Filter (7.5.D) đọc → gọi `clear_tone_flags()` sau khi xử.
"""
from __future__ import annotations

import asyncio
import uuid
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from interfaces.animation import MoodState
from interfaces.affect import AffectComposer, TurnAffect
from orchestrator.logger import get_logger
from orchestrator.mood_engine import MoodEngine
from services.emotion.appraisal import AppraisalTable
from services.emotion.classifier import (
    EmotionCause,
    EmotionEvent,
    EventClassifier,
    EventKind,
    sanitize_alias,
)
from services.emotion.modifiers import ModifierEngine
from services.emotion.affect_style import AffectStyleRenderer
from services.emotion.affect_v2 import AffectV2
from services.emotion.hybrid_affect import HybridAffectComposer
from services.emotion.mood_style import MoodStyleTable
from interfaces.state import (
    AgentEventKind,
    AgentEventSource,
    EventProvenance,
    GroundedEvent,
)


@dataclass
class ProcessedEvent:
    """Kết quả xử lý 1 event — trả cho caller để log/debug."""
    category: str
    targets: dict[str, float]
    tone_flag: str | None
    cause: EmotionCause | None = None


class EmotionOrchestrator:
    def __init__(
        self,
        classifier: EventClassifier,
        appraisal: AppraisalTable,
        modifiers: ModifierEngine,
        engine: MoodEngine,
        tick_hz: int = 10,
        agent_state: Any = None,
        affect_v2: AffectV2 | None = None,
        affect_renderer: AffectStyleRenderer | None = None,
        affect_composer: AffectComposer | None = None,
        affect_shadow_enabled: bool = False,
        affect_prompt_enabled: bool = False,
    ) -> None:
        self._classifier = classifier
        self._appraisal = appraisal
        self._modifiers = modifiers
        self._engine = engine
        self._tick_hz = int(tick_hz)
        self._dt = 1.0 / self._tick_hz
        self._agent_state = agent_state
        self._affect_v2 = affect_v2
        self._affect_renderer = affect_renderer
        self._affect_composer = affect_composer
        self._affect_shadow_enabled = bool(affect_shadow_enabled)
        self._affect_prompt_enabled = bool(affect_prompt_enabled)

        # Buffer per-dim: targets[dim] = list of float (nhiều event trong 1 tick)
        self._pending: dict[str, list[float]] = defaultdict(list)
        self._active_flags: set[str] = set()
        self._active_cause: EmotionCause | None = None   # A4
        self._last_category: str | None = None
        self._events_total = 0

        self._tick_task: asyncio.Task | None = None
        self._log = get_logger("emotion")

    @classmethod
    def from_loader(
        cls,
        loader,
        classifier: EventClassifier | None = None,
        appraisal: AppraisalTable | None = None,
        modifiers: ModifierEngine | None = None,
        engine: MoodEngine | None = None,
        memory: Any = None,
        filter_service: Any = None,
        agent_state: Any = None,
        metrics: Any = None,
    ) -> "EmotionOrchestrator":
        classifier = classifier or EventClassifier.from_loader(loader, filter_service=filter_service)
        appraisal = appraisal or AppraisalTable.from_loader(loader)
        modifiers = modifiers or ModifierEngine.from_loader(loader, memory=memory)
        engine = engine or MoodEngine.from_loader(loader)
        shadow_enabled = bool(loader.get(
            "features", "features.mood_v2_shadow.enabled", False,
        ))
        prompt_enabled = bool(loader.get(
            "features", "features.mood_v2_prompt.enabled", False,
        ))
        affect_v2 = AffectV2.from_loader(
            loader, metrics=metrics, enabled=shadow_enabled,
        )
        mood_style = MoodStyleTable.from_loader(loader)
        return cls(
            classifier=classifier,
            appraisal=appraisal,
            modifiers=modifiers,
            engine=engine,
            tick_hz=engine.tick_hz,
            agent_state=agent_state,
            affect_v2=affect_v2,
            affect_renderer=AffectStyleRenderer.from_loader(loader),
            affect_composer=HybridAffectComposer.from_loader(
                loader, mood_style=mood_style,
            ),
            affect_shadow_enabled=shadow_enabled,
            affect_prompt_enabled=prompt_enabled,
        )

    # ---------- lifecycle ----------

    async def start(self) -> None:
        """Start background tick loop 10Hz. Idempotent."""
        if self._tick_task is not None and not self._tick_task.done():
            return
        if self._affect_v2 is not None:
            await self._affect_v2.start()
        self._tick_task = asyncio.create_task(self._tick_loop(), name="emotion_tick")
        self._log.info("emotion_orchestrator_ready", tick_hz=self._tick_hz)

    async def stop(self) -> None:
        if self._affect_v2 is not None:
            await self._affect_v2.stop()
        if self._tick_task is None:
            return
        self._tick_task.cancel()
        try:
            await self._tick_task
        except asyncio.CancelledError:
            pass
        self._tick_task = None

    async def _tick_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._dt)
                self.flush_and_tick(self._dt)
            except asyncio.CancelledError:
                break
            except Exception as e:  # pragma: no cover - defensive
                self._log.error("emotion_tick_failed", error=str(e))

    # ---------- API ----------

    async def handle_event(self, event: EmotionEvent) -> ProcessedEvent:
        """Full pipeline 1 event: classify → appraise → modifier → buffer.

        KHÔNG áp thẳng vào engine — chờ tick flush để saturate với event khác cùng tick.
        """
        self._events_total += 1
        category = self._classifier.classify(event)
        self._last_category = category

        base_targets = self._appraisal.target_for(category)
        viewer_id = event.meta.get("viewer_id") if event.meta else None
        final_targets = await self._modifiers.apply(category, base_targets, viewer_id)

        # Buffer per-dim (saturation ở flush)
        for dim, val in final_targets.items():
            self._pending[dim].append(float(val))

        # Tone flag (nếu có) — Prompt/Filter đọc sau
        flag = self._appraisal.tone_flag(category)
        if flag:
            self._active_flags.add(flag)

        # A4: cause (object của cảm xúc) — chỉ chat có alias người gây ra.
        cause = self._derive_cause(event, category)
        if cause is not None:
            self._active_cause = cause

        if self._affect_v2 is not None and self._affect_shadow_enabled:
            try:
                self._affect_v2.observe(
                    category,
                    targets=final_targets,
                    tone_flag=flag,
                    cause_ref=str((event.meta or {}).get("source_event_id") or "") or None,
                )
            except Exception as exc:
                self._log.warning("affect_v2_shadow_failed", error=str(exc))

        processed = ProcessedEvent(
            category=category, targets=final_targets, tone_flag=flag, cause=cause,
        )
        self._record_grounded_event(event, processed)
        return processed

    def _record_grounded_event(
        self, event: EmotionEvent, processed: ProcessedEvent,
    ) -> None:
        if self._agent_state is None:
            return
        source_id = str((event.meta or {}).get("source_event_id") or "") or None
        event_id = (
            f"agent:emotion:{source_id}:{processed.category}"
            if source_id else f"agent:emotion:{uuid.uuid4().hex}"
        )
        cause = processed.cause.as_phrase() if processed.cause is not None else None
        try:
            self._agent_state.record(GroundedEvent(
                event_id=event_id,
                kind=AgentEventKind.EMOTION_APPLIED,
                source=AgentEventSource.EMOTION,
                timestamp=event.timestamp or datetime.now(timezone.utc),
                confidence=1.0,
                payload={
                    "category": processed.category,
                    "targets": processed.targets,
                    "tone_flag": processed.tone_flag,
                    "cause": cause,
                },
                provenance=EventProvenance(
                    producer="emotion_orchestrator",
                    source_event_id=source_id,
                    platform=str((event.meta or {}).get("platform") or "") or None,
                ),
            ))
        except Exception as exc:
            self._log.warning("emotion_agent_event_failed", error=str(exc))

    def _derive_cause(self, event: EmotionEvent, category: str) -> EmotionCause | None:
        """A4: dựng cause SANITIZE từ event + category. None nếu category không đáng
        gắn (neutral/question/timer) — không bịa lý do."""
        intent = self._appraisal.cause_intent(category)
        if not intent:
            return None
        meta = event.meta or {}
        if event.kind == EventKind.CHAT:
            alias = sanitize_alias(meta.get("author") or meta.get("viewer_name"))
        elif event.kind == EventKind.SYSTEM and "operator" in category:
            alias = "ông"
        else:
            alias = sanitize_alias(meta.get("author") or meta.get("viewer_name"))
        return EmotionCause(viewer_alias=alias, intent_short=intent)

    def flush_and_tick(self, dt: float | None = None) -> MoodState:
        """Flush buffer → saturate → apply_appraisal → tick 1 lần.

        Public để test call trực tiếp bypass loop. Nếu buffer rỗng → chỉ tick (decay).
        """
        if self._pending:
            saturated = self._engine.saturate(dict(self._pending))
            self._engine.apply_appraisal(saturated)
            self._pending.clear()
        return self._engine.tick(dt or self._dt)

    def apply_llm_hint(self, mood_state: MoodState) -> None:
        """A1 (docs/MAI_V2_SYSTEM_SPEC.md): Kênh B ĐÃ BỎ — no-op.

        Giữ signature để backward compat với caller cũ. LLM không còn tự report
        mood (persona đã xoá mood block instruction). Mood engine giờ chỉ đi 1
        chiều: appraisal event → engine → prompt.
        """
        return

    def current_mood(self) -> MoodState:
        """Snapshot mood hiện tại (không tick). Prompt/Animation gọi."""
        return self._engine.current_state()

    def active_tone_flags(self) -> set[str]:
        """Cờ tone hiện đang active (sinh từ event gần đây, chưa clear)."""
        return set(self._active_flags)

    def active_cause(self) -> EmotionCause | None:
        """A4: cause hiện tại (object cảm xúc) — Prompt đọc, clear cùng tone flags."""
        return self._active_cause

    def current_turn_affect(self) -> TurnAffect | None:
        if self._affect_v2 is None or not self._affect_shadow_enabled:
            return None
        return self._affect_v2.current_turn_affect()

    def delivery_directive(self) -> str | None:
        """Return one hybrid prompt directive only after explicit consumer cutover."""
        if (
            not self._affect_prompt_enabled
            or self._affect_v2 is None
            or self._affect_renderer is None
        ):
            return None
        affect = self._affect_v2.current_turn_affect()
        if self._affect_composer is not None:
            plan = self._affect_composer.compose(
                self._last_category or "default",
                affect,
                self.current_mood(),
                self.active_tone_flags(),
            )
            return self._affect_renderer.directive_for_plan(
                plan, self._affect_v2.current_session_mood(),
            )
        return self._affect_renderer.directive_for(
            affect, self._affect_v2.current_session_mood(),
        )

    @property
    def affect_shadow_enabled(self) -> bool:
        return self._affect_shadow_enabled

    @property
    def affect_prompt_enabled(self) -> bool:
        return self._affect_prompt_enabled

    def set_affect_shadow_enabled(self, enabled: bool) -> None:
        self._affect_shadow_enabled = bool(enabled)
        if self._affect_v2 is not None:
            self._affect_v2.set_enabled(enabled)
        if not enabled:
            self._affect_prompt_enabled = False

    def set_affect_prompt_enabled(self, enabled: bool) -> None:
        self._affect_prompt_enabled = bool(enabled) and self._affect_shadow_enabled

    def clear_tone_flags(self) -> None:
        """Prompt/Filter gọi sau khi đã đọc & xử cờ (1 lần dùng cho 1 turn).
        A4: clear luôn cause (cùng vòng đời per-turn)."""
        self._active_flags.clear()
        self._active_cause = None
        if self._affect_v2 is not None:
            self._affect_v2.advance_turn()

    def reset_session(self) -> None:
        """Session mới: reset modifier counters (không reset mood engine)."""
        self._modifiers.reset_session()
        if self._affect_v2 is not None:
            self._affect_v2.reset_session()

    def set_memory_service(self, memory: Any = None) -> None:
        self._modifiers.set_memory_service(memory)

    # ---------- introspection ----------

    def get_metrics(self) -> dict[str, Any]:
        return {
            "emotion_events_total": self._events_total,
            "emotion_pending_dims": len(self._pending),
            "emotion_active_flags": len(self._active_flags),
            "emotion_last_category": self._last_category,
            **self._engine.get_metrics(),
            **self._modifiers.get_metrics(),
            **(self._affect_v2.get_metrics() if self._affect_v2 is not None else {}),
            **(self._affect_composer.get_metrics() if self._affect_composer is not None else {}),
        }

    def snapshot(self) -> dict[str, Any]:
        """Dashboard/debug — trạng thái đầy đủ."""
        return {
            "mood_pos": self._engine.snapshot()["pos"],
            "mood_target": self._engine.snapshot()["target"],
            "current_mood": self.current_mood().model_dump(),
            "active_flags": sorted(self._active_flags),
            "last_category": self._last_category,
            "pending_events": {d: list(v) for d, v in self._pending.items()},
            "affect_v2": (
                {
                    **self._affect_v2.snapshot(),
                    "shadow_enabled": self._affect_shadow_enabled,
                    "prompt_enabled": self._affect_prompt_enabled,
                    "delivery_directive": self.delivery_directive(),
                    "hybrid": (
                        self._affect_composer.snapshot()
                        if self._affect_composer is not None
                        and hasattr(self._affect_composer, "snapshot") else None
                    ),
                }
                if self._affect_v2 is not None else None
            ),
        }
