"""Declarative capability availability services."""
