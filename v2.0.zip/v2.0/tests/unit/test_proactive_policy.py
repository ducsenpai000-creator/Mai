from __future__ import annotations

from datetime import datetime, timedelta, timezone

from services.operations.metrics import MetricsCollector
from interfaces.state import Goal, GoalKind, GoalSnapshot, GoalSource, GoalStatus
from interfaces.state import (
    AgentStateSnapshot, OpenThread, ThreadEvidence, ThreadKind, ThreadStatus,
)
from services.director.action_types import DirectorInput
from services.director.director import DirectorAction
from services.director.proactive_policy import (
    ProactiveHostingPolicy, ProactivePolicyConfig, ProactiveSource,
)

NOW = datetime(2026, 8, 8, 12, 0, tzinfo=timezone.utc)


def _policy(metrics=None) -> ProactiveHostingPolicy:
    return ProactiveHostingPolicy(ProactivePolicyConfig(
        90, "follow_up_topic", "environment_reaction", "complain_silence", 220,
    ), metrics=metrics)


def _input(state: AgentStateSnapshot, goals: GoalSnapshot = GoalSnapshot()) -> DirectorInput:
    return DirectorInput(now=100.0, agent_state=state, goals=goals)


def test_open_thread_wins_environment_and_silence_with_evidence() -> None:
    thread = OpenThread(
        "thread-1", "story", "unfinished grounded story", NOW, NOW,
        NOW + timedelta(minutes=5), kind=ThreadKind.STORY,
        evidence=(ThreadEvidence("event-story", "story excerpt", "rule"),),
    )
    state = AgentStateSnapshot(
        open_threads=(thread,),
        environment_summary={
            "salient": True, "source_event_id": "env-1", "summary": "scene changed",
        },
    )
    choice = _policy().choose(
        _input(state), allowed_actions={"follow_up", "self_talk"}, silence_ready=True,
    )
    assert choice and choice.source is ProactiveSource.OPEN_THREAD
    assert choice.action is DirectorAction.FOLLOW_UP
    assert choice.evidence_ids == ("event-story",)


def test_salient_grounded_environment_wins_silence() -> None:
    state = AgentStateSnapshot(environment_summary={
        "salient": True, "source_event_id": "env-1", "summary": "OBS switched scene",
    })
    choice = _policy().choose(
        _input(state), allowed_actions={"self_talk"}, silence_ready=True,
    )
    assert choice and choice.source is ProactiveSource.ENVIRONMENT
    assert choice.evidence_ids == ("env-1",)


def test_untrusted_environment_is_skipped_and_silence_is_last_fallback() -> None:
    state = AgentStateSnapshot(environment_summary={"salient": True, "summary": "no source"})
    choice = _policy().choose(
        _input(state), allowed_actions={"self_talk"}, silence_ready=True,
    )
    assert choice and choice.source is ProactiveSource.SILENCE


def test_active_goal_blocks_proactive_candidate() -> None:
    goal = Goal(
        "g1", GoalKind.OPERATOR_PINNED, GoalStatus.ACTIVE, 90, "operator task",
        GoalSource.OPERATOR, NOW, NOW + timedelta(minutes=5), ("complete",),
    )
    assert _policy().choose(
        _input(AgentStateSnapshot(), GoalSnapshot(active=goal)),
        allowed_actions={"self_talk"}, silence_ready=True,
    ) is None


def test_source_cooldown_and_metrics_prevent_immediate_replay() -> None:
    metrics = MetricsCollector()
    policy = _policy(metrics)
    thread = OpenThread(
        "thread-1", "story", "unfinished", NOW, NOW, NOW + timedelta(minutes=5),
    )
    value = _input(AgentStateSnapshot(open_threads=(thread,)))
    first = policy.choose(value, allowed_actions={"follow_up"}, silence_ready=False)
    assert first is not None
    policy.mark_used(first, 100.0)
    blocked = policy.choose(value, allowed_actions={"follow_up"}, silence_ready=False)
    assert blocked is not None and blocked.action is DirectorAction.WAIT
    assert metrics.proactive_candidate_snapshot()["open_thread:selected"] == 1


def test_open_thread_choice_uses_active_latest_thread_with_stable_tie_break() -> None:
    parked = OpenThread(
        "thread-z", "parked", "parked", NOW, NOW + timedelta(seconds=2),
        NOW + timedelta(minutes=5), status=ThreadStatus.PARKED,
    )
    first = OpenThread(
        "thread-a", "first", "first", NOW, NOW + timedelta(seconds=1),
        NOW + timedelta(minutes=5),
    )
    tied = OpenThread(
        "thread-b", "tied", "tied", NOW, NOW + timedelta(seconds=1),
        NOW + timedelta(minutes=5),
    )
    choice = _policy().choose_open_thread(
        _input(AgentStateSnapshot(open_threads=(parked, first, tied))),
        allowed_actions={"follow_up", "self_talk"},
    )

    assert choice is not None
    assert choice.action is DirectorAction.FOLLOW_UP
    assert choice.source_id == "thread-b"


def test_open_thread_choice_respects_goal_segment_and_delivery_cooldown() -> None:
    policy = _policy()
    thread = OpenThread(
        "thread-1", "story", "unfinished", NOW, NOW, NOW + timedelta(minutes=5),
    )
    state = AgentStateSnapshot(open_threads=(thread,))
    fallback = policy.choose_open_thread(
        _input(state), allowed_actions={"self_talk"},
    )
    assert fallback is not None and fallback.action is DirectorAction.SELF_TALK
    assert policy.choose_open_thread(_input(state), allowed_actions=set()) is None

    policy.mark_source_used("open_thread", "thread-1", 100.0)
    blocked = policy.choose_open_thread(
        _input(state), allowed_actions={"follow_up"},
    )
    assert blocked is not None and blocked.action is DirectorAction.WAIT
    assert policy.get_metrics()["proactive_candidate_outcomes"] == {
        "open_thread:cooldown": 1,
        "open_thread:selected": 1,
    }

    goal = Goal(
        "g1", GoalKind.OPERATOR_PINNED, GoalStatus.ACTIVE, 90, "operator task",
        GoalSource.OPERATOR, NOW, NOW + timedelta(minutes=5), ("complete",),
    )
    assert policy.choose_open_thread(
        _input(state, GoalSnapshot(active=goal)), allowed_actions={"follow_up"},
    ) is None


def test_silence_fallback_has_global_cooldown() -> None:
    policy = _policy()
    first_input = _input(AgentStateSnapshot())
    first = policy.choose(
        first_input, allowed_actions={"self_talk"}, silence_ready=True,
    )
    assert first is not None and first.source is ProactiveSource.SILENCE
    policy.mark_used(first, first_input.now)

    blocked = policy.choose(
        DirectorInput(now=120.0, agent_state=AgentStateSnapshot(), goals=GoalSnapshot()),
        allowed_actions={"self_talk"}, silence_ready=True,
    )
    assert blocked is not None and blocked.action is DirectorAction.WAIT
    assert blocked.reason == "silence_cooldown"

    ready = policy.choose(
        DirectorInput(now=145.0, agent_state=AgentStateSnapshot(), goals=GoalSnapshot()),
        allowed_actions={"self_talk"}, silence_ready=True,
    )
    assert ready is not None and ready.action is DirectorAction.SELF_TALK
