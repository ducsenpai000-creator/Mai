from __future__ import annotations

from datetime import datetime, timedelta, timezone
from dataclasses import replace
import pytest

from services.agent.thread_detector import RuleThreadDetector
from interfaces.state import (
    AgentEventKind, AgentEventSource, EventProvenance, GroundedEvent, OpenThread,
    ThreadKind, ThreadOperation,
)

NOW = datetime(2026, 8, 8, 12, 0, tzinfo=timezone.utc)


def _event(event_id: str, kind: AgentEventKind, text: str) -> GroundedEvent:
    return GroundedEvent(
        event_id, kind, AgentEventSource.CHAT, NOW, 1.0, {"text": text},
        EventProvenance("test", source_event_id=event_id),
    )


def _thread(kind: ThreadKind = ThreadKind.STORY) -> OpenThread:
    return OpenThread(
        "thread-1", "chuyện cà phê", "tớ đang kể chuyện cà phê",
        NOW, NOW, NOW + timedelta(minutes=5), kind=kind,
    )


def test_detects_question_promise_and_story_with_readable_evidence() -> None:
    detector = RuleThreadDetector()
    cases = (
        (_event("q", AgentEventKind.CHAT_RECEIVED, "Mai thích món nào?"), ThreadKind.QUESTION),
        (_event("p", AgentEventKind.SPEECH_FINAL, "Lát nữa tớ sẽ kể kết quả."), ThreadKind.PROMISE),
        (_event("s", AgentEventKind.SPEECH_FINAL, "Để tớ kể chuyện này."), ThreadKind.STORY),
    )
    for event, expected in cases:
        signal = detector.detect(event, ())[0]
        assert signal.operation is ThreadOperation.CREATE
        assert signal.kind is expected
        assert signal.evidence.source_event_id == event.event_id
        assert signal.evidence.excerpt == event.payload["text"]


def test_follow_up_updates_and_explicit_completion_resolves_existing_thread() -> None:
    detector = RuleThreadDetector()
    update = detector.detect(
        _event("u", AgentEventKind.CHAT_RECEIVED, "Kể tiếp đi"), (_thread(),),
    )[0]
    assert update.operation is ThreadOperation.UPDATE
    assert update.target_thread_id == "thread-1"
    resolved = detector.detect(
        _event("r", AgentEventKind.SPEECH_FINAL, "Tớ kể xong chuyện này rồi."),
        (_thread(),),
    )[0]
    assert resolved.operation is ThreadOperation.RESOLVE
    assert resolved.reason == "explicit_completion"


def test_non_conversational_event_or_plain_statement_produces_no_signal() -> None:
    detector = RuleThreadDetector()
    assert detector.detect(
        _event("plain", AgentEventKind.CHAT_RECEIVED, "xin chào"), (),
    ) == ()
    assert detector.detect(
        _event("env", AgentEventKind.ENVIRONMENT_OBSERVED, "ignored"), (),
    ) == ()


def test_temporal_nay_does_not_hijack_unrelated_active_thread() -> None:
    detector = RuleThreadDetector()

    signals = detector.detect(
        _event("other", AgentEventKind.CHAT_RECEIVED, "nãy cao nhất thấy 6 mà"),
        (_thread(),),
    )

    assert signals == ()


def test_delivered_answer_closes_exact_question_lineage_without_lexical_match() -> None:
    thread = replace(_thread(ThreadKind.QUESTION), topic="28 cộng 15?", summary="28 cộng 15?",
                     origin_event_id="agent:chat:sum")
    event = replace(_event("delivered", AgentEventKind.SPEECH_COMPLETED, "Kết quả là 43."),
                    payload={"text": "Kết quả là 43.", "action": "read_chat", "output_ok": True,
                             "ref_event_ids": ["sum"], "expects_chat_answer": False, "direct_reply": True})
    signal = RuleThreadDetector().detect(event, (thread,))[0]
    assert signal.operation is ThreadOperation.RESOLVE
    assert signal.target_thread_id == thread.thread_id
    assert signal.reason == "delivered_answer"


@pytest.mark.parametrize("changes", [
    {"output_ok": False}, {"ref_event_ids": ["unrelated"]},
    {"direct_reply": False},
    {"ref_event_ids": None}, {"ref_event_ids": [1]},
    {"thread_id": "thread-1", "ref_event_ids": ["unrelated"]},
    {"expects_chat_answer": True}, {"text": "Cậu muốn hỏi thêm gì?"},
])
def test_question_is_not_closed_without_valid_answer_evidence(changes) -> None:
    thread = replace(_thread(ThreadKind.QUESTION), origin_event_id="agent:chat:sum")
    payload = {"text": "Kết quả là 43.", "action": "read_chat", "output_ok": True,
               "ref_event_ids": ["sum"], "expects_chat_answer": False, "direct_reply": True, **changes}
    event = replace(_event("delivered", AgentEventKind.SPEECH_COMPLETED, payload["text"]), payload=payload)
    signals = RuleThreadDetector().detect(event, (thread,))
    assert all(signal.operation is not ThreadOperation.RESOLVE for signal in signals)
