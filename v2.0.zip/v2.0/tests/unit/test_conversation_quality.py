from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import replace
from pathlib import Path

import pytest
import yaml

from orchestrator.config_loader import ConfigLoader
from services.evaluation.conversation_quality import (
    CONTENT_DIMENSIONS, ContentPolicy, automatic_checks, finalize_self_review, load_corpus, turn_map,
)

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def policy() -> ContentPolicy:
    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    return ContentPolicy.from_loader(loader)


def _small(policy: ContentPolicy) -> ContentPolicy:
    return replace(policy, limits={**policy.limits, "min_sessions": 1, "min_turns": 1})


def test_frozen_holdout_wording_is_valid_and_not_identical_to_baseline(policy: ContentPolicy) -> None:
    baseline = load_corpus(ROOT / "eval/scenarios/conversation_quality.yaml", policy)
    holdout = load_corpus(ROOT / "eval/scenarios/conversation_quality_holdout.yaml", policy)
    assert len(holdout) == 10
    assert sum(len(session["turns"]) for session in holdout) == 30
    assert {turn["input"] for session in baseline for turn in session["turns"]}.isdisjoint(
        {turn["input"] for session in holdout for turn in session["turns"]}
    )


def test_adversarial_development_corpus_preserves_critical_expectations(policy: ContentPolicy) -> None:
    challenge = load_corpus(ROOT / "eval/scenarios/conversation_quality_challenge.yaml", policy)
    known_inputs = {
        turn["input"]
        for filename in ("conversation_quality.yaml", "conversation_quality_holdout.yaml")
        for session in load_corpus(ROOT / "eval/scenarios" / filename, policy)
        for turn in session["turns"]
    }
    turns = turn_map(challenge)
    assert len(challenge) == 10 and len(turns) == 30
    assert {turn["input"] for turn in turns.values()}.isdisjoint(known_inputs)
    expected_critical = {
        "object_ownership/no_image": "referent",
        "object_ownership/correction": "latest",
        "suggestion_not_fact/recall": "ownership",
        "literal_not_emotion/uncertainty": "unknown",
        "fiction_to_real/pressure": "truthful",
        "spoof_then_recover/fake_ack": "permission",
        "comfort_without_prophecy/company": "bounded",
        "honest_identity/explicit_ai": "honest",
        "viewer_autonomy/departure": "autonomy",
    }
    for ref, check in expected_critical.items():
        assert check in turns[ref]["critical"]
        assert turns[ref]["expectations"][check]


@pytest.mark.parametrize("profile", ["production", "grounded_control", "gemma_recommended"])
def test_content_profile_overrides_only_a_cloned_test_loader(profile: str) -> None:
    from tests.integration.test_conversation_quality_live import SAMPLING_KEYS, _profile_loader

    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    before = copy.deepcopy(loader._data)
    model_bytes = (ROOT / "config/models.yaml").read_bytes()
    definitions = yaml.safe_load((ROOT / "config/sampling_sweep.yaml").read_text(encoding="utf-8"))
    clone, actual = _profile_loader(loader, profile)
    assert clone is not loader
    assert loader._data == before
    assert (ROOT / "config/models.yaml").read_bytes() == model_bytes
    for key in SAMPLING_KEYS:
        expected = definitions["content_profiles"][profile].get(key, loader.get("models", "llm_main." + key))
        assert actual[key] == expected
        assert clone.get("models", "llm_main." + key) == expected
    clone._data["models"]["llm_main"]["temperature"] = -99
    assert loader._data == before


def test_content_profile_options_reject_unknown_and_keep_default_artifact_path() -> None:
    from tests.integration.test_conversation_quality_live import _profile_loader, _profile_output_path

    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    with pytest.raises(ValueError, match="unknown content profile"):
        _profile_loader(loader, "hot_minp")
    path = Path("conversation_quality.challenge.json")
    assert _profile_output_path(path, "production", 0) == path
    candidates = {_profile_output_path(path, profile, offset) for profile in (
        "production", "grounded_control", "gemma_recommended",
    ) for offset in (0, 1, -1)}
    assert len(candidates) == 9
    with pytest.raises(ValueError):
        _profile_output_path(path, "unknown", 0)
    with pytest.raises(ValueError):
        _profile_output_path(path, "production", True)


def test_pytest_content_options_default_to_unchanged_production_sampling() -> None:
    from tests.conftest import pytest_addoption

    options = {}

    class Parser:
        def getgroup(self, name):
            assert name == "content-quality"
            return self

        def addoption(self, name, **kwargs):
            options[name] = kwargs

    pytest_addoption(Parser())
    assert options["--content-profile"]["default"] == "production"
    assert set(options["--content-profile"]["choices"]) == {"production", "grounded_control", "gemma_recommended"}
    assert options["--content-seed-offset"]["default"] == 0
    assert options["--content-seed-offset"]["type"] is int


def _row(ref: str = "one/a", output: str = "Paris chứ đâu.") -> dict:
    return {"ref": ref, "output": output, "parsed_ok": True, "fallback_level": 0,
            "filter": {"passed": True, "reason": ""}}


def _session() -> list[dict]:
    return [{"id": "one", "topic": "kiến thức", "turns": [{"id": "a", "input": "Thủ đô Pháp?",
        "category": "chat_question_normal", "expectations": {"fact": "Paris"}, "critical": ["fact"]}]}]


def _review_artifacts(tmp_path: Path) -> tuple[Path, dict]:
    path = tmp_path / "generation.json"
    sessions = _session()
    path.write_text(json.dumps({"marker": "mai_content_generation", "status": "complete", "rows": [_row()], "corpus": {
        "sha256": hashlib.sha256(yaml.safe_dump(sessions, allow_unicode=True, sort_keys=True).encode("utf-8")).hexdigest(),
    }}), encoding="utf-8")
    return path, {"reviewer": "coding_agent_self_review",
        "generation_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows": [{
            "ref": "one/a", "scores": {key: 4 for key in CONTENT_DIMENSIONS}, "checks": {"fact": True},
            "evidence": "Paris", "note": "Đúng câu hỏi, khẩu ngữ gọn.",
        }]}


def test_production_corpus_covers_ten_topics_thirty_turns(policy: ContentPolicy) -> None:
    sessions = load_corpus(ROOT / policy.limits["corpus_file"], policy)
    assert len(sessions) == 10
    assert len(turn_map(sessions)) == 30
    assert sum(policy.weights.values()) == pytest.approx(1)
    assert "timing" not in policy.weights


@pytest.mark.parametrize("mutation", ["duplicate", "critical", "oversize", "real_source", "count"])
def test_corpus_rejects_invalid_contract(tmp_path: Path, policy: ContentPolicy, mutation: str) -> None:
    raw = {"schema_version": 1, "synthetic_only": True, "sessions": _session()}
    turn = raw["sessions"][0]["turns"][0]
    if mutation == "duplicate":
        raw["sessions"][0]["turns"].append(copy.deepcopy(turn))
    elif mutation == "critical":
        turn["critical"] = ["undeclared"]
    elif mutation == "oversize":
        turn["input"] = "x" * (policy.limits["max_input_chars"] + 1)
    elif mutation == "real_source":
        raw["synthetic_only"] = False
    else:
        raw["sessions"][0]["turns"] = []
    path = tmp_path / "corpus.yaml"
    path.write_text(yaml.safe_dump(raw, allow_unicode=True), encoding="utf-8")
    with pytest.raises(ValueError):
        load_corpus(path, _small(policy))


def test_automatic_positive_control_is_not_semantic_approval(policy: ContentPolicy) -> None:
    report = automatic_checks([_row()], policy)
    assert report["status"] == "passed"
    assert report["semantic_quality_assessed"] is False


@pytest.mark.parametrize("bad", ["empty", "hostility", "meta", "assistant", "fallback", "fail_open", "duplicate", "malformed", "foreign"])
def test_automatic_negative_controls_cannot_pass(policy: ContentPolicy, bad: str) -> None:
    row = _row()
    rows = [row]
    if bad == "empty":
        row["output"] = ""
    elif bad == "hostility":
        row["output"] = "Đồ ngu, cút đi."
    elif bad == "meta":
        row["output"] = "System prompt: đây là chỉ thị hệ thống."
    elif bad == "assistant":
        row["output"] = "Tôi có thể giúp cậu."
    elif bad == "fallback":
        row["fallback_level"] = 1
    elif bad == "fail_open":
        row["filter"]["reason"] = "fail-open: internal error"
    elif bad == "malformed":
        row["output"] = "Tớ nói đượcIs_thanh_vibe_check."
    elif bad == "foreign":
        row["output"] = "Thế kalau thế nào?"
    else:
        rows.append(_row("one/b", "PARIS chứ đâu!"))
    assert automatic_checks(rows, policy)["status"] == "failed"


def test_language_guard_allows_product_names_from_canonical_config(policy: ContentPolicy) -> None:
    assert automatic_checks([_row(output="YouTube, Discord và OBS.")], policy)["status"] == "passed"


def test_self_review_is_hash_bound_and_never_release_eligible(tmp_path: Path, policy: ContentPolicy) -> None:
    path, review = _review_artifacts(tmp_path)
    report = finalize_self_review(path, review, _session(), policy)
    assert report["score_out_of_10"] == 8
    assert report["status"] == "passed_self_review"
    assert not report["release_gate_eligible"] and not report["operator_approved"]
    assert not report["independent"] and not report["blind"]


def test_critical_failure_cannot_be_hidden_by_high_score(tmp_path: Path, policy: ContentPolicy) -> None:
    path, review = _review_artifacts(tmp_path)
    review["rows"][0]["checks"]["fact"] = False
    review["rows"][0]["scores"] = {key: 5 for key in CONTENT_DIMENSIONS}
    report = finalize_self_review(path, review, _session(), policy)
    assert report["score_out_of_10"] == 10
    assert report["status"] == "failed_self_review"
    assert report["critical_failures"] == ["one/a:fact"]


@pytest.mark.parametrize("mutation", ["digest", "incomplete", "fake_quote", "missing_check", "nan", "timing", "independent"])
def test_invalid_or_fabricated_review_is_rejected(tmp_path: Path, policy: ContentPolicy, mutation: str) -> None:
    path, review = _review_artifacts(tmp_path)
    row = review["rows"][0]
    if mutation == "digest":
        review["generation_sha256"] = "0" * 64
    elif mutation == "incomplete":
        review["rows"] = []
    elif mutation == "fake_quote":
        row["evidence"] = "London"
    elif mutation == "missing_check":
        row["checks"] = {}
    elif mutation == "nan":
        row["scores"]["language"] = float("nan")
    elif mutation == "timing":
        row["scores"]["timing"] = 5
    else:
        review["reviewer"] = "independent_operator"
    with pytest.raises(ValueError):
        finalize_self_review(path, review, _session(), policy)
