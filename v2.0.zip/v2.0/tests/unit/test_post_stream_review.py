from __future__ import annotations

import json
from pathlib import Path

import pytest

from services.operations.post_stream_review import PostStreamReviewer, ReviewConfig
from services.data.sanitize import metadata_reference


def _config(tmp_path: Path) -> ReviewConfig:
    return ReviewConfig(
        shutdown_snapshot=tmp_path / "shutdown.json",
        incident_log=tmp_path / "incidents.jsonl",
        operator_audit=tmp_path / "audit.jsonl",
        soak_report=tmp_path / "soak.json",
        export_dir=tmp_path / "reviews",
    )


@pytest.mark.asyncio
async def test_review_ready_exports_metadata_only_checklist(tmp_path: Path) -> None:
    config = _config(tmp_path)
    config.shutdown_snapshot.write_text(json.dumps({
        "schema_version": 1, "shutdown_errors_before_snapshot": [],
    }), encoding="utf-8")
    config.incident_log.write_text("", encoding="utf-8")
    config.operator_audit.write_text(json.dumps({"action": "pause"}) + "\n", encoding="utf-8")
    config.soak_report.write_text(json.dumps({
        "passed": True, "configured_duration_s": 7200,
    }), encoding="utf-8")

    report = await PostStreamReviewer(config).review(tmp_path / "review.json")

    assert report["ready"] is True
    exported = json.loads((tmp_path / "review.json").read_text(encoding="utf-8"))
    assert exported["privacy"] == "metadata_only_no_chat_or_prompt_content"
    assert "records" not in json.dumps(exported)


@pytest.mark.asyncio
async def test_review_flags_unresolved_incident_and_missing_soak(tmp_path: Path) -> None:
    config = _config(tmp_path)
    config.shutdown_snapshot.write_text(json.dumps({
        "schema_version": 1, "shutdown_errors_before_snapshot": [],
    }), encoding="utf-8")
    config.incident_log.write_text(json.dumps({
        "incident_id": "inc:1", "status": "open",
    }) + "\n", encoding="utf-8")

    report = await PostStreamReviewer(config).review(tmp_path / "review.json")

    assert report["ready"] is False
    assert report["checklist"]["incident_log"]["unresolved_count"] == 1
    assert report["checklist"]["soak_acceptance"]["error"] == "missing"


async def test_review_joins_legacy_incident_with_new_resolution_without_rewriting(tmp_path: Path) -> None:
    config = _config(tmp_path)
    events = [
        {"incident_id": "inc:legacy", "status": "open", "summary": "SYNTHETIC_OLD_TEXT"},
        {"incident_id": metadata_reference("inc:legacy"), "status": "resolved"},
    ]
    original = "".join(json.dumps(row) + "\n" for row in events)
    config.incident_log.write_text(original, encoding="utf-8")
    report = await PostStreamReviewer(config).review(tmp_path / "review.json")
    assert report["checklist"]["incident_log"]["unresolved_count"] == 0
    assert config.incident_log.read_text(encoding="utf-8") == original
    assert "SYNTHETIC_OLD_TEXT" not in json.dumps(report)


async def test_review_cli_loads_configured_salt_for_mixed_legacy_references(tmp_path: Path, monkeypatch) -> None:
    import scripts.post_stream_review as cli
    from services.data.sanitize import configure_hash_salt

    salt = tmp_path / "private-salt.bin"
    configure_hash_salt(salt)
    resolved = metadata_reference("inc:legacy-cli")
    config = _config(tmp_path)
    config.incident_log.write_text("".join(json.dumps(row) + "\n" for row in (
        {"incident_id": "inc:legacy-cli", "status": "open"},
        {"incident_id": resolved, "status": "resolved"},
    )), encoding="utf-8")
    class Loader:
        def __init__(self, path: Path) -> None:
            pass

        def load_all(self) -> None:
            pass

        def get(self, name: str, key: str, default: object = None) -> object:
            return {
                ("data_privacy", "privacy.viewer_hash_salt_file"): salt,
                ("operations", "incident_log.file"): config.incident_log,
                ("operations", "shutdown.snapshot_file"): config.shutdown_snapshot,
                ("operations", "dashboard_standalone.operator_audit_file"): config.operator_audit,
                ("evaluation", "evaluation.operations.soak.report_file"): config.soak_report,
            }.get((name, key), default)

    monkeypatch.setattr(cli, "ConfigLoader", Loader)
    configure_hash_salt(tmp_path / "unrelated-process-salt.bin")
    output = tmp_path / "cli-review.json"
    await cli.run(["--output", str(output)])
    assert json.loads(output.read_text(encoding="utf-8"))["checklist"]["incident_log"]["unresolved_count"] == 0
