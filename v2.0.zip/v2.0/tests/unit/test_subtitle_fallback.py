"""Test SubtitleFallbackService (Phase 4, 4.C)."""
from __future__ import annotations

import pytest
import asyncio
import socket
from pathlib import Path

import httpx

from interfaces.tts import TTSRequest
from services.tts.subtitle_fallback import SubtitleFallbackService


class TestBasics:
    async def test_yields_single_final_chunk_empty_audio(self) -> None:
        svc = SubtitleFallbackService(on_subtitle=lambda _rid, _text: None)
        chunks = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r1", text="chào"))]
        assert len(chunks) == 1
        assert chunks[0].is_final is True
        assert chunks[0].audio_bytes == b""
        assert chunks[0].duration_ms == 0

    async def test_invokes_subtitle_sink(self) -> None:
        seen = []
        svc = SubtitleFallbackService(on_subtitle=lambda rid, txt: seen.append((rid, txt)))
        _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r1", text="hello"))]
        assert seen == [("r1", "hello")]

    async def test_publishes_event_bus(self) -> None:
        events = []

        class Bus:
            def publish(self, topic, payload):
                events.append((topic, payload))

        svc = SubtitleFallbackService(event_bus=Bus())
        _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r1", text="hi"))]
        assert events == [("tts_subtitle", {"request_id": "r1", "text": "hi"})]

    async def test_metrics(self) -> None:
        svc = SubtitleFallbackService(on_subtitle=lambda _rid, _text: None)
        _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r1", text="a"))]
        _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r2", text="b"))]
        assert svc.get_metrics()["tts_subtitle_total"] == 2


class TestFailSafe:
    async def test_only_sink_failure_does_not_claim_success(self) -> None:
        def boom(*_):
            raise RuntimeError("bad sink")

        svc = SubtitleFallbackService(on_subtitle=boom)
        with pytest.raises(RuntimeError, match="delivery sink"):
            _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r", text="x"))]
        assert svc.get_metrics()["tts_subtitle_delivery_failures_total"] == 1

    async def test_one_failed_sink_can_use_other_verified_event_bus(self) -> None:
        events = []

        def boom(*_):
            raise RuntimeError("bad callback")

        class Bus:
            def publish(self, topic, payload):
                events.append((topic, payload))

        svc = SubtitleFallbackService(on_subtitle=boom, event_bus=Bus())
        chunks = [c async for c in svc.synthesize_stream(TTSRequest(request_id="r", text="hello"))]
        assert len(chunks) == 1 and chunks[0].is_final
        assert events == [("tts_subtitle", {"request_id": "r", "text": "hello"})]

    async def test_cancel_is_noop(self) -> None:
        svc = SubtitleFallbackService()
        await svc.cancel("r")           # không raise

    @pytest.mark.parametrize("required", [False, True])
    async def test_delivery_without_sink_always_fails(self, required: bool) -> None:
        svc = SubtitleFallbackService(require_delivery=required)
        with pytest.raises(RuntimeError, match="no working delivery sink"):
            _ = [
                chunk async for chunk in svc.synthesize_stream(
                    TTSRequest(request_id="r", text="x"),
                )
            ]

    def test_legacy_file_sink_is_rejected_without_touching_history(self, tmp_path: Path) -> None:
        output = tmp_path / "live" / "subtitle.txt"
        output.parent.mkdir()
        historical = b"SYNTHETIC_HISTORICAL_SUBTITLE"
        output.write_bytes(historical)
        with pytest.raises(ValueError, match="file|RAM|metadata|disk"):
            SubtitleFallbackService(output_file=output, require_delivery=True)
        assert output.read_bytes() == historical
        assert not output.with_suffix(".txt.tmp").exists()

    def test_loader_cannot_reenable_a_file_sink(self, tmp_path: Path) -> None:
        output = tmp_path / "new_subtitle.txt"

        class Loader:
            def get(self, name, key, default=None):
                return str(output) if (name, key) == ("models", "tts_fallback.output_file") else default

        with pytest.raises(ValueError):
            SubtitleFallbackService.from_loader(Loader())
        assert not output.exists()


class TestHealth:
    async def test_without_verified_sink_is_degraded(self) -> None:
        svc = SubtitleFallbackService()
        h = await svc.health_check()
        assert h.is_ok is False
        assert h.state.value == "degraded"

    async def test_callback_sink_is_healthy(self) -> None:
        svc = SubtitleFallbackService(on_subtitle=lambda _rid, _text: None)
        assert (await svc.health_check()).is_ok is True

    async def test_http_overlay_is_healthy_only_after_actual_start(self) -> None:
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, require_delivery=True)
        assert not (await svc.health_check()).is_ok
        await svc.start()
        try:
            assert (await svc.health_check()).is_ok
            assert svc.get_metrics()["tts_subtitle_http_running"] is True
        finally:
            await svc.stop()
        assert not (await svc.health_check()).is_ok
        assert svc.get_metrics()["tts_subtitle_http_running"] is False

    async def test_required_delivery_without_sink_is_unhealthy(self) -> None:
        svc = SubtitleFallbackService(require_delivery=True)
        h = await svc.health_check()
        assert h.is_ok is False
        assert h.state.value == "unhealthy"


class TestLocalHttpOverlay:
    async def test_real_http_has_no_store_csp_safe_dom_and_strict_host(self, tmp_path: Path) -> None:
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, require_delivery=True)
        await svc.start()
        payload = '<img src=x onerror="alert(1)">SYNTHETIC_SUBTITLE'
        try:
            chunks = [c async for c in svc.synthesize_stream(TTSRequest(request_id="private-id", text=payload))]
            assert len(chunks) == 1 and chunks[0].is_final
            async with httpx.AsyncClient(base_url=svc.overlay_url, timeout=1.0, trust_env=False) as client:
                page = await client.get("/")
                subtitle = await client.get("/subtitle")
                missing = await client.get("/missing")
                mutation = await client.post("/subtitle", json={"text": "must not overwrite"})
                denied = await client.get("/subtitle", headers={"Host": "attacker.example"})
                assert page.status_code == subtitle.status_code == 200
                assert subtitle.json() == {"text": payload}
                assert "private-id" not in subtitle.text
                assert payload not in page.text
                assert "textContent" in page.text and "innerHTML" not in page.text
                assert missing.status_code == 404
                assert mutation.status_code == 405
                assert (await client.get("/subtitle")).json() == {"text": payload}
                assert denied.status_code in {400, 403}
                assert payload not in denied.text
                for response in (page, subtitle, missing, mutation, denied):
                    assert "no-store" in response.headers["cache-control"]
                    assert response.headers["x-content-type-options"] == "nosniff"
                    assert "default-src" in response.headers["content-security-policy"]
                    assert "access-control-allow-origin" not in response.headers
                origin = await client.get("/subtitle", headers={"Origin": "https://attacker.example"})
                assert "access-control-allow-origin" not in origin.headers
                wrong_port = str(httpx.URL(svc.overlay_url).port + 1)
                wrong = await client.get("/subtitle", headers={"Host": f"127.0.0.1:{wrong_port}"})
                assert wrong.status_code in {400, 403}
            assert list(tmp_path.iterdir()) == []
        finally:
            await svc.stop()

    async def test_ttl_clears_ram_without_http_polling(self) -> None:
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0,
                                      overlay_ttl_s=0.02, require_delivery=True)
        await svc.start()
        try:
            _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="ttl", text="Only in RAM"))]
            assert svc.get_metrics()["tts_subtitle_retained_chars"] > 0
            await asyncio.sleep(0.07)
            assert svc._text == "", "TTL must clear RAM even without HTTP/metrics polling"
            assert svc.get_metrics()["tts_subtitle_retained_chars"] == 0
            assert svc.get_metrics()["tts_subtitle_expired_total"] == 1
            async with httpx.AsyncClient(base_url=svc.overlay_url, trust_env=False) as client:
                assert (await client.get("/subtitle")).json() == {"text": ""}
        finally:
            await svc.stop()

    async def test_cancel_family_cancel_all_and_stop_clear_visible_text(self) -> None:
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, require_delivery=True)
        await svc.start()
        url = svc.overlay_url
        try:
            async with httpx.AsyncClient(base_url=url, trust_env=False) as client:
                _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="root#0", text="Visible"))]
                await svc.cancel("other")
                assert (await client.get("/subtitle")).json()["text"] == "Visible"
                await svc.cancel("root")
                assert (await client.get("/subtitle")).json()["text"] == ""
                _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="next", text="Next"))]
                await svc.cancel_all()
                assert (await client.get("/subtitle")).json()["text"] == ""
                _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="stop", text="Clear on stop"))]
        finally:
            await svc.stop()
        assert svc.get_metrics()["tts_subtitle_retained_chars"] == 0
        assert svc.get_metrics()["tts_subtitle_http_running"] is False

    async def test_occupied_port_never_reports_healthy_or_delivered(self) -> None:
        with socket.socket() as occupied:
            occupied.bind(("127.0.0.1", 0))
            occupied.listen(1)
            svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=occupied.getsockname()[1],
                                          require_delivery=True)
            try:
                with pytest.raises((OSError, RuntimeError)):
                    await svc.start()
                assert not (await svc.health_check()).is_ok
                assert svc.get_metrics()["tts_subtitle_http_running"] is False
                with pytest.raises(RuntimeError):
                    _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="blocked", text="Not delivered"))]
            finally:
                await svc.stop()

    @pytest.mark.parametrize("mode", ["timeout", "cancel"])
    async def test_startup_timeout_or_cancellation_closes_socket_and_server_task(self, monkeypatch, mode: str) -> None:
        from services.tts import subtitle_fallback as module

        entered = asyncio.Event()
        ports: list[int] = []

        async def never_ready(self, sockets=None):
            ports.extend(item.getsockname()[1] for item in sockets)
            entered.set()
            await asyncio.Event().wait()

        monkeypatch.setattr(module._OverlayServer, "serve", never_ready)
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0,
                                      overlay_poll_s=0.001, startup_timeout_s=0.02, require_delivery=True)
        task = asyncio.create_task(svc.start())
        try:
            await asyncio.wait_for(entered.wait(), timeout=1.0)
            server_task = svc._server_task
            if mode == "cancel":
                task.cancel()
                with pytest.raises(asyncio.CancelledError):
                    await task
            else:
                with pytest.raises(TimeoutError):
                    await task
            assert server_task.done()
            assert svc._server_task is None and svc._socket is None
            assert not (await svc.health_check()).is_ok
            assert svc.get_metrics()["tts_subtitle_http_running"] is False
            assert ports
            with socket.socket() as probe:
                probe.bind(("127.0.0.1", ports[0]))
        finally:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
            await svc.stop()

    async def test_max_chars_rejects_not_truncates_or_calls_injected_sink(self) -> None:
        seen = []
        svc = SubtitleFallbackService(on_subtitle=lambda rid, text: seen.append((rid, text)),
                                      overlay_max_chars=4, require_delivery=True)
        _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="x", text="good"))]
        with pytest.raises((ValueError, RuntimeError)):
            _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="y", text="ABCDE"))]
        assert seen == [("x", "good")]

    async def test_request_id_cannot_hide_unbounded_retained_text(self) -> None:
        seen = []
        svc = SubtitleFallbackService(on_subtitle=lambda rid, text: seen.append((rid, text)), overlay_max_chars=4)
        with pytest.raises((ValueError, RuntimeError)):
            _ = [c async for c in svc.synthesize_stream(TTSRequest(request_id="ABCDE", text="ok"))]
        assert seen == []

    async def test_one_client_limit_still_serves_one_client(self) -> None:
        svc = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, overlay_max_clients=1)
        await svc.start()
        try:
            async with httpx.AsyncClient(base_url=svc.overlay_url, trust_env=False) as client:
                response = await client.get("/subtitle")
                assert response.status_code == 200
                assert response.json() == {"text": ""}
        finally:
            await svc.stop()

    @pytest.mark.parametrize("options", [
        {"overlay_host": "0.0.0.0"}, {"overlay_host": "localhost"},
        {"overlay_host": "::1"}, {"overlay_port": 65536},
        {"overlay_ttl_s": 0}, {"overlay_max_chars": 0},
        {"overlay_max_clients": 0},
    ])
    def test_constructor_rejects_unsafe_or_unbounded_configuration(self, options: dict) -> None:
        with pytest.raises((ValueError, TypeError)):
            SubtitleFallbackService(**options)
