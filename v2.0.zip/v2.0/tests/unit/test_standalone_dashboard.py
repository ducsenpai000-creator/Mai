from __future__ import annotations

import json
from pathlib import Path
import re

import pytest

from services.operations.standalone_snapshot import StandaloneSnapshotProvider
from services.data.sanitize import metadata_reference


async def test_standalone_provider_reads_last_snapshot_and_forces_controls_offline(
    tmp_path: Path,
) -> None:
    snapshot = tmp_path / "snapshot.json"
    audit = tmp_path / "audit.jsonl"
    snapshot.write_text(json.dumps({
        "agent": {"active_goal_ref": "goal:1", "open_threads": []},
        "runtime": {"running": False},
    }), encoding="utf-8")
    audit.write_text(json.dumps({
        "action": "pause", "target": "agent", "outcome": "completed",
    }) + "\n", encoding="utf-8")
    incidents = tmp_path / "incidents.jsonl"
    incidents.write_text(json.dumps({
        "incident_id": "inc:1", "status": "open", "severity": "warning",
    }) + "\n", encoding="utf-8")
    provider = StandaloneSnapshotProvider(
        snapshot_path=snapshot, audit_path=audit, incident_path=incidents,
    )
    await provider.start()
    value = await provider.snapshot()
    assert re.fullmatch(r"r_[0-9a-f]{16}", value["agent"]["active_goal_ref"])
    assert value["agent"]["active_goal_ref"] != "goal:1"
    assert value["runtime"]["online"] is False
    assert value["runtime"]["mode"] == "standalone"
    assert value["runtime"]["controls_available"] is False
    assert value["operations"]["audit"][0]["action"] == "pause"
    assert value["incidents"]["unresolved"] == 1
    assert (await provider.health_check()).is_ok


async def test_missing_or_invalid_snapshot_is_safe(tmp_path: Path) -> None:
    snapshot = tmp_path / "bad.json"
    snapshot.write_text("not-json", encoding="utf-8")
    provider = StandaloneSnapshotProvider(
        snapshot_path=snapshot, audit_path=tmp_path / "missing.jsonl",
    )
    value = await provider.snapshot()
    assert value["runtime"]["online"] is False
    assert value.get("agent") is None


async def test_legacy_snapshot_read_projects_private_duplicates_before_own_audit_tails(tmp_path: Path) -> None:
    secret = "SYNTHETIC_LEGACY_CHAT tên Nguyễn Mẫu viewer@example.invalid 0900000000"
    snapshot = tmp_path / "legacy.json"
    old = {
        "agent": {"active_goal_ref": secret, "topic": secret, "recap": secret,
                  "current_topic": {"summary": secret},
                  "open_threads": [{"thread_id": secret, "kind": "question", "summary": secret}],
                  "recent_events": [{"event_id": secret, "kind": "chat_received", "text": secret}]},
        "authoritative_state": {"agent": {"topic": secret, "recap": secret,
                                          "open_threads": [{"thread_id": secret, "summary": secret}]}},
        "goals": {"active": {"goal_id": secret, "status": "active", "description": secret,
                              "reason": secret, "success_condition": secret, "metadata": {"text": secret}}},
        "operations": {"audit": [{"reason": secret}], "available": True},
        "incidents": {"recent": [{"incident_id": secret, "summary": secret}]},
        "metrics": {"llm_requests_total": 9, secret: 1},
        "runtime": {"running": False, "mode": "live"}, secret: {"count": 9},
    }
    legacy_text = json.dumps(old, ensure_ascii=False)
    snapshot.write_text(legacy_text, encoding="utf-8")
    original_bytes = snapshot.read_bytes()
    audit = tmp_path / "audit.jsonl"
    audit.write_text(json.dumps({"action": "pause", "target": "agent", "outcome": "completed"}), encoding="utf-8")
    incidents = tmp_path / "incidents.jsonl"
    incidents.write_text(json.dumps({"incident_id": "inc:safe", "status": "open", "severity": "warning"}), encoding="utf-8")
    provider = StandaloneSnapshotProvider(snapshot_path=snapshot, audit_path=audit, incident_path=incidents)

    value = await provider.snapshot()
    again = await provider.snapshot()
    serialized = json.dumps(value, ensure_ascii=False)

    for marker in ("SYNTHETIC_LEGACY_CHAT", "Nguyễn Mẫu", "viewer@example.invalid", "0900000000"):
        assert marker not in serialized
    assert snapshot.read_text(encoding="utf-8") == legacy_text
    assert snapshot.read_bytes() == original_bytes
    assert value == again
    opaque = value["agent"]["active_goal_ref"]
    assert re.fullmatch(r"r_[0-9a-f]{16}", opaque)
    assert value["goals"]["active"] == {"goal_id": opaque, "status": "active"}
    assert value["authoritative_state"]["agent"]["open_threads"] == [{"thread_id": opaque}]
    assert value["metrics"] == {"llm_requests_total": 9}
    assert value["operations"]["audit"] == [{"action": "pause", "target": "agent", "outcome": "completed"}]
    assert value["incidents"]["recent"] == [{"incident_id": metadata_reference("inc:safe"), "status": "open", "severity": "warning"}]
    assert value["incidents"]["unresolved"] == 1
    assert value["runtime"]["online"] is False
    assert value["operations"]["available"] is False


@pytest.mark.parametrize("error_type", [ValueError, TypeError])
async def test_legacy_projection_failure_returns_offline_without_raw_fallback(
    tmp_path: Path, monkeypatch, error_type: type[Exception],
) -> None:
    from services.operations import standalone_snapshot as module

    secret = "SYNTHETIC_PRIVATE_READ viewer@example.invalid"
    path = tmp_path / "legacy.json"
    original = json.dumps({"agent": {"topic": secret}})
    path.write_text(original, encoding="utf-8")

    def broken_projection(_value):
        raise error_type(secret)

    monkeypatch.setattr(module, "metadata_snapshot", broken_projection)
    provider = StandaloneSnapshotProvider(snapshot_path=path, audit_path=tmp_path / "none.jsonl")
    value = await provider.snapshot()

    assert value.get("agent") is None
    assert secret not in json.dumps(value)
    assert value["runtime"]["mode"] == "standalone"
    assert value["runtime"]["controls_available"] is False
    assert path.read_text(encoding="utf-8") == original
