"""Synthetic voice candidates through the production chunk renderer, not MOS."""
from __future__ import annotations

import hashlib
import asyncio
import json
import time
from pathlib import Path

import numpy as np
import pytest
import soundfile as sf

from interfaces.tts import TTSRequest
from orchestrator.config_loader import ConfigLoader
from services.tts.audio_player import AudioPlayer
from services.tts.vieneu_service import VieNeuTtsService

ROOT = Path(__file__).resolve().parents[2]
pytestmark = pytest.mark.llm


class CaptureBackend:
    """Capture exactly what AudioPlayer would write; do not claim speaker playback."""

    def __init__(self) -> None:
        self.chunks: list[np.ndarray] = []

    def play_blocking(self, samples: np.ndarray, sample_rate: int) -> None:
        self.chunks.append(samples.copy())

    def stop(self) -> None:
        pass


async def test_real_tts_voice_candidates(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HF_HUB_OFFLINE", "1")
    monkeypatch.setenv("TRANSFORMERS_OFFLINE", "1")
    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    service = VieNeuTtsService.from_loader(loader)
    output_dir = ROOT / "test-results" / "voice_candidates"
    output_dir.mkdir(parents=True, exist_ok=True)
    texts = (
        "Cậu cứ chọn vani đi, phần sô cô la để tớ giữ nhé. Chuyên gia đồ ngọt không chịu thiệt đâu!",
        "Tớ chưa thấy màn hình của cậu. Kể tớ nghe chuyện gì vừa xảy ra nhé.",
        "Ừ, cậu cứ nghỉ ngơi nhé. Hôm nay không cần cố tỏ ra ổn đâu.",
    )
    report = {"schema_version": 1, "synthetic_only": True, "human_listening_required": True,
              "mos_assessed": False, "speaker_playback_verified": False,
              "renderer": "production_audio_player_per_chunk", "rows": [],
              "models_yaml_sha256": hashlib.sha256((ROOT / "config/models.yaml").read_bytes()).hexdigest()}
    try:
        await service.start()
        for index, text in enumerate(texts):
            started = time.perf_counter()
            chunks = [c async for c in service.synthesize_stream(TTSRequest(request_id=f"voice-{index}", text=text))]
            generation_ms = (time.perf_counter() - started) * 1000
            assert chunks[-1].is_final and any(c.audio_bytes for c in chunks)
            for pitch in (0.0, 1.5, 3.0):
                capture = CaptureBackend()
                player = AudioPlayer(sample_rate=service.sample_rate, backend=capture, pitch_semitones=pitch)
                await player.start()
                try:
                    receipts = [await player.enqueue(c) for c in chunks]
                    assert all(await asyncio.gather(*receipts))
                finally:
                    await player.stop()
                audio = np.concatenate(capture.chunks)
                assert audio.size > 0 and np.isfinite(audio).all()
                path = output_dir / f"sample_{index}_pitch_{pitch:g}.wav"
                sf.write(path, audio, service.sample_rate, subtype="PCM_16")
                peak = float(np.max(np.abs(audio)))
                report["rows"].append({"text": text, "pitch_semitones": pitch,
                    "file": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "duration_s": len(audio) / service.sample_rate, "peak": peak,
                    "clipped_fraction": float(np.mean(np.abs(audio) >= 1.0)),
                    "generation_ms": generation_ms, "ttfa_ms": service.get_metrics()["tts_last_ttfa_ms"],
                    "engine_chunks": len(chunks) - 1})
                assert peak < 1.0, "candidate clips before WAV encoding"
        report["metrics"] = service.get_metrics()
    finally:
        await service.stop()
        (output_dir / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
