"""VieNeuTtsService — VieNeu-TTS v3 Turbo streaming (Phase 4).

Production baseline:
- VieNeu-TTS v3 Turbo (48kHz, GPU PyTorch), clone qua vi_sample.wav
- BẮT BUỘC `add_voice()` trong start() để enroll ref audio 1 lần → cache
  speaker_emb + ref_codes. Nếu KHÔNG cache, mỗi infer re-encode ref → TTFA 5626ms.
  Sau khi cache: TTFA ~308ms (đo được, nhanh hơn viXTTS 450ms 32%).
- Streaming qua `infer_stream(voice=name)` yield np.float32 chunks

Audio chunk: raw float32 mono PCM @ 48kHz (bytes) — audio player 4.D dùng nguyên.
Test không GPU: inject fake `engine` qua constructor.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import contextlib
import threading
import time
from pathlib import Path
from typing import Any, AsyncIterator

import numpy as np

from interfaces.base import HealthStatus
from interfaces.tts import AudioChunk, TTSRequest, TTSService
from orchestrator.logger import get_logger

_SENTINEL = object()
_VOICE_NAME = "mai_ref"  # tên nội bộ cho enrolled voice
_torchaudio_patched = False


def _patch_torchaudio_load() -> None:
    """torchaudio 2.11 bỏ backend soundfile, redirect load() sang torchcodec —
    torchcodec cần FFmpeg DLL không có sẵn Windows. Patch load() dùng soundfile
    trực tiếp (đủ cho VieNeu chỉ load wav ref). Idempotent.
    """
    global _torchaudio_patched
    if _torchaudio_patched:
        return
    import torchaudio
    import torch
    import soundfile as sf

    def _sf_load(path, *args, **kw):
        audio, sr = sf.read(str(path), dtype="float32", always_2d=True)
        return torch.from_numpy(audio.T), sr

    torchaudio.load = _sf_load
    _torchaudio_patched = True


class VieNeuError(Exception):
    pass


class VieNeuTtsService(TTSService):
    service_id = "tts"

    def __init__(
        self,
        reference_audio: str | Path,
        style: str = "tu_nhien",
        denoise: bool = True,
        temperature: float = 0.8,
        top_k: int = 25,
        top_p: float = 0.95,
        max_new_frames: int = 300,
        repetition_penalty: float = 1.2,
        sample_rate: int = 48000,
        device: str = "cuda",
        backend: str = "pytorch",
        engine: Any = None,
        queue_maxsize: int = 32,
        handoff_poll_s: float = 0.05,
        producer_drain_timeout_s: float = 3.0,
        warmup_text: str = "",
    ) -> None:
        self.reference_audio = Path(reference_audio)
        self.style = style
        self.denoise = denoise
        self.temperature = temperature
        self.top_k = top_k
        self.top_p = top_p
        self.max_new_frames = max_new_frames
        self.repetition_penalty = repetition_penalty
        self.sample_rate = sample_rate
        self.device = device
        self.backend = backend
        self._queue_maxsize = queue_maxsize
        if queue_maxsize < 1 or handoff_poll_s <= 0 or producer_drain_timeout_s <= 0:
            raise ValueError("invalid TTS handoff bounds")
        self._handoff_poll_s = handoff_poll_s
        self._producer_drain_timeout_s = producer_drain_timeout_s
        self._warmup_text = warmup_text.strip()
        self._warmup_requests_total = 0
        self._last_warmup_ms: float | None = None
        self._inference_lock = asyncio.Lock()
        self._producer_task: asyncio.Future[None] | None = None
        self._cancel_event: threading.Event | None = None
        self._cancel_wake: asyncio.Event | None = None
        self._active_id: str | None = None
        self._stopping = False
        self._backpressure_total = 0
        self._cancel_total = 0
        self._drain_timeouts = 0

        self._engine = engine
        self._voice_enrolled = False
        self._voice_profile: dict[str, Any] | None = None

        self._log = get_logger("tts")

        self._requests_total = 0
        self._errors_total = 0
        self._last_ttfa_ms: float | None = None
        self._last_chunks: int = 0
        self._last_audio_ms: int = 0
        self._last_rtf: float | None = None
        self._last_startup_ms: float | None = None
        self._startup_errors = 0

    @classmethod
    def from_loader(cls, loader, engine: Any = None) -> "VieNeuTtsService":
        get = lambda k, d=None: loader.get("models", f"tts.{k}", d)  # noqa: E731
        params = get("params", {}) or {}
        return cls(
            reference_audio=get("reference_audio"),
            style=str(params.get("style", "tu_nhien")),
            denoise=bool(params.get("denoise", True)),
            temperature=float(params.get("temperature", 0.8)),
            top_k=int(params.get("top_k", 25)),
            top_p=float(params.get("top_p", 0.95)),
            max_new_frames=int(params.get("max_new_frames", 300)),
            repetition_penalty=float(params.get("repetition_penalty", 1.2)),
            sample_rate=int(get("sample_rate", 48000)),
            device=str(get("device", "cuda")),
            backend=str(get("backend", "pytorch")),
            engine=engine,
            queue_maxsize=int(get("queue_maxsize", 32)),
            handoff_poll_s=float(get("handoff_poll_s", 0.05)),
            producer_drain_timeout_s=float(get("producer_drain_timeout_s", 3.0)),
            warmup_text=str(get("warmup_text", "")),
        )

    # ---------- Service ----------

    async def start(self) -> None:
        await self._drain_producer()
        self._stopping = False
        started_at = time.perf_counter()
        try:
            if self._engine is None:
                _patch_torchaudio_load()  # real VieNeu only; injected fakes stay dependency-free
                self._engine = await asyncio.to_thread(self._load_engine)
            # Enroll ref audio 1 LẦN (cache speaker_emb + ref_codes) — critical.
            await asyncio.to_thread(self._enroll_reference)
            if self._warmup_text:
                warmup_started = time.perf_counter()
                async with contextlib.aclosing(self.synthesize_stream(TTSRequest(
                    request_id="tts-warmup", text=self._warmup_text,
                ))) as stream:
                    has_audio = False
                    async for chunk in stream:
                        has_audio = has_audio or bool(chunk.audio_bytes)
                if not has_audio:
                    raise VieNeuError("warmup produced no audio")
                self._warmup_requests_total += 1
                self._last_warmup_ms = (time.perf_counter() - warmup_started) * 1000
        except Exception:
            self._startup_errors += 1
            self._voice_enrolled = False
            self._voice_profile = None
            raise
        finally:
            self._last_startup_ms = (time.perf_counter() - started_at) * 1000
        info: dict[str, Any] = {
            "reference_audio": str(self.reference_audio),
            "sample_rate": self.sample_rate,
            "style": self.style,
            "device": self.device,
            "backend": self.backend,
        }
        try:
            import torch
            if self.device == "cuda" and torch.cuda.is_available():
                info["vram_alloc_gb"] = round(torch.cuda.memory_allocated() / 1024**3, 2)
        except Exception:  # pragma: no cover
            pass
        self._log.info("tts_ready", **info)

    async def stop(self) -> None:
        self._stopping = True
        self._signal_cancel()
        # Never free an engine still used by its worker thread.
        await self._drain_producer()
        self._engine = None
        self._voice_enrolled = False
        self._voice_profile = None
        await asyncio.to_thread(self._reclaim_memory)

    async def health_check(self) -> HealthStatus:
        if self._engine is None or not self._voice_enrolled:
            return HealthStatus.unhealthy(self.service_id, "chưa start() hoặc voice chưa enrolled")
        return HealthStatus.healthy(self.service_id, sample_rate=self.sample_rate)

    def get_metrics(self) -> dict[str, Any]:
        return {
            "tts_requests_total": self._requests_total,
            "tts_errors_total": self._errors_total,
            "tts_last_ttfa_ms": self._last_ttfa_ms,
            "tts_last_chunks": self._last_chunks,
            "tts_last_audio_ms": self._last_audio_ms,
            "tts_last_rtf": self._last_rtf,
            "tts_last_startup_ms": self._last_startup_ms,
            "tts_startup_errors_total": self._startup_errors,
            "tts_backpressure_total": self._backpressure_total,
            "tts_cancel_total": self._cancel_total,
            "tts_producer_drain_timeouts_total": self._drain_timeouts,
            "tts_producer_inflight": bool(self._producer_task and not self._producer_task.done()),
            "tts_warmup_requests_total": self._warmup_requests_total,
            "tts_last_warmup_ms": self._last_warmup_ms,
        }

    def _load_engine(self) -> Any:
        from vieneu import Vieneu
        return Vieneu(mode="v3turbo", backend=self.backend)

    def _enroll_reference(self) -> None:
        if not self.reference_audio.exists():
            raise VieNeuError(f"reference_audio không tồn tại: {self.reference_audio}")
        # VieNeu v3 wrapper pre-cleans vào ~/.cache trước add_voice(). Trên Windows
        # thư mục profile có thể bị policy/antivirus chặn và làm mkstemp treo vô hạn.
        # Engine v3 đã nhận WAV trực tiếp, nên enroll vào profile RAM để không tạo
        # temp ngoài workspace. Fake/legacy engine vẫn dùng public add_voice().
        core = getattr(self._engine, "engine", None)
        prepare_reference = getattr(core, "prepare_reference", None)
        if callable(prepare_reference):
            speaker_emb, ref_codes = prepare_reference(
                str(self.reference_audio),
                denoise=self.denoise,
                use_ref_codes=True,
            )
            self._voice_profile = {
                "speaker_emb": speaker_emb,
                "codes": ref_codes,
                "style": self.style,
            }
        else:
            self._engine.add_voice(
                _VOICE_NAME, str(self.reference_audio), denoise=self.denoise,
            )
            self._voice_profile = None
        self._voice_enrolled = True

    def _reclaim_memory(self) -> None:
        import gc
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    # ---------- streaming ----------

    async def cancel(self, request_id: str) -> None:
        if self._active_id is not None and (
            self._active_id == request_id or self._active_id.startswith(request_id + "#")
        ):
            self._cancel_total += 1
            self._signal_cancel()

    def _signal_cancel(self) -> None:
        if self._cancel_event is not None:
            self._cancel_event.set()
        if self._cancel_wake is not None:
            self._cancel_wake.set()

    async def _drain_producer(self) -> None:
        task = self._producer_task
        if task is None:
            return
        try:
            await asyncio.wait_for(asyncio.shield(task), self._producer_drain_timeout_s)
        except asyncio.TimeoutError as exc:
            self._drain_timeouts += 1
            raise VieNeuError("previous inference has not drained") from exc
        if self._producer_task is task:
            self._producer_task = None
            self._active_id = None
            self._cancel_event = None
            self._cancel_wake = None

    async def synthesize_stream(self, request: TTSRequest) -> AsyncIterator[AudioChunk]:
        async with self._inference_lock:
            await self._drain_producer()
            if self._stopping:
                raise VieNeuError("service stopping")
            async with contextlib.aclosing(self._stream_request(request)) as stream:
                async for chunk in stream:
                    yield chunk

    async def _stream_request(self, request: TTSRequest) -> AsyncIterator[AudioChunk]:
        if self._engine is None or not self._voice_enrolled:
            raise VieNeuError("service chưa start() hoặc voice chưa enrolled")
        self._requests_total += 1

        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[Any] = asyncio.Queue(maxsize=self._queue_maxsize)
        cancel_event = threading.Event()
        cancel_wake = asyncio.Event()
        self._cancel_event = cancel_event
        self._cancel_wake = cancel_wake
        self._active_id = request.request_id
        engine = self._engine

        def _put(item: Any) -> bool:
            if cancel_event.is_set():
                return False
            pending = asyncio.run_coroutine_threadsafe(queue.put(item), loop)
            blocked = False
            while not cancel_event.is_set():
                try:
                    pending.result(timeout=self._handoff_poll_s)
                    return True
                except concurrent.futures.TimeoutError:
                    if not blocked:
                        self._backpressure_total += 1
                        blocked = True
            pending.cancel()
            return False

        def _producer() -> None:
            gen = None
            try:
                gen = engine.infer_stream(
                    text=request.text,
                    voice=self._voice_profile or _VOICE_NAME,
                    style=self.style,
                    temperature=self.temperature,
                    top_k=self.top_k,
                    top_p=self.top_p,
                    max_new_frames=self.max_new_frames,
                    repetition_penalty=self.repetition_penalty,
                )
                for chunk in gen:
                    if not _put(chunk):
                        break
            except Exception as e:
                _put(e)
            finally:
                try:
                    if gen is not None and hasattr(gen, "close"):
                        gen.close()
                except Exception as e:
                    _put(e)
                finally:
                    _put(_SENTINEL)

        t0 = time.perf_counter()
        t_first: float | None = None
        idx = 0
        total_samples = 0
        producer_task = loop.run_in_executor(None, _producer)
        self._producer_task = producer_task
        wake_task = asyncio.create_task(cancel_wake.wait())

        try:
            while True:
                get_task = asyncio.create_task(queue.get())
                try:
                    await asyncio.wait((get_task, wake_task), return_when=asyncio.FIRST_COMPLETED)
                    if cancel_event.is_set():
                        break
                    item = get_task.result()
                finally:
                    if not get_task.done():
                        get_task.cancel()
                    await asyncio.gather(get_task, return_exceptions=True)
                if item is _SENTINEL:
                    break
                if isinstance(item, Exception):
                    raise VieNeuError(f"infer_stream failed: {type(item).__name__}") from item

                if t_first is None:
                    t_first = time.perf_counter()
                    self._last_ttfa_ms = (t_first - t0) * 1000

                audio_np, samples = _to_float32_mono(item)
                if samples == 0:
                    continue
                total_samples += samples
                duration_ms = int(1000 * samples / self.sample_rate)
                yield AudioChunk(
                    request_id=request.request_id,
                    chunk_index=idx,
                    audio_bytes=audio_np.tobytes(),
                    is_final=False,
                    duration_ms=duration_ms,
                )
                idx += 1

            self._last_chunks = idx
            self._last_audio_ms = int(1000 * total_samples / self.sample_rate)
            if t_first is not None and self._last_audio_ms > 0:
                self._last_rtf = (time.perf_counter() - t0) / (self._last_audio_ms / 1000)
            yield AudioChunk(
                request_id=request.request_id,
                chunk_index=idx,
                audio_bytes=b"",
                is_final=True,
                duration_ms=0,
            )
        except Exception:
            self._errors_total += 1
            raise
        finally:
            cancel_event.set()
            wake_task.cancel()
            await asyncio.gather(wake_task, return_exceptions=True)
            # Cancelling an executor future does not stop its thread. Retain ownership
            # through timeout so a later request cannot enter the engine concurrently.
            await self._drain_producer()


def _to_float32_mono(item: Any) -> tuple[np.ndarray, int]:
    """Chuyển 1 chunk từ VieNeu infer_stream về float32 mono numpy."""
    if hasattr(item, "detach"):
        arr = item.detach().cpu().numpy()
    elif isinstance(item, np.ndarray):
        arr = item
    else:
        arr = np.asarray(item, dtype=np.float32)
    arr = np.asarray(arr, dtype=np.float32).squeeze()
    if arr.ndim == 0:
        arr = arr.reshape(1)
    if arr.ndim > 1:
        arr = arr.mean(axis=0)
    if not np.isfinite(arr).all():
        raise VieNeuError("non-finite audio chunk")
    return arr, int(arr.shape[0])
