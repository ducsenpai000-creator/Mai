"""Terminal TTS delivery through an ephemeral loopback subtitle overlay.

Only the latest text is retained in bounded RAM. A successful handoff confirms
the local sink, not an OBS browser, capture device or public broadcast.
"""
from __future__ import annotations

import asyncio
import contextlib
import math
from pathlib import Path
import socket
import time
from typing import Any, AsyncIterator, Callable, Iterator

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
import uvicorn

from interfaces.base import HealthStatus
from interfaces.tts import AudioChunk, TTSRequest, TTSService
from orchestrator.logger import get_logger

SubtitleSink = Callable[[str, str], None]

_PRIVACY_HEADERS = {
    "Cache-Control": "no-store",
    "Pragma": "no-cache",
    "Expires": "0",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": (
        "default-src 'none'; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; connect-src 'self'; "
        "base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
    ),
}


class _OverlayServer(uvicorn.Server):
    @contextlib.contextmanager
    def capture_signals(self) -> Iterator[None]:
        # The outer runtime owns Windows process signals and shutdown ordering.
        yield


class SubtitleFallbackService(TTSService):
    service_id = "tts_subtitle"

    def __init__(
        self,
        on_subtitle: SubtitleSink | None = None,
        event_bus: Any = None,
        output_file: str | Path | None = None,
        require_delivery: bool = False,
        *,
        overlay_host: str | None = None,
        overlay_port: int = 7862,
        overlay_ttl_s: float = 15.0,
        overlay_max_chars: int = 4000,
        overlay_poll_s: float = 0.1,
        overlay_max_clients: int = 8,
        startup_timeout_s: float = 5.0,
    ) -> None:
        if output_file is not None:
            raise ValueError("subtitle output_file is prohibited; migrate OBS to the RAM Browser Source")
        if overlay_host is not None and overlay_host != "127.0.0.1":
            raise ValueError("subtitle overlay_host must be the literal loopback 127.0.0.1")
        if type(overlay_port) is not int or not 0 <= overlay_port <= 65535:
            raise ValueError("subtitle overlay_port must be a valid port (0 is test-only)")
        if type(overlay_max_chars) is not int or overlay_max_chars < 1:
            raise ValueError("subtitle overlay_max_chars must be a positive integer")
        if type(overlay_max_clients) is not int or overlay_max_clients < 1:
            raise ValueError("subtitle overlay_max_clients must be a positive integer")
        for name, value in (
            ("overlay_ttl_s", overlay_ttl_s),
            ("overlay_poll_s", overlay_poll_s),
            ("startup_timeout_s", startup_timeout_s),
        ):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"subtitle {name} must be finite and positive")
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"subtitle {name} must be finite and positive")
        self._on_subtitle = on_subtitle
        self._event_bus = event_bus
        self._require_delivery = require_delivery
        self._overlay_host = overlay_host
        self._overlay_port = overlay_port
        self._overlay_ttl_s = float(overlay_ttl_s)
        self._overlay_max_chars = overlay_max_chars
        self._overlay_poll_s = float(overlay_poll_s)
        self._overlay_max_clients = overlay_max_clients
        self._startup_timeout_s = float(startup_timeout_s)
        self._log = get_logger("tts_subtitle")
        self._subtitles_total = 0
        self._delivery_failures = 0
        self._expired_total = 0
        self._http_failures = 0
        self._text = ""
        self._request_id: str | None = None
        self._expires_at = 0.0
        self._expiry_handle: asyncio.TimerHandle | None = None
        self._socket: socket.socket | None = None
        self._bound_port: int | None = None
        self._server: _OverlayServer | None = None
        self._server_task: asyncio.Task[None] | None = None
        self._lifecycle_lock = asyncio.Lock()

    @classmethod
    def from_loader(
        cls,
        loader: Any,
        *,
        on_subtitle: SubtitleSink | None = None,
        event_bus: Any = None,
    ) -> "SubtitleFallbackService":
        return cls(
            on_subtitle=on_subtitle,
            event_bus=event_bus,
            output_file=loader.get("models", "tts_fallback.output_file", None),
            require_delivery=loader.get("models", "tts_fallback.require_delivery", True),
            overlay_host=loader.get("models", "tts_fallback.overlay_host", "127.0.0.1"),
            overlay_port=loader.get("models", "tts_fallback.overlay_port", 7862),
            overlay_ttl_s=loader.get("models", "tts_fallback.overlay_ttl_s", 15.0),
            overlay_max_chars=loader.get("models", "tts_fallback.overlay_max_chars", 4000),
            overlay_poll_s=loader.get("models", "tts_fallback.overlay_poll_s", 0.1),
            overlay_max_clients=loader.get("models", "tts_fallback.overlay_max_clients", 8),
            startup_timeout_s=loader.get("models", "tts.health_timeout_s", 5.0),
        )

    @property
    def overlay_url(self) -> str | None:
        port = self._bound_port or self._overlay_port
        return f"http://127.0.0.1:{port}/" if self._overlay_host and port else None

    def _http_running(self) -> bool:
        return (
            self._server is not None and self._server.started
            and not self._server.should_exit
            and self._server_task is not None and not self._server_task.done()
        )

    async def start(self) -> None:
        if self._overlay_host is None:
            return
        async with self._lifecycle_lock:
            if self._http_running():
                return
            self._clear()
            await self._close_http()
            try:
                # Prebind ourselves: occupied ports raise OSError, not uvicorn's
                # SystemExit, and every failed/cancelled startup owns its socket.
                self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                    self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                self._socket.bind((self._overlay_host, self._overlay_port))
                self._socket.setblocking(False)
                self._bound_port = int(self._socket.getsockname()[1])
                self._server = _OverlayServer(uvicorn.Config(
                    self._app(), host=self._overlay_host, port=self._bound_port,
                    access_log=False, log_config=None, log_level="critical",
                    proxy_headers=False, server_header=False, date_header=False,
                    ws="none",
                    lifespan="off", timeout_graceful_shutdown=self._startup_timeout_s,
                    # uvicorn counts the just-accepted connection and rejects
                    # at >= limit; +1 therefore admits the configured capacity.
                    limit_concurrency=self._overlay_max_clients + 1,
                    backlog=self._overlay_max_clients,
                    timeout_keep_alive=min(self._overlay_ttl_s, self._startup_timeout_s),
                ))
                self._server_task = asyncio.create_task(
                    self._serve_overlay(self._server, self._socket), name="subtitle_overlay",
                )
                deadline = time.monotonic() + self._startup_timeout_s
                while not self._http_running():
                    if self._server_task.done():
                        await self._server_task
                        raise RuntimeError("subtitle overlay stopped during startup")
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise TimeoutError("subtitle overlay startup timed out")
                    await asyncio.sleep(min(self._overlay_poll_s, remaining))
            except BaseException:
                self._http_failures += 1
                self._clear()
                await self._close_http()
                raise

    async def stop(self) -> None:
        async with self._lifecycle_lock:
            self._clear()
            await self._close_http()

    async def _serve_overlay(self, server: _OverlayServer, listener: socket.socket) -> None:
        try:
            await server.serve(sockets=[listener])
        finally:
            if self._server is server:
                self._clear()

    async def _close_http(self) -> None:
        server, task = self._server, self._server_task
        try:
            if server is not None:
                server.should_exit = True
            if task is not None:
                done, _ = await asyncio.wait({task}, timeout=self._startup_timeout_s)
                if not done:
                    task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await task
        finally:
            if task is not None and not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await task
            if server is not None:
                for listener in getattr(server, "servers", ()):
                    listener.close()
                    await listener.wait_closed()
            if self._socket is not None:
                self._socket.close()
            self._server = None
            self._server_task = None
            self._socket = None
            self._bound_port = None

    def _app(self) -> FastAPI:
        app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

        @app.middleware("http")
        async def privacy_headers(request: Request, call_next: Any) -> Response:
            # Literal Host + port prevents DNS-rebinding aliases. No CORS is
            # installed, and this service exposes no mutating HTTP endpoint.
            expected = f"127.0.0.1:{self._bound_port}"
            if request.headers.get("host") != expected:
                response = Response(status_code=400)
            else:
                response = await call_next(request)
            response.headers.update(_PRIVACY_HEADERS)
            return response

        @app.get("/", response_class=HTMLResponse)
        async def overlay_page() -> HTMLResponse:
            interval_ms = self._overlay_poll_s * 1000.0
            return HTMLResponse(
                "<!doctype html><html lang=\"vi\"><meta charset=\"utf-8\">"
                "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                "<title>Mai subtitles</title><style>"
                "html,body{margin:0;background:transparent;overflow:hidden}"
                "#subtitle{color:white;font:36px sans-serif;white-space:pre-wrap;"
                "overflow-wrap:anywhere;text-align:center;text-shadow:0 2px 4px black}"
                "</style><body><div id=\"subtitle\" role=\"status\"></div><script>"
                "const target=document.getElementById('subtitle');"
                "async function poll(){try{const response=await fetch('/subtitle',"
                "{cache:'no-store',credentials:'omit'});if(!response.ok)throw new Error();"
                "const payload=await response.json();target.textContent=payload.text;"
                "}catch(_){target.textContent='';}"
                f"setTimeout(poll,{interval_ms});"
                "}poll();</script></body></html>"
            )

        @app.get("/subtitle")
        async def subtitle() -> JSONResponse:
            self._expire_if_needed()
            return JSONResponse({"text": self._text})

        return app

    def _clear(self) -> None:
        if self._expiry_handle is not None:
            self._expiry_handle.cancel()
        self._expiry_handle = None
        self._text = ""
        self._request_id = None
        self._expires_at = 0.0

    def _expire_if_needed(self) -> None:
        if self._request_id is not None and time.monotonic() >= self._expires_at:
            self._expired_total += 1
            self._clear()

    def _expire_timer(self) -> None:
        self._expiry_handle = None
        self._expire_if_needed()
        if self._request_id is not None:
            # Event-loop timers may fire one clock-resolution early. Retain no
            # text indefinitely merely because nobody polls the HTTP endpoint.
            self._expiry_handle = asyncio.get_running_loop().call_later(
                max(0.0, self._expires_at - time.monotonic()), self._expire_timer,
            )

    async def health_check(self) -> HealthStatus:
        self._expire_if_needed()
        if self._http_running():
            return HealthStatus.healthy(self.service_id, sink="ram_loopback")
        if self._on_subtitle is not None or self._event_bus is not None:
            return HealthStatus.healthy(self.service_id, sink="callback_or_event_bus")
        if self._require_delivery:
            return HealthStatus.unhealthy(self.service_id, "subtitle fallback has no working delivery sink")
        return HealthStatus.degraded(self.service_id, "subtitle fallback has no verified delivery sink")

    def get_metrics(self) -> dict[str, Any]:
        self._expire_if_needed()
        return {
            "tts_subtitle_total": self._subtitles_total,
            "tts_subtitle_delivery_failures_total": self._delivery_failures,
            "tts_subtitle_http_failures_total": self._http_failures,
            "tts_subtitle_http_running": self._http_running(),
            "tts_subtitle_retained_chars": len(self._text),
            "tts_subtitle_expired_total": self._expired_total,
        }

    @staticmethod
    def _turn_id(request_id: str) -> str:
        root, separator, suffix = request_id.rpartition("#")
        return root if separator and suffix.isdigit() else request_id

    async def cancel(self, request_id: str) -> None:
        if self._request_id is not None and self._turn_id(self._request_id) == self._turn_id(request_id):
            self._clear()

    async def cancel_all(self) -> None:
        self._clear()

    async def synthesize_stream(self, request: TTSRequest) -> AsyncIterator[AudioChunk]:
        self._subtitles_total += 1
        if len(request.text) > self._overlay_max_chars or len(request.request_id) > self._overlay_max_chars:
            self._delivery_failures += 1
            raise ValueError("subtitle text exceeds RAM capacity; no truncated delivery")
        self._log.info("tts_subtitle_fallback", request_id=request.request_id, chars=len(request.text))
        delivered = False
        if self._http_running():
            self._clear()
            self._request_id = request.request_id
            self._text = request.text
            self._expires_at = time.monotonic() + self._overlay_ttl_s
            self._expiry_handle = asyncio.get_running_loop().call_later(
                self._overlay_ttl_s, self._expire_timer,
            )
            delivered = True
        if self._on_subtitle is not None:
            try:
                self._on_subtitle(request.request_id, request.text)
                delivered = True
            except Exception as exc:
                self._log.warning("subtitle_sink_failed", error=type(exc).__name__)
        if self._event_bus is not None:
            try:
                self._event_bus.publish("tts_subtitle", {"request_id": request.request_id, "text": request.text})
                delivered = True
            except Exception as exc:
                self._log.warning("subtitle_event_bus_failed", error=type(exc).__name__)
        if not delivered:
            self._delivery_failures += 1
            raise RuntimeError("subtitle fallback has no working delivery sink")
        yield AudioChunk(
            request_id=request.request_id, chunk_index=0, audio_bytes=b"",
            is_final=True, duration_ms=0,
        )
