"""Sanitize identifiers for local logs and shareable training datasets.

Data đem train KHÔNG được lẫn PII người xem:
- viewer_id → HMAC-SHA256 với salt local, không lưu ID gốc.
- email, phone, handle, secret URL, address, IP and common IDs → `[PII]`.

Làm từ ĐẦU (lúc ghi log), không sửa sau — data lỡ ghi PII coi như hỏng.
"""
from __future__ import annotations

import hashlib
import hmac
import math
import re
import secrets
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

# email
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
# số điện thoại VN/quốc tế (8-15 chữ số, cho phép +, space, -, dấu chấm)
_PHONE_RE = re.compile(r"(?<!\w)(?:\+?\d[\d .\-]{7,14}\d)(?!\w)")
# token/khoá dài (≥20 ký tự chữ+số liền, kiểu api key)
_TOKEN_RE = re.compile(r"\b[A-Za-z0-9_\-]{20,}\b")
_HANDLE_RE = re.compile(r"(?<![\w@])@[A-Za-z0-9_][A-Za-z0-9_.-]{1,31}\b")
_URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)
_IP_RE = re.compile(
    r"(?<!\d)(?:25[0-5]|2[0-4]\d|1?\d?\d)"
    r"(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?!\d)"
)
_LABELED_ID_RE = re.compile(
    r"(?i)\b(CCCD|CMND|passport|hộ\s*chiếu|ID)\s*[:#-]?\s*[A-Z0-9][A-Z0-9-]{5,}\b"
)
_LABELED_NAME_RE = re.compile(
    r"(?i)\b(tên\s+(?:tôi|mình|em)\s+là|họ\s*và\s*tên|full\s*name|name)"
    r"\s*[:=-]?\s*[\wÀ-ỹ]+(?:\s+[\wÀ-ỹ]+){0,3}"
)
_ADDRESS_RE = re.compile(
    r"(?i)\b(địa\s*chỉ|address)\s*[:=-]?\s*[^,;\n]{5,100}"
)
_SECRET_QUERY_KEYS = {
    "access_token", "api_key", "apikey", "auth", "code", "key", "password",
    "secret", "session", "signature", "sig", "token",
}

_MASK = "[PII]"
_PROCESS_SALT = secrets.token_bytes(32)
_LOCAL_SALT = _PROCESS_SALT


def configure_hash_salt(path: str | Path) -> Path:
    """Load or create the local HMAC salt. The path must stay ignored by git."""
    salt_path = Path(path)
    salt_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with salt_path.open("xb") as stream:
            stream.write(secrets.token_bytes(32))
    except FileExistsError:
        pass
    return load_existing_hash_salt(salt_path)


def load_existing_hash_salt(path: str | Path) -> Path:
    """Load a required existing key, without mkdir, creation or a probe/read race fallback."""
    global _LOCAL_SALT
    salt_path = Path(path)
    salt = salt_path.read_bytes()
    if len(salt) < 32:
        raise ValueError("privacy hash salt must contain at least 32 bytes")
    _LOCAL_SALT = salt
    return salt_path


def hash_viewer_id(viewer_id: str | None, *, salt: bytes | None = None) -> str | None:
    """Return a non-reversible, locally salted viewer pseudonym."""
    if not viewer_id:
        return None
    key = salt or _LOCAL_SALT
    digest = hmac.new(key, str(viewer_id).encode("utf-8"), hashlib.sha256).hexdigest()[:16]
    return f"v_{digest}"


def pseudonymize_viewer_id(viewer_id: str | None) -> str | None:
    """Normalize a raw or canonical viewer reference without hashing twice."""
    if viewer_id and re.fullmatch(r"v_[0-9a-f]{16}", viewer_id):
        return viewer_id
    return hash_viewer_id(viewer_id)


# Runtime diagnostics are not training data. This is a closed wire projection,
# not a blacklist/PII heuristic: unknown fields and arbitrary objects never persist.
_METADATA_TEXT = frozenset({
    "user_text", "mai_text", "context_block", "chosen", "rejected", "original",
    "corrected", "corrected_text", "reason", "summary", "error", "exception",
    "stack", "stack_info", "alias", "text", "message", "msg", "description",
    "resolution", "prompt", "speech", "pause_reason",
})
_METADATA_REFS = frozenset({
    "session_id", "request_id", "event_id", "incident_id", "thread_id", "goal_id",
    "source_event_id", "record_id", "outcome_id", "active_goal_ref", "prompt_id",
    "feature_id",
})
_METADATA_NUMBERS = frozenset({
    "schema_version", "turn_id", "count", "total", "chars", "tokens", "attempt",
    "attempts", "latency_ms", "duration_ms", "ttft_ms", "ttfa_ms", "history_len",
    "level_used", "parse_ok", "was_regen", "raw_had_mood_block", "delivered",
    "passed", "fail_open", "checked", "failed", "enabled", "available", "healthy", "ok",
    "pending", "pid", "port", "managed", "mood_intensity", "confidence", "revision",
    "vui", "buon", "buc", "bon_chon", "nguong", "score", "bytes", "elapsed_ms",
})
_METADATA_CONTAINERS = frozenset({
    "mood_state", "mood_cause", "filter_verdict", "prompt_ref", "metrics", "details",
})
_METADATA_CODE_FIELDS = frozenset({
    "event", "kind", "record_type", "source", "level", "mode", "status", "severity",
    "action", "target", "outcome", "component", "trigger_type", "event_category",
    "rating", "mood_dominant", "persona_version", "architecture_version",
    "context_schema_version", "agenda_policy_version", "state", "from", "to", "error_type",
})
_METADATA_CODES = frozenset({
    "generation_attempt", "delivery_outcome", "quarantine", "preference_metadata",
    "chat_reply", "director_read", "directed", "ambient", "turn", "delivery",
    "chat_normal", "chat_question", "chat_donation", "donation", "filter", "dedup",
    "events", "pref_pairs", "operator_audit", "live_incident", "ratings", "corrections",
    "debug", "info", "warning", "error", "critical", "audio", "subtitle", "mixed",
    "none", "cancelled", "open", "monitoring", "resolved", "pending", "completed",
    "failed", "rejected", "success", "pause", "resume", "agent", "emergency",
    "already_paused", "already_running", "good", "bad", "flag", "vui", "buon",
    "buc", "bon_chon", "nguong", "neutral", "mai-agent-v1", "mai-context-v1",
    "mai-agenda-v1", "incident_opened", "incident_resolved", "llm_cancelled",
    "tts_subtitle_fallback", "record_quarantined", "turn_log_failed",
    "delivery_outcome_log_failed", "pref_pair_log_failed", "filter_regen_recovered",
    "filter_regen_failed", "director_loop_ready", "llama_server_started",
    "llama_server_stopping", "llama_server_starting", "llama_server_already_up",
    "state_transition", "filter_hit", "fallback_triggered", "healthy", "unhealthy",
    "degraded", "stopped", "unknown", "idle", "listening", "thinking", "speaking",
    "persona_break", "profanity", "sensitive_topic", "privacy", "prompt_injection",
    "RuntimeError", "ValueError", "TypeError", "OSError", "TimeoutError",
    "PermissionError", "CancelledError", "ConnectionError", "FileNotFoundError",
    "IDLE", "LISTENING", "THINKING", "SPEAKING", "manipulation", "explicit", "harmful",
    "low", "medium", "high", "allow", "regenerate", "replace", "block", "fallback_recovered",
    "llm", "tts", "input", "dashboard", "restart", "alert",
    "feature_toggle", "enable", "disable", "on", "off", "blocked", "error", "disabled",
})


def metadata_reference(value: str) -> str:
    """Stable opaque diagnostic reference; never an execution or permission token."""
    if re.fullmatch(r"r_[0-9a-f]{16}", value):
        return value
    # Keep the namespace used by metadata-only shutdown snapshots before this
    # shared boundary existed, so old snapshot references still identify logs.
    hashed = hash_viewer_id("shutdown-reference:" + value)
    assert hashed is not None
    return "r_" + hashed[2:]


def metadata_record(record: dict[str, object]) -> dict[str, object]:
    """Copy only closed diagnostic metadata, without mutating or stringifying RAM data."""
    if not isinstance(record, dict):
        raise TypeError("runtime metadata requires a mapping")
    result: dict[str, object] = {}
    for key, value in record.items():
        if key == "error" and isinstance(value, str) and value in _METADATA_CODES:
            result[key] = value
        elif key in _METADATA_TEXT:
            result[key] = None
        elif key in _METADATA_NUMBERS:
            if value is None or type(value) in (bool, int) or (
                type(value) is float and math.isfinite(value)
            ):
                result[key] = value
        elif key == "viewer_id":
            if value is None or isinstance(value, str):
                result[key] = pseudonymize_viewer_id(value)
        elif key in _METADATA_REFS:
            if value is None:
                result[key] = None
            elif isinstance(value, str):
                result[key] = metadata_reference(value)
            elif type(value) is int:
                result[key] = metadata_reference(str(value))
        elif key in _METADATA_CODE_FIELDS:
            if value is None:
                result[key] = None
            elif isinstance(value, str):
                result[key] = value if value in _METADATA_CODES else metadata_reference(value)
        elif key in {"timestamp", "ts", "at"}:
            # Timestamp normalization belongs to the writer, not arbitrary text serialization.
            from datetime import datetime, timezone

            try:
                parsed = None
                if isinstance(value, datetime):
                    parsed = value
                elif isinstance(value, str):
                    parsed = datetime.fromisoformat(value)
            except ValueError:
                parsed = None
            if parsed is not None:
                result[key] = parsed.replace(tzinfo=parsed.tzinfo or timezone.utc).isoformat()
        elif key in _METADATA_CONTAINERS and isinstance(value, dict):
            result[key] = metadata_record(value)
        elif key in {"evidence_refs", "outcome_refs"} and isinstance(value, (list, tuple)):
            result[key] = [metadata_reference(ref) for ref in value if isinstance(ref, str)]
        elif key == "categories" and isinstance(value, (list, tuple)):
            result[key] = [item if item in _METADATA_CODES else metadata_reference(item)
                           for item in value if isinstance(item, str)]
    return result


def mask_pii(text: str | None) -> str | None:
    """Mask common direct identifiers. None/empty remains unchanged; never raises."""
    return mask_pii_with_count(text)[0]


def mask_known_identifier(text: str | None, identifier: str | None) -> str | None:
    """Mask an identifier known from structured metadata, such as a display name."""
    if not text or not identifier or len(identifier.strip()) < 2:
        return text
    try:
        return re.sub(re.escape(identifier.strip()), _MASK, text, flags=re.IGNORECASE)
    except Exception:
        return text


def mask_pii_with_count(text: str | None) -> tuple[str | None, int]:
    """Return sanitized text and number of substitutions for dry-run reporting."""
    if not text:
        return text, 0
    try:
        count = 0
        t, n = _EMAIL_RE.subn(_MASK, text)
        count += n
        t, n = _mask_sensitive_urls(t)
        count += n
        t, n = _IP_RE.subn(_MASK, t)
        count += n
        t, n = _PHONE_RE.subn(_MASK, t)
        count += n
        t, n = _LABELED_ID_RE.subn(lambda m: f"{m.group(1)} {_MASK}", t)
        count += n
        t, n = _LABELED_NAME_RE.subn(lambda m: f"{m.group(1)} {_MASK}", t)
        count += n
        t, n = _ADDRESS_RE.subn(lambda m: f"{m.group(1)} {_MASK}", t)
        count += n
        t, n = _HANDLE_RE.subn(_MASK, t)
        count += n
        t, n = _TOKEN_RE.subn(_MASK, t)
        count += n
        return t, count
    except Exception:
        return text, 0


def _mask_sensitive_urls(text: str) -> tuple[str, int]:
    count = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal count
        url = match.group(0)
        try:
            query_keys = {key.lower() for key, _value in parse_qsl(urlsplit(url).query)}
            if not query_keys & _SECRET_QUERY_KEYS:
                return url
        except Exception:
            pass
        count += 1
        return _MASK

    return _URL_RE.sub(replace, text), count
