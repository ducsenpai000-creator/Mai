"""Ordered, idempotent graceful shutdown with an atomic runtime snapshot."""
from __future__ import annotations

import asyncio
import inspect
import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from interfaces.base import HealthStatus
from interfaces.operations import RecoveryAction, ShutdownCoordinatorService
from services.data.sanitize import metadata_reference


SnapshotProvider = Callable[[], dict[str, Any]]

# Closed diagnostic schema. Unknown fields, mapping keys and free text are omitted,
# including duplicates of chat inside authoritative state, goals or thread metadata.
_METADATA_CONTAINERS = frozenset({
    "runtime", "agent", "authoritative_state", "world", "self", "capabilities",
    "action_mock", "local_action_adapters", "execution_outcomes", "continuity",
    "embodiment", "external_executors", "external_actions", "perception", "ingress",
    "director_v2_shadow", "director_v2_takeover", "trajectories", "goals", "active",
    "candidates", "suspended", "health_supervisor", "operations", "emergency",
    "incidents", "turn_journal", "cognitive_brain_shadow", "turn_kernel", "decisions",
    "metrics", "open_threads", "recent_events", "recent", "targets",
    "llm_main", "input_router", "tts_primary", "tts", "dashboard",
    "shutdown_errors_before_snapshot",
})
_METADATA_NUMBERS = frozenset({
    "schema_version", "privacy_schema_version", "metadata_only", "revision", "count",
    "total", "available", "running", "enabled", "online", "paused", "latched",
    "connected", "healthy", "known", "confidence", "pending", "pending_count",
    "consecutive_failures", "restarts_total", "next_retry_at", "circuit_open",
    "dashboard_enabled", "tts_enabled", "controls_available", "unresolved",
    "runtime_running", "runtime_tts_enabled", "runtime_memory_enabled",
    "runtime_semantic_memory_requested", "runtime_autonomy_enabled", "runtime_filter_enabled",
    "continuity_commit_total", "continuity_inconsistency_total", "llm_requests_total",
    "llm_errors_total", "llm_last_ttft_ms", "tts_last_ttfa_ms", "tts_pipeline_requests_total",
    "tts_pipeline_pending_invocations", "audio_chunks_played", "audio_chunks_dropped",
    "audio_chunks_failed", "memory_fb_primary_available",
})
_METADATA_REFS = frozenset({
    "active_goal_ref", "goal_id", "thread_id", "event_id", "session_id", "request_id",
    "turn_id", "source_event_id", "record_id", "incident_id", "outcome_id", "parent_thread_id",
})
_METADATA_REF_LISTS = frozenset({"evidence_refs", "outcome_refs"})
_METADATA_TIMES = frozenset({"captured_at", "observed_at", "updated_at"})
_METADATA_ENUMS: dict[str, frozenset[str]] = {
    "state": frozenset({"healthy", "unhealthy", "degraded", "stopped", "unknown", "active",
                        "suspended", "completed", "cancelled", "failed", "pending"}),
    "status": frozenset({"open", "resolved", "completed", "completed_with_errors", "failed",
                         "pending", "active", "suspended", "cancelled", "committed", "aborted"}),
    "mode": frozenset({"live", "standalone", "off", "shadow", "brain", "compatibility"}),
    "health": frozenset({"healthy", "unhealthy", "degraded", "stopped", "unknown"}),
    "severity": frozenset({"low", "medium", "high", "critical", "info", "warning", "error"}),
    "disposition": frozenset({"COMMITTED", "ABORTED", "INCONSISTENT", "DUPLICATE"}),
    "delivery_mode": frozenset({"audio", "subtitle", "mixed", "none", "cancelled"}),
    "kind": frozenset({"question", "promise", "story", "chat_received", "donation_received",
                       "speech_completed"}),
    "error": frozenset({"timeout", "RuntimeError", "ValueError", "TypeError", "OSError",
                        "TimeoutError", "PermissionError", "CancelledError"}),
    "step": frozenset({"pause_recovery", "stop_driver", "stop_input", "stop_speech",
                       "close_dashboard", "stop_supporting_services", "stop_llm",
                       "stop_agent_state", "animation", "snapshot", "flush_logging"}),
}


def _diagnostic_ref(value: str) -> str:
    return metadata_reference(value)


def metadata_snapshot(value: dict[str, Any]) -> dict[str, Any]:
    """Project diagnostic metadata without mutating the canonical RAM snapshot."""
    if not isinstance(value, dict):
        raise TypeError("snapshot must be a mapping")
    output: dict[str, Any] = {}
    for key, item in value.items():
        if key in _METADATA_NUMBERS:
            if item is None or type(item) in (bool, int) or (type(item) is float and math.isfinite(item)):
                output[key] = item
        elif key in _METADATA_REFS:
            if item is None:
                output[key] = None
            elif isinstance(item, str) and item:
                output[key] = _diagnostic_ref(item)
            elif type(item) is int:
                output[key] = _diagnostic_ref(str(item))
        elif key in _METADATA_REF_LISTS and isinstance(item, (list, tuple)):
            output[key] = [_diagnostic_ref(ref) for ref in item if isinstance(ref, str) and ref]
        elif key in _METADATA_ENUMS:
            if isinstance(item, str) and item in _METADATA_ENUMS[key]:
                output[key] = item
        elif key in _METADATA_TIMES and isinstance(item, str) and "T" in item:
            try:
                timestamp = datetime.fromisoformat(item)
            except ValueError:
                continue
            if timestamp.tzinfo is not None:
                output[key] = timestamp.isoformat()
        elif key in _METADATA_CONTAINERS:
            if isinstance(item, dict):
                output[key] = metadata_snapshot(item)
            elif isinstance(item, (list, tuple)):
                output[key] = [metadata_snapshot(row) for row in item if isinstance(row, dict)]
            elif item is None:
                output[key] = None
    return output


@dataclass(frozen=True)
class ShutdownStep:
    name: str
    callback: RecoveryAction


class ShutdownCoordinator(ShutdownCoordinatorService):
    service_id = "shutdown_coordinator"

    def __init__(
        self,
        *,
        timeout_s: float,
        snapshot_path: str | Path,
        snapshot_provider: SnapshotProvider,
        flush_callback: Callable[[], Any] | None = None,
        metrics: Any = None,
    ) -> None:
        if timeout_s <= 0:
            raise ValueError("shutdown timeout must be positive")
        self.timeout_s = float(timeout_s)
        self.snapshot_path = Path(snapshot_path)
        self._snapshot_provider = snapshot_provider
        self._flush_callback = flush_callback
        self._metrics = metrics
        self._steps: list[ShutdownStep] = []
        self._running = False
        self._completed = False
        self._lock = asyncio.Lock()
        self._report: dict[str, Any] | None = None
        self._snapshots_written_total = 0

    @classmethod
    def from_loader(
        cls,
        loader: Any,
        *,
        snapshot_provider: SnapshotProvider,
        flush_callback: Callable[[], Any] | None = None,
        metrics: Any = None,
    ) -> "ShutdownCoordinator":
        return cls(
            timeout_s=float(loader.get("operations", "shutdown.timeout_s", 15.0)),
            snapshot_path=loader.get(
                "operations", "shutdown.snapshot_file",
                "logs/operations/last_runtime_snapshot.json",
            ),
            snapshot_provider=snapshot_provider,
            flush_callback=flush_callback,
            metrics=metrics,
        )

    def register_step(self, name: str, callback: RecoveryAction) -> None:
        clean = " ".join(str(name).split())
        if not clean or any(step.name == clean for step in self._steps):
            raise ValueError("shutdown step name must be non-empty and unique")
        self._steps.append(ShutdownStep(clean, callback))

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        await self.shutdown()

    async def health_check(self) -> HealthStatus:
        if self._completed:
            return HealthStatus.stopped(self.service_id)
        if self._running:
            return HealthStatus.healthy(self.service_id, steps=len(self._steps))
        return HealthStatus.stopped(self.service_id)

    def get_metrics(self) -> dict[str, Any]:
        report = self._report or {}
        return {
            "shutdown_completed": self._completed,
            "shutdown_steps_total": len(self._steps),
            "shutdown_step_errors": len(report.get("errors") or []),
            "shutdown_snapshot_metadata_only": True,
            "shutdown_snapshots_written_total": self._snapshots_written_total,
        }

    async def shutdown(self) -> dict[str, Any]:
        async with self._lock:
            if self._report is not None:
                return dict(self._report)
            self._running = False
            started = datetime.now(timezone.utc)
            completed_steps: list[str] = []
            errors: list[dict[str, str]] = []
            for step in self._steps:
                try:
                    await asyncio.wait_for(step.callback(), timeout=self.timeout_s)
                    completed_steps.append(step.name)
                    self._record(step.name, "completed")
                except asyncio.TimeoutError:
                    errors.append({"step": step.name, "error": "timeout"})
                    self._record(step.name, "timeout")
                except Exception as exc:
                    errors.append({"step": step.name, "error": type(exc).__name__})
                    self._record(step.name, "failed")
            snapshot_error = self._write_snapshot(errors)
            if snapshot_error is not None:
                errors.append({"step": "snapshot", "error": snapshot_error})
                self._record("snapshot", "failed")
            else:
                completed_steps.append("snapshot")
                self._record("snapshot", "completed")
            flush_error = await self._flush()
            if flush_error is not None:
                errors.append({"step": "flush_logging", "error": flush_error})
                self._record("flush_logging", "failed")
            else:
                completed_steps.append("flush_logging")
                self._record("flush_logging", "completed")
            self._completed = True
            self._report = {
                "schema_version": 1,
                "status": "completed" if not errors else "completed_with_errors",
                "started_at": started.isoformat(),
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "completed_steps": completed_steps,
                "errors": errors,
                "snapshot_path": str(self.snapshot_path),
            }
            return dict(self._report)

    def _write_snapshot(self, errors: list[dict[str, str]]) -> str | None:
        try:
            value = {
                **metadata_snapshot(self._snapshot_provider()),
                "schema_version": 1,
                "privacy_schema_version": 1,
                "metadata_only": True,
                "captured_at": datetime.now(timezone.utc).isoformat(),
                "shutdown_errors_before_snapshot": metadata_snapshot({
                    "shutdown_errors_before_snapshot": errors,
                })["shutdown_errors_before_snapshot"],
            }
            self.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.snapshot_path.with_suffix(self.snapshot_path.suffix + ".tmp")
            temporary.write_text(
                json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            temporary.replace(self.snapshot_path)
            self._snapshots_written_total += 1
            return None
        except Exception as exc:
            return type(exc).__name__

    async def _flush(self) -> str | None:
        if self._flush_callback is None:
            return None
        try:
            value = self._flush_callback()
            if inspect.isawaitable(value):
                await asyncio.wait_for(value, timeout=self.timeout_s)
            return None
        except Exception as exc:
            return type(exc).__name__

    def _record(self, step: str, outcome: str) -> None:
        if self._metrics is not None and hasattr(self._metrics, "record_shutdown_step"):
            self._metrics.record_shutdown_step(step, outcome)
