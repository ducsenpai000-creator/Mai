from __future__ import annotations

import asyncio
from copy import deepcopy
import json
from pathlib import Path
import re
from typing import Any

import pytest

from services.operations.metrics import MetricsCollector
from services.operations.shutdown_coordinator import ShutdownCoordinator, metadata_snapshot


PRIVATE_SENTINEL = "SYNTHETIC_PRIVATE_CHAT tên Nguyễn Mẫu email viewer@example.invalid phone 0900000000"


def _private_runtime_snapshot() -> dict[str, Any]:
    agent = {
        "active_goal_ref": PRIVATE_SENTINEL,
        "topic": PRIVATE_SENTINEL,
        "current_topic": {"summary": PRIVATE_SENTINEL},
        "recap": PRIVATE_SENTINEL,
        "open_threads": [{
            "thread_id": PRIVATE_SENTINEL, "kind": "promise", "count": 3,
            "topic": PRIVATE_SENTINEL, "summary": PRIVATE_SENTINEL,
            "payload": {"text": PRIVATE_SENTINEL},
        }],
        "recent_events": [{
            "event_id": PRIVATE_SENTINEL, "kind": "chat_received",
            "text": PRIVATE_SENTINEL, "payload": {"message": PRIVATE_SENTINEL},
        }],
    }
    goal = {
        "goal_id": PRIVATE_SENTINEL, "status": "active",
        "description": PRIVATE_SENTINEL, "reason": PRIVATE_SENTINEL,
        "metadata": {"description": PRIVATE_SENTINEL},
        "success_condition": PRIVATE_SENTINEL, "evidence_refs": [PRIVATE_SENTINEL],
    }
    return {
        "schema_version": 99, "privacy_schema_version": 99, "metadata_only": False,
        "captured_at": "2050-01-01T00:00:00+00:00",
        "runtime": {"running": True, "mode": "live", "reason": PRIVATE_SENTINEL},
        "agent": agent,
        "goals": {"active": goal, "candidates": [deepcopy(goal)], "suspended": []},
        "authoritative_state": {
            "agent": deepcopy(agent), "goals": {"active": deepcopy(goal)},
            "recap": PRIVATE_SENTINEL,
        },
        "world": {"known": True, "summary": PRIVATE_SENTINEL, "description": PRIVATE_SENTINEL},
        "decisions": [{"mode": "compatibility", "request_id": PRIVATE_SENTINEL,
                       "speech": PRIVATE_SENTINEL, "reason": PRIVATE_SENTINEL}],
        "metrics": {"llm_requests_total": 7, "llm_last_ttft_ms": 1.5, PRIVATE_SENTINEL: 1},
        "operations": {"available": True, "pause_reason": PRIVATE_SENTINEL,
                       "audit": [{"reason": PRIVATE_SENTINEL}]},
        "incidents": {"recent": [{"incident_id": PRIVATE_SENTINEL, "status": "open",
                                    "summary": PRIVATE_SENTINEL}]},
        "shutdown_errors_before_snapshot": [{"step": "snapshot", "error": PRIVATE_SENTINEL}],
        PRIVATE_SENTINEL: {"count": 8},
    }


async def test_shutdown_is_ordered_atomic_flushed_and_idempotent(tmp_path: Path) -> None:
    order: list[str] = []
    flushed = 0

    def step(name: str):
        async def run() -> None:
            order.append(name)
        return run

    def flush() -> None:
        nonlocal flushed
        flushed += 1

    path = tmp_path / "operations" / "snapshot.json"
    coordinator = ShutdownCoordinator(
        timeout_s=0.2, snapshot_path=path,
        snapshot_provider=lambda: {"agent": {"active_goal_ref": "goal:1"}},
        flush_callback=flush,
    )
    coordinator.register_step("input", step("input"))
    coordinator.register_step("speech", step("speech"))
    first = await coordinator.shutdown()
    second = await coordinator.shutdown()

    assert order == ["input", "speech"]
    assert flushed == 1
    assert first == second
    assert first["status"] == "completed"
    assert not path.with_suffix(".json.tmp").exists()
    snapshot = json.loads(path.read_text(encoding="utf-8"))
    assert re.fullmatch(r"r_[0-9a-f]{16}", snapshot["agent"]["active_goal_ref"])
    assert snapshot["agent"]["active_goal_ref"] != "goal:1"
    assert snapshot["metadata_only"] is True
    assert coordinator.get_metrics()["shutdown_snapshots_written_total"] == 1


async def test_step_failure_and_timeout_do_not_skip_later_cleanup(tmp_path: Path) -> None:
    completed = False
    metrics = MetricsCollector()

    async def fail() -> None:
        raise RuntimeError("broken")

    async def hang() -> None:
        await asyncio.sleep(1)

    async def final() -> None:
        nonlocal completed
        completed = True

    coordinator = ShutdownCoordinator(
        timeout_s=0.01, snapshot_path=tmp_path / "snapshot.json",
        snapshot_provider=lambda: {}, metrics=metrics,
    )
    coordinator.register_step("fail", fail)
    coordinator.register_step("hang", hang)
    coordinator.register_step("final", final)
    report = await coordinator.shutdown()

    assert completed is True
    assert report["status"] == "completed_with_errors"
    assert report["errors"] == [
        {"step": "fail", "error": "RuntimeError"},
        {"step": "hang", "error": "timeout"},
    ]
    assert metrics.shutdown_snapshot()["final:completed"] == 1


async def test_health_transitions_to_stopped_after_shutdown(tmp_path: Path) -> None:
    coordinator = ShutdownCoordinator(
        timeout_s=0.1, snapshot_path=tmp_path / "snapshot.json",
        snapshot_provider=lambda: {},
    )
    await coordinator.start()
    assert (await coordinator.health_check()).is_ok
    await coordinator.stop()
    assert not (await coordinator.health_check()).is_ok


async def test_shutdown_persists_only_closed_metadata_without_mutating_live_ram(tmp_path: Path) -> None:
    source = _private_runtime_snapshot()
    original = deepcopy(source)
    path = tmp_path / "snapshot.json"
    coordinator = ShutdownCoordinator(
        timeout_s=0.1, snapshot_path=path, snapshot_provider=lambda: source,
    )

    report = await coordinator.shutdown()
    persisted_text = path.read_text(encoding="utf-8")
    persisted = json.loads(persisted_text)

    assert report["status"] == "completed"
    for marker in ("SYNTHETIC_PRIVATE_CHAT", "Nguyễn Mẫu", "viewer@example.invalid", "0900000000"):
        assert marker not in persisted_text
    assert source == original
    assert persisted["schema_version"] == persisted["privacy_schema_version"] == 1
    assert persisted["metadata_only"] is True
    assert persisted["captured_at"] != original["captured_at"]
    assert persisted["shutdown_errors_before_snapshot"] == []
    assert persisted["runtime"] == {"running": True, "mode": "live"}
    assert persisted["metrics"] == {"llm_requests_total": 7, "llm_last_ttft_ms": 1.5}
    opaque = persisted["agent"]["active_goal_ref"]
    assert re.fullmatch(r"r_[0-9a-f]{16}", opaque)
    assert persisted["agent"]["open_threads"][0] == {
        "thread_id": opaque, "kind": "promise", "count": 3,
    }
    assert persisted["agent"]["recent_events"][0] == {"event_id": opaque, "kind": "chat_received"}
    assert persisted["goals"]["active"] == {
        "goal_id": opaque, "status": "active", "evidence_refs": [opaque],
    }
    assert persisted["authoritative_state"]["agent"] == persisted["agent"]
    assert persisted["authoritative_state"]["goals"]["active"] == persisted["goals"]["active"]
    assert metadata_snapshot(persisted) == persisted
    assert coordinator.get_metrics()["shutdown_snapshot_metadata_only"] is True
    assert coordinator.get_metrics()["shutdown_snapshots_written_total"] == 1


def test_metadata_refs_are_salted_consistent_and_idempotent_without_stringifying_objects(monkeypatch) -> None:
    from services.data import sanitize

    class NoStringification:
        def __str__(self) -> str:
            raise AssertionError("private object must never be serialized")

    raw = {
        "agent": {"active_goal_ref": "goal:private", "event_id": "goal:private",
                  "request_id": NoStringification(), "speech": NoStringification()},
        "metrics": {"llm_requests_total": 4, "llm_last_ttft_ms": float("inf"),
                    "tts_last_ttfa_ms": float("nan"), "llm_errors_total": "secret"},
        "world": {"known": True, "confidence": 0.4, "state": "healthy"},
        "runtime": {"mode": PRIVATE_SENTINEL},
        "goals": {"active": {"goal_id": "r_0123456789abcdef", "status": PRIVATE_SENTINEL}},
    }
    monkeypatch.setattr(sanitize, "_LOCAL_SALT", b"synthetic-test-salt-A-32-bytes!!!!")
    first = metadata_snapshot(raw)
    second = metadata_snapshot(raw)
    assert first == second == metadata_snapshot(first)
    assert first["agent"]["active_goal_ref"] == first["agent"]["event_id"]
    assert re.fullmatch(r"r_[0-9a-f]{16}", first["agent"]["active_goal_ref"])
    assert first["metrics"] == {"llm_requests_total": 4}
    assert first["world"] == {"known": True, "confidence": 0.4, "state": "healthy"}
    assert first["runtime"] == {}
    assert first["goals"]["active"] == {"goal_id": "r_0123456789abcdef"}
    monkeypatch.setattr(sanitize, "_LOCAL_SALT", b"synthetic-test-salt-B-32-bytes!!!!")
    assert metadata_snapshot(raw)["agent"]["active_goal_ref"] != first["agent"]["active_goal_ref"]


def test_every_declared_metadata_container_drops_free_text_and_private_mapping_keys() -> None:
    from services.operations.shutdown_coordinator import _METADATA_CONTAINERS

    for section in sorted(_METADATA_CONTAINERS):
        source = {section: {
            "schema_version": 1, "count": 2, "running": True,
            "summary": PRIVATE_SENTINEL, "topic": PRIVATE_SENTINEL,
            "current_topic": {"summary": PRIVATE_SENTINEL},
            "active": {"goal_id": PRIVATE_SENTINEL, "metadata": {"text": PRIVATE_SENTINEL}},
            "recent": [{"event_id": PRIVATE_SENTINEL, "text": PRIVATE_SENTINEL,
                        "payload": {"message": PRIVATE_SENTINEL}}],
            PRIVATE_SENTINEL: {"count": 7},
        }}
        original = deepcopy(source)
        projected = metadata_snapshot(source)

        assert projected[section]["count"] == 2, section
        assert projected[section]["running"] is True, section
        assert "SYNTHETIC_PRIVATE_CHAT" not in json.dumps(projected, ensure_ascii=False), section
        assert "viewer@example.invalid" not in json.dumps(projected, ensure_ascii=False), section
        assert source == original, section


@pytest.mark.parametrize("failure_point", ["provider", "projection"])
async def test_snapshot_failure_never_falls_back_to_raw_or_replaces_safe_file(
    tmp_path: Path, monkeypatch, failure_point: str,
) -> None:
    from services.operations import shutdown_coordinator as module

    path = tmp_path / "snapshot.json"
    previous = '{"metadata_only": true, "runtime": {"running": false}}'
    path.write_text(previous, encoding="utf-8")
    cleanup: list[str] = []

    async def stop_input() -> None:
        cleanup.append("input")

    def unavailable(*_args):
        raise ValueError(PRIVATE_SENTINEL)

    provider = unavailable if failure_point == "provider" else _private_runtime_snapshot
    if failure_point == "projection":
        monkeypatch.setattr(module, "metadata_snapshot", unavailable)
    coordinator = ShutdownCoordinator(
        timeout_s=0.1, snapshot_path=path, snapshot_provider=provider,
        flush_callback=lambda: cleanup.append("flush"),
    )
    coordinator.register_step("stop_input", stop_input)
    report = await coordinator.shutdown()

    assert report["status"] == "completed_with_errors"
    assert report["errors"] == [{"step": "snapshot", "error": "ValueError"}]
    assert cleanup == ["input", "flush"]
    assert path.read_text(encoding="utf-8") == previous
    assert not path.with_suffix(".json.tmp").exists()
    assert PRIVATE_SENTINEL not in str(report)
    assert coordinator.get_metrics()["shutdown_snapshots_written_total"] == 0
