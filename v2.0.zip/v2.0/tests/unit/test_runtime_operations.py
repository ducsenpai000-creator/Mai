from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from interfaces.base import HealthStatus
from orchestrator.runtime_operations import build_health_supervisor
from services.operations.health_supervisor import HealthSupervisor, SupervisorPolicy


async def test_primary_tts_recovery_is_separate_from_deliverable_pipeline_health(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class Service:
        def __init__(self, healthy: bool = True) -> None:
            self.healthy = healthy
            self.starts = 0
            self.stops = 0

        async def health_check(self) -> HealthStatus:
            return HealthStatus.healthy("fake") if self.healthy else HealthStatus.unhealthy("fake", "primary unavailable")

        async def start(self) -> None:
            self.starts += 1
            self.healthy = True

        async def stop(self) -> None:
            self.stops += 1

    class Pipeline:
        async def health_check(self) -> HealthStatus:
            return HealthStatus.healthy("tts", delivery_mode="subtitle", audio_available=False)

    monkeypatch.setattr(
        HealthSupervisor, "from_loader",
        classmethod(lambda cls, loader, **kwargs: cls(SupervisorPolicy(unhealthy_threshold=1), **kwargs)),
    )
    primary = Service(healthy=False)
    incidents = []
    loader = SimpleNamespace(get=lambda name, key, default=None: default)
    supervisor = build_health_supervisor(
        enabled=True, loader=loader, metrics=None,
        incident_log=SimpleNamespace(record_incident=lambda **kwargs: incidents.append(kwargs)),
        turn_lock=asyncio.Lock(), llm_svc=Service(), llama_process_manager=None,
        router=Service(), tts_svc=primary, tts_pipeline=Pipeline(),
        dashboard_ref=None, dashboard_server=None,
    )
    statuses = await supervisor.check_once()
    assert set(statuses) == {"llm_main", "input_router", "tts_primary", "tts"}
    assert statuses["tts_primary"].is_ok is False
    assert statuses["tts"].is_ok is True
    assert statuses["tts"].details["delivery_mode"] == "subtitle"
    assert primary.starts == primary.stops == 1
    targets = supervisor.snapshot()["targets"]
    assert targets["tts_primary"]["last_action"] == "restarted"
    assert targets["tts"]["last_action"] == "healthy"
