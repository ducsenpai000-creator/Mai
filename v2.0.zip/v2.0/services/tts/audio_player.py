"""AudioPlayer — phát AudioChunk tuần tự, không overlap (Phase 4, 4.D).

Nhận `AudioChunk` (float32 mono PCM @ sample_rate), enqueue, phát tuần tự:
chunk N+1 chỉ bắt đầu khi N phát xong → KHÔNG overlap giữa turns (DoD P4).

Backend mặc định dùng OutputStream persistent; DSP và blocking device I/O chạy
trong `asyncio.to_thread`. Test inject backend để không mở device thật.
`cancel_current(request_id)` dừng ngay chunk đang phát + drop mọi chunk cùng
request_id còn trong queue.
"""
from __future__ import annotations

import asyncio
import contextlib
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np

from interfaces.tts import AudioChunk, PlaybackReceipt
from orchestrator.logger import get_logger
from services.tts.pitch import clamp_semitones, pitch_shift_samples


class AudioBackend(Protocol):
    """Backend phát audio synchronous. `play_blocking` phải chờ tới khi kết thúc."""

    def play_blocking(self, samples: np.ndarray, sample_rate: int) -> None: ...
    def stop(self) -> None: ...


@dataclass
class _PlaybackItem:
    chunk: AudioChunk
    receipt: PlaybackReceipt
    cancelled: threading.Event = field(default_factory=threading.Event)


class SounddeviceBackend:
    """Backend thật bằng sounddevice.

    Dùng OutputStream persistent + `stream.write` per chunk (KHÔNG `sd.play+sd.wait`
    per chunk — cách đó mở/đóng stream mỗi lần → click/gap giữa chunk).
    `stream.write` blocking khi buffer đầy → pacing gần realtime, không giật.
    `stop()` abort stream đang phát (dùng khi cancel_current).
    """

    def __init__(self, output_device: str | int | None = None) -> None:
        if isinstance(output_device, bool) or (
            output_device is not None and not isinstance(output_device, (str, int))
        ):
            raise ValueError("output_device must be a device name, index, or None")
        if isinstance(output_device, str) and (
            not output_device.strip() or output_device != output_device.strip()
        ):
            raise ValueError("output_device name must be trimmed and non-empty")
        if isinstance(output_device, int) and output_device < 0:
            raise ValueError("output_device index must be non-negative")
        self.output_device = output_device
        self._stream: Any = None
        self._sr: int | None = None
        self._state_lock = threading.Lock()
        self._generation = 0

    def _ensure_stream(self, sample_rate: int, cancelled: threading.Event) -> Any:
        import sounddevice as sd

        with self._state_lock:
            generation = self._generation
            if cancelled.is_set():
                return None
            if self._stream is not None and self._sr == sample_rate:
                return self._stream
            old_stream, self._stream = self._stream, None
            self._sr = None
        self._close_stream(old_stream)
        # Opening a device may block. Do not make emergency stop wait for it;
        # a candidate opened across cancellation must never become the sink.
        stream = sd.OutputStream(
            samplerate=sample_rate, channels=1, dtype="float32", blocksize=0,
            device=self.output_device,
        )
        with self._state_lock:
            stale = generation != self._generation or cancelled.is_set()
        if stale:
            self._close_stream(stream)
            return None
        try:
            stream.start()
        except BaseException:
            self._close_stream(stream)
            raise
        with self._state_lock:
            accepted = generation == self._generation and not cancelled.is_set()
            if accepted:
                self._stream = stream
                self._sr = sample_rate
        if not accepted:
            self._close_stream(stream)
            return None
        return stream

    def play_blocking(self, samples: np.ndarray, sample_rate: int) -> None:
        self.play_cancellable(samples, sample_rate, threading.Event())

    def play_cancellable(
        self, samples: np.ndarray, sample_rate: int, cancelled: threading.Event,
    ) -> bool:
        stream = self._ensure_stream(sample_rate, cancelled)
        if stream is None:
            return False
        if samples.ndim == 1:
            samples = samples.reshape(-1, 1)
        with self._state_lock:
            if cancelled.is_set() or self._stream is not stream:
                return False
        # write blocks khi buffer PortAudio đầy → giữ pacing gần realtime.
        # Không gọi wait() giữa chunk (đó là nguồn gap/click). Cuối turn, worker
        # xử chunk tiếp; giữa turn, Queue của AudioPlayer serialize.
        # stop() can abort this exact stream while write is blocked. Never look
        # up/reopen a replacement stream after this cancellation fence.
        stream.write(samples.astype("float32"))
        return not cancelled.is_set()

    def stop(self) -> None:
        # cancel_current: abort ngay + drop buffered
        self._teardown()

    def finish_request(self) -> None:
        """Drain device buffers at the sentence boundary before acknowledging delivery."""
        self.finish_cancellable(threading.Event())

    def finish_cancellable(self, cancelled: threading.Event) -> bool:
        with self._state_lock:
            stream = self._stream
            generation = self._generation
            if cancelled.is_set():
                return False
        if stream is not None:
            stream.stop()
            with self._state_lock:
                if cancelled.is_set() or generation != self._generation or self._stream is not stream:
                    return False
            stream.start()
            with self._state_lock:
                stale = cancelled.is_set() or generation != self._generation or self._stream is not stream
            if stale:
                self._close_stream(stream)
                return False
        return not cancelled.is_set()

    def _teardown(self) -> None:
        with self._state_lock:
            self._generation += 1
            stream, self._stream = self._stream, None
            self._sr = None
        self._close_stream(stream)

    @staticmethod
    def _close_stream(stream: Any) -> None:
        if stream is not None:
            try:
                stream.abort()
                stream.close()
            except Exception:
                pass


class AudioPlayer:
    def __init__(
        self,
        sample_rate: int = 24000,
        backend: AudioBackend | None = None,
        queue_maxsize: int = 128,
        pitch_semitones: float = 0.0,
        output_device: str | int | None = None,
    ) -> None:
        self.sample_rate = sample_rate
        self.pitch_semitones = clamp_semitones(pitch_semitones)
        self._backend: AudioBackend = backend or SounddeviceBackend(output_device)
        self._queue: asyncio.Queue[_PlaybackItem | _StopSentinel] = asyncio.Queue(maxsize=queue_maxsize)
        self._worker: asyncio.Task[None] | None = None
        self._running = False
        self._current_request_id: str | None = None
        self._current_item: _PlaybackItem | None = None
        self._cancelled_ids: set[str] = set()
        self._log = get_logger("audio_player")

        self.chunks_played = 0
        self.chunks_dropped = 0
        self.chunks_failed = 0
        self._pitch_warmup_ms: float | None = None

    async def start(self) -> None:
        if self._worker is None:
            if self.pitch_semitones != 0.0:
                started = time.perf_counter()
                # Initialize lazy DSP/JIT caches without writing a sample to the sink.
                await asyncio.to_thread(pitch_shift_samples, np.zeros(self.sample_rate, dtype=np.float32),
                                        self.sample_rate, self.pitch_semitones)
                self._pitch_warmup_ms = (time.perf_counter() - started) * 1000
            self._running = True
            self._worker = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        await self.cancel_all()
        self._running = False
        # đẩy None-marker để worker thoát vòng chờ queue
        try:
            self._queue.put_nowait(_STOP)  # type: ignore[arg-type]
        except asyncio.QueueFull:
            pass
        self._backend.stop()
        if self._worker is not None:
            try:
                await asyncio.wait_for(self._worker, timeout=3.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._worker.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await self._worker
            self._worker = None

    async def enqueue(self, chunk: AudioChunk) -> PlaybackReceipt:
        receipt: PlaybackReceipt = asyncio.get_running_loop().create_future()
        if not self._running or chunk.request_id in self._cancelled_ids:
            receipt.set_result(False)
            return receipt
        await self._queue.put(_PlaybackItem(chunk, receipt))
        return receipt

    async def cancel_current(self, request_id: str) -> None:
        """Đánh dấu request_id bị huỷ + stop chunk hiện tại (nếu cùng id)."""
        self._cancelled_ids.add(request_id)
        if self._current_request_id == request_id:
            self._cancel_active_item()
            self._backend.stop()
            self._current_request_id = None

    async def cancel_all(self) -> None:
        """Immediately stop playback and discard every queued audio chunk."""
        if self._current_request_id is not None:
            self._cancelled_ids.add(self._current_request_id)
        self._cancel_active_item()
        self._backend.stop()
        self._current_request_id = None
        while True:
            try:
                chunk = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            if isinstance(chunk, _PlaybackItem):
                chunk.cancelled.set()
                self._cancelled_ids.add(chunk.chunk.request_id)
                if not chunk.receipt.done():
                    chunk.receipt.set_result(False)

    @property
    def is_running(self) -> bool:
        return self._running and self._worker is not None and not self._worker.done()

    @property
    def is_playing(self) -> bool:
        return self._current_request_id is not None

    def get_metrics(self) -> dict[str, Any]:
        return {
            "audio_chunks_played": self.chunks_played,
            "audio_chunks_dropped": self.chunks_dropped,
            "audio_chunks_failed": self.chunks_failed,
            "audio_queue_size": self._queue.qsize(),
            "audio_is_playing": self.is_playing,
            "audio_pitch_semitones": self.pitch_semitones,
            "audio_pitch_warmup_ms": self._pitch_warmup_ms,
        }

    # ---------- worker ----------

    def _cancel_active_item(self) -> None:
        item = self._current_item
        if item is not None:
            item.cancelled.set()

    async def _loop(self) -> None:
        while self._running:
            try:
                item = await self._queue.get()
            except asyncio.CancelledError:
                return
            if item is _STOP:
                return
            if not isinstance(item, _PlaybackItem):
                continue  # ignore junk
            chunk = item.chunk
            played = False
            self._current_item = item
            try:
                played = await self._play_chunk(chunk, item.cancelled)
            finally:
                if self._current_item is item:
                    self._current_item = None
                if not item.receipt.done():
                    item.receipt.set_result(played)

    async def _play_chunk(self, chunk: AudioChunk, cancelled: threading.Event) -> bool:
        if chunk.request_id in self._cancelled_ids:
            self.chunks_dropped += 1
            return False
        try:
            if chunk.audio_bytes:
                samples = np.frombuffer(chunk.audio_bytes, dtype=np.float32)
                self._current_request_id = chunk.request_id
                played = await asyncio.to_thread(self._render_and_play, samples, cancelled)
                if not played or cancelled.is_set() or chunk.request_id in self._cancelled_ids:
                    self.chunks_dropped += 1
                    return False
                self.chunks_played += 1
            elif chunk.is_final:
                self._current_request_id = chunk.request_id
                finish_cancellable = getattr(self._backend, "finish_cancellable", None)
                if callable(finish_cancellable):
                    if not await asyncio.to_thread(finish_cancellable, cancelled):
                        return False
                else:
                    finish = getattr(self._backend, "finish_request", None)
                    if callable(finish) and not cancelled.is_set():
                        await asyncio.to_thread(finish)
                if self._current_request_id == chunk.request_id:
                    self._current_request_id = None
            return not cancelled.is_set() and chunk.request_id not in self._cancelled_ids
        except Exception as exc:
            self.chunks_failed += 1
            self._log.warning("audio_play_failed", error=type(exc).__name__)
            return False

    def _render_and_play(self, samples: np.ndarray, cancelled: threading.Event) -> bool:
        """Áp pitch-shift (nếu bật) rồi phát — chạy trong to_thread, không block loop."""
        if self.pitch_semitones != 0.0:
            samples = pitch_shift_samples(samples, self.sample_rate, self.pitch_semitones)
        if cancelled.is_set():
            return False
        play_cancellable = getattr(self._backend, "play_cancellable", None)
        if callable(play_cancellable):
            return bool(play_cancellable(samples, self.sample_rate, cancelled))
        self._backend.play_blocking(samples, self.sample_rate)
        return not cancelled.is_set()


class _StopSentinel:
    pass


_STOP = _StopSentinel()
