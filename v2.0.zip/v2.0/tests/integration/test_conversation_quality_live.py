"""Real content corpus through production generation/filter, not public delivery."""
from __future__ import annotations

import hashlib
import asyncio
import copy
import json
import math
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import pytest
import yaml

from interfaces.llm import LLMRequest, LLMToken, ViewerUtterance
from orchestrator.config_loader import CONFIG_FILES, ConfigLoader
from orchestrator.fallback_manager import FallbackManager
from services.data.sanitize import mask_pii
from services.evaluation.conversation_quality import ContentPolicy, automatic_checks, load_corpus
from services.evaluation.release_gate import inspect_source_state
from services.filter.regenerator import FilterRegenerator
from services.filter.rule_filter import RuleFilter
from services.llm.canned_response import CannedResponder
from services.llm.llama_cpp_llm import LlamaCppLLMService
from services.llm.llm_turn import LLMTurnRunner
from services.llm.process_manager import LlamaServerConfig, LlamaServerProcessManager
from services.llm.prompt_manager import PromptManager

ROOT = Path(__file__).resolve().parents[2]
pytestmark = pytest.mark.llm
CONTENT_PROFILES = ("production", "grounded_control", "gemma_recommended")
SAMPLING_KEYS = (
    "temperature", "min_p", "top_p", "top_k", "repeat_penalty", "repeat_last_n",
    "presence_penalty", "frequency_penalty",
)


def _profile_loader(loader: ConfigLoader, profile: str) -> tuple[ConfigLoader, dict]:
    """Clone only the test loader; no file/hot-reload/production state mutation."""
    if profile not in CONTENT_PROFILES:
        raise ValueError("unknown content profile")
    profiles = yaml.safe_load((ROOT / "config" / "sampling_sweep.yaml").read_text(encoding="utf-8"))["content_profiles"]
    if not isinstance(profiles, dict) or set(profiles) != set(CONTENT_PROFILES):
        raise ValueError("invalid content profile definitions")
    overrides = profiles[profile]
    if not isinstance(overrides, dict) or set(overrides) - set(SAMPLING_KEYS):
        raise ValueError("invalid content sampling keys")
    if profiles["production"] != {}:
        raise ValueError("production content profile must inherit models.yaml")
    if any(type(value) not in (int, float) or not math.isfinite(value) for value in overrides.values()):
        raise ValueError("content profile values must be finite numbers")
    with loader._lock:
        clone = ConfigLoader(loader._dir, required=loader._required)
        clone._data = copy.deepcopy(loader._data)
    clone._data["models"]["llm_main"].update(overrides)
    effective = {key: clone.get("models", "llm_main." + key) for key in SAMPLING_KEYS}
    return clone, effective


def _profile_output_path(path: Path, profile: str, seed_offset: int) -> Path:
    if profile not in CONTENT_PROFILES or type(seed_offset) is not int:
        raise ValueError("invalid content comparison options")
    if profile == "production" and seed_offset == 0:
        return path
    return path.with_name(f"{path.stem}.{profile}.seed{seed_offset}{path.suffix}")


def _save(path: Path, report: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


@pytest.fixture(scope="module")
def real_model_manager():
    """Reuse one owned process; service clients still belong to each test loop."""
    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    manager = LlamaServerProcessManager(LlamaServerConfig.from_loader(loader))
    try:
        yield manager
    finally:
        asyncio.run(manager.stop())


@pytest.mark.parametrize("corpus_variant", ["baseline", "holdout", "challenge"])
async def test_real_conversation_content_corpus(
    monkeypatch: pytest.MonkeyPatch, corpus_variant: str, real_model_manager,
    request: pytest.FixtureRequest,
) -> None:
    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    profile = request.config.getoption("content_profile")
    seed_offset = request.config.getoption("content_seed_offset")
    loader, effective_sampling = _profile_loader(loader, profile)
    policy = ContentPolicy.from_loader(loader)
    corpus_path = ROOT / policy.limits["corpus_file"]
    if corpus_variant != "baseline":
        corpus_path = corpus_path.with_name(f"conversation_quality_{corpus_variant}.yaml")
    sessions = load_corpus(corpus_path, policy)
    output_path = ROOT / policy.limits["output_file"]
    if corpus_variant != "baseline":
        output_path = output_path.with_name(f"conversation_quality.{corpus_variant}.json")
    output_path = _profile_output_path(output_path, profile, seed_offset)
    if output_path.exists():
        shutil.copy2(output_path, output_path.with_name(output_path.stem + f".previous-{time.time_ns()}.json"))
    if corpus_variant == "baseline" and profile == "production" and seed_offset == 0 and output_path.exists():
        baseline_path = output_path.with_name("conversation_quality.before_tuning.json")
        if not baseline_path.exists():
            shutil.copy2(output_path, baseline_path)
    assert loader.get("features", "features.filter_rule.enabled", False) is True
    source = inspect_source_state(ROOT)
    bound_files = [ROOT / "config" / name for name in CONFIG_FILES.values()]
    bound_files.extend(ROOT / "config" / "prompts" / name for name in ("persona_system.txt", "mai_lore.txt"))
    bound_files.extend(ROOT / path for path in (
        "services/llm/llm_turn.py", "services/llm/llama_cpp_llm.py", "services/llm/prompt_manager.py",
        "services/filter/regenerator.py", "services/filter/rule_filter.py",
        "interfaces/llm.py", "interfaces/state.py", "services/data/sanitize.py",
        "services/director/action_prompts.py", "services/state/continuity.py",
        "services/execution/speech.py", "services/input/chat_router.py",
        "services/cognition/compatibility_context.py",
        "services/evaluation/conversation_quality.py", "tests/integration/test_conversation_quality_live.py",
        "config/sampling_sweep.yaml", "tests/conftest.py",
    ))
    report = {
        "schema_version": 1, "marker": "mai_content_generation", "status": "running",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "product_version": loader.get("system", "app.version"),
        "source_revision": source.revision, "source_clean": source.clean,
        "file_hashes": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in bound_files},
        "corpus": {"file": str(corpus_path.relative_to(ROOT)), "synthetic_only": True,
                   "file_sha256": hashlib.sha256(corpus_path.read_bytes()).hexdigest(),
                   "sha256": hashlib.sha256(yaml.safe_dump(sessions, allow_unicode=True, sort_keys=True).encode("utf-8")).hexdigest()},
        "seed": (policy.limits["seed"] + seed_offset) % (2**31),
        "seed_offset": seed_offset, "content_profile": profile,
        "sampling_parameters": effective_sampling,
        "sampling": "production_with_request_seed" if profile == "production" else "test_profile_with_request_seed",
        "corpus_variant": corpus_variant,
        "holdout_wording": corpus_variant == "holdout", "independent_holdout": False,
        "tuning_exposure": (
            "AI-authored adversarial development corpus; not an external or blind benchmark"
            if corpus_variant == "challenge" else
            "development corpus, repeatedly reviewed; not an external held-out benchmark"
        ),
        "operator_approved": False, "release_gate_eligible": False,
        "pipeline": "production_persona_lore_history_llama_cpp_parser_filter_regeneration",
        "delivery_verified": False, "history_mode": "simulated_after_capture",
        "source_mode": "deterministic_synthetic_pseudonym_per_session",
        "not_covered": ["live_director_selection", "live_mood", "memory_relationship", "brain", "tts_avatar", "public_broadcast", "real_multi_viewer_lineage"],
        "sessions": len(sessions), "rows": [],
    }
    _save(output_path, report)
    manager = real_model_manager
    service = LlamaCppLLMService.from_loader(loader)
    rule_filter = RuleFilter.from_config(loader)
    original_generate = service.generate_stream

    async def seeded_generate(request: LLMRequest) -> AsyncIterator[LLMToken]:
        offset = int.from_bytes(hashlib.sha256(request.request_id.encode("utf-8")).digest()[:4], "big")
        seeded = request.model_copy(update={"seed": (policy.limits["seed"] + seed_offset + offset) % (2**31)})
        async for token in original_generate(seeded):
            yield token

    monkeypatch.setattr(service, "generate_stream", seeded_generate)
    try:
        await manager.start()
        await service.start()
        await rule_filter.start()
        assert (await service.health_check()).is_ok
        for session in sessions:
            viewer_ref = "v_" + hashlib.sha256(session["id"].encode("utf-8")).hexdigest()[:16]
            pm = PromptManager.from_loader(loader)
            runner = LLMTurnRunner.from_loader(
                loader, service, pm, FallbackManager(), CannedResponder.from_loader(loader),
                regenerator=FilterRegenerator.from_loader(loader, rule_filter, service),
                session_id="content-" + session["id"],
            )
            for turn in session["turns"]:
                sources = (ViewerUtterance(text=turn["input"], viewer_ref=viewer_ref),)
                ref = session["id"] + "/" + turn["id"]
                history_messages = len(pm.history())
                started = time.perf_counter()
                parsed, level = await runner.run_turn(
                    request_id=ref, user_text=turn["input"], trigger_type="chat",
                    event_category=turn["category"], commit_history=False,
                    source_messages=sources,
                )
                verdict = runner.last_filter_verdict
                row = {
                    "ref": ref, "input": mask_pii(turn["input"]), "output": mask_pii(parsed.text),
                    "expectations": turn["expectations"], "critical": turn["critical"],
                    "history_messages_before": history_messages, "parsed_ok": parsed.ok,
                    "fallback_level": level, "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
                    "ttft_ms": service.get_metrics().get("llm_last_ttft_ms"),
                    "filter": verdict.model_dump(mode="json") if verdict is not None else None,
                }
                report["rows"].append(row)
                _save(output_path, report)
                # Windows console may use cp1252; the artifact still retains UTF-8 text.
                print(f"CONTENT {ref}: {json.dumps(row['output'], ensure_ascii=True)}", flush=True)
                # Text-only simulated sink; no turn logger, memory, business commit or delivery claims.
                if parsed.ok and verdict is not None and verdict.passed and not verdict.reason.startswith("fail-open"):
                    pm.commit_turn(turn["input"], parsed.text, sources=sources)
        report["status"] = "complete"
    except BaseException as exc:
        report["status"] = "interrupted"
        report["error_type"] = type(exc).__name__
        raise
    finally:
        try:
            await rule_filter.stop()
            await service.stop()
        finally:
            report["automatic"] = automatic_checks(report["rows"], policy)
            report["llm_metrics"] = service.get_metrics()
            report["filter_metrics"] = rule_filter.get_metrics()
            _save(output_path, report)
    assert len(report["rows"]) == sum(len(session["turns"]) for session in sessions)
    assert report["automatic"]["status"] == "passed", report["automatic"]
