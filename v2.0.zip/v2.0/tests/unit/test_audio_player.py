"""Test AudioPlayer với FakeBackend (không mở audio device) — Phase 4, 4.D."""
from __future__ import annotations

import asyncio
import threading
import time

import numpy as np
import pytest

from interfaces.tts import AudioChunk
from services.tts.audio_player import AudioPlayer


def test_explicit_output_device_is_passed_to_portaudio(monkeypatch) -> None:
    from services.tts.audio_player import SounddeviceBackend
    import sounddevice as sd

    settings = []

    class Stream:
        def __init__(self, **kwargs):
            settings.append(kwargs)

        def start(self):
            pass

        def write(self, samples):
            assert samples.dtype == np.float32

        def abort(self):
            pass

        def close(self):
            pass

    monkeypatch.setattr(sd, "OutputStream", Stream)
    backend = SounddeviceBackend("CABLE Input")
    backend.play_blocking(np.zeros(240, dtype=np.float32), 48000)
    backend.stop()
    assert settings[0]["device"] == "CABLE Input"
    assert settings[0]["samplerate"] == 48000


@pytest.mark.parametrize("device", [True, -1, "", " CABLE Input ", []])
def test_invalid_output_device_is_rejected(device) -> None:
    from services.tts.audio_player import SounddeviceBackend

    with pytest.raises(ValueError):
        SounddeviceBackend(device)


class FakeBackend:
    """Ghi lại (samples, sr) đã phát. play_blocking sleep để mô phỏng thời gian."""

    def __init__(self, per_chunk_delay_s: float = 0.02):
        self.played: list[tuple[int, int]] = []  # (nsamples, sr)
        self.stops = 0
        self._delay = per_chunk_delay_s
        self._stop_event = threading.Event()

    def play_blocking(self, samples, sample_rate):
        self._stop_event.clear()
        # simulate blocking playback interruptible by stop()
        deadline = time.perf_counter() + self._delay
        while time.perf_counter() < deadline:
            if self._stop_event.is_set():
                return
            time.sleep(0.005)
        self.played.append((int(samples.shape[0]), sample_rate))

    def stop(self):
        self.stops += 1
        self._stop_event.set()


def chunk(rid: str, idx: int, samples: int = 240, is_final: bool = False, sample_rate: int = 24000) -> AudioChunk:
    audio = np.zeros(samples, dtype=np.float32).tobytes() if not is_final else b""
    return AudioChunk(request_id=rid, chunk_index=idx, audio_bytes=audio,
                      is_final=is_final, duration_ms=int(1000 * samples / sample_rate))


async def _wait_played(player: AudioPlayer, n: int, timeout: float = 2.0) -> None:
    # Wait on the player's own metric: the backend list is appended in the worker
    # thread before `chunks_played` is incremented back on the event loop.
    deadline = asyncio.get_event_loop().time() + timeout
    while (
        player.get_metrics()["audio_chunks_played"] < n
        and asyncio.get_event_loop().time() < deadline
    ):
        await asyncio.sleep(0.01)


class TestSequential:
    async def test_plays_in_order_no_overlap(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.03)
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            for i in range(3):
                await p.enqueue(chunk("r1", i))
            final = await p.enqueue(chunk("r1", 3, is_final=True))
            await _wait_played(p, 3)
            # The final marker's receipt resolves only after the worker reset `current`.
            assert await asyncio.wait_for(final, timeout=2.0) is True
            assert len(be.played) == 3
            assert p.get_metrics()["audio_chunks_played"] == 3
            assert p.is_playing is False    # final → reset current
        finally:
            await p.stop()

    async def test_two_requests_dont_overlap(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.03)
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            await p.enqueue(chunk("r1", 0))
            await p.enqueue(chunk("r1", 1, is_final=True))
            await p.enqueue(chunk("r2", 0))
            await p.enqueue(chunk("r2", 1, is_final=True))
            await _wait_played(p, 2)
            assert be.played == [(240, 24000), (240, 24000)]
        finally:
            await p.stop()


class TestCancel:
    @pytest.mark.parametrize("operation", ["cancel_current", "cancel_all", "stop"])
    async def test_cancel_during_pitch_render_never_starts_late_playback(
        self, monkeypatch: pytest.MonkeyPatch, operation: str,
    ) -> None:
        entered = threading.Event()
        release = threading.Event()

        def blocked_pitch(samples: np.ndarray, sample_rate: int, semitones: float) -> np.ndarray:
            entered.set()
            if not release.wait(timeout=2.0):
                raise TimeoutError("test did not release pitch render")
            return samples

        monkeypatch.setattr("services.tts.audio_player.pitch_shift_samples", blocked_pitch)
        backend = FakeBackend(per_chunk_delay_s=0)
        player = AudioPlayer(sample_rate=24000, backend=backend)
        await player.start()
        player.pitch_semitones = 1.5
        stop_task: asyncio.Task[None] | None = None
        try:
            receipt = await player.enqueue(chunk("cancel-during-render", 0))
            assert await asyncio.to_thread(entered.wait, 1.0), "DSP did not begin"
            if operation == "stop":
                stop_task = asyncio.create_task(player.stop())
                assert await asyncio.to_thread(backend._stop_event.wait, 1.0)
            elif operation == "cancel_all":
                await asyncio.wait_for(player.cancel_all(), timeout=1.0)
            else:
                await asyncio.wait_for(player.cancel_current("cancel-during-render"), timeout=1.0)

            # A receipt that says failure is insufficient: cancelled sound must
            # never reach the backend once its slow DSP worker returns.
            assert backend.played == []
            release.set()
            assert await asyncio.wait_for(receipt, timeout=2.0) is False
            if stop_task is not None:
                await asyncio.wait_for(stop_task, timeout=2.0)
            assert backend.played == []
            assert player.is_playing is False
            assert player.get_metrics()["audio_chunks_played"] == 0
            if operation != "stop":
                fresh = await player.enqueue(chunk("after-cancel", 0))
                assert await asyncio.wait_for(fresh, timeout=2.0) is True
                assert backend.played == [(240, 24000)]
        finally:
            release.set()
            if stop_task is not None:
                await asyncio.wait_for(stop_task, timeout=2.0)
            await player.stop()

    async def test_cancelled_receipts_fail_and_do_not_leave_stale_speaking_state(self) -> None:
        backend = FakeBackend(per_chunk_delay_s=0.3)
        player = AudioPlayer(sample_rate=24000, backend=backend)
        await player.start()
        try:
            receipt = await player.enqueue(chunk("cancelled-receipt", 0))
            await asyncio.sleep(0.02)
            await player.cancel_all()
            assert await receipt is False
            assert player.is_playing is False
        finally:
            await player.stop()

    async def test_cancel_all_stops_backend_and_drains_queue(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.3)
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            for i in range(5):
                await p.enqueue(chunk(f"r{i}", 0))
            await asyncio.sleep(0.02)
            await p.cancel_all()
            assert p.get_metrics()["audio_queue_size"] == 0
            assert be.stops >= 1
        finally:
            await p.stop()

    async def test_cancel_drops_pending_of_same_request(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.05)
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            # nhét 5 chunk r1, cancel ngay → chỉ chunk đang chạy có thể đã play (bị stop),
            # còn lại drop.
            for i in range(5):
                await p.enqueue(chunk("r1", i))
            await asyncio.sleep(0.01)   # để worker bắt chunk đầu
            await p.cancel_current("r1")
            # nhét thêm r2 sau khi cancel r1
            await p.enqueue(chunk("r2", 0))
            await _wait_played(p, 1)
            # ít nhất 1 chunk r2 chạy được; nhiều chunk r1 bị drop
            assert p.get_metrics()["audio_chunks_dropped"] >= 3
        finally:
            await p.stop()

    async def test_cancel_stops_current_chunk_immediately(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.3)   # chunk dài
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            await p.enqueue(chunk("r1", 0))
            await asyncio.sleep(0.02)     # để worker vào giữa chunk
            t0 = asyncio.get_event_loop().time()
            await p.cancel_current("r1")
            # cho worker time để hủy
            await asyncio.sleep(0.05)
            elapsed = asyncio.get_event_loop().time() - t0
            assert elapsed < 0.25              # dừng trước khi hết 300ms
            assert be.stops >= 1
        finally:
            await p.stop()


class TestLifecycle:
    async def test_stop_clean_when_idle(self) -> None:
        p = AudioPlayer(sample_rate=24000, backend=FakeBackend())
        await p.start()
        await asyncio.wait_for(p.stop(), timeout=2.0)

    async def test_metrics_empty_initially(self) -> None:
        p = AudioPlayer(sample_rate=24000, backend=FakeBackend())
        m = p.get_metrics()
        assert m["audio_chunks_played"] == 0
        assert m["audio_chunks_dropped"] == 0
        assert m["audio_is_playing"] is False


@pytest.mark.parametrize("barrier_phase", ["construct", "start", "drain", "restart"])
async def test_sounddevice_cancel_fences_late_open_and_final_drain(
    monkeypatch: pytest.MonkeyPatch, barrier_phase: str,
) -> None:
    import sounddevice as sd
    from services.tts.audio_player import SounddeviceBackend

    entered = threading.Event()
    release = threading.Event()
    cancellation_started = threading.Event()
    streams = []
    writes = []
    late_starts = []

    class ControlledStream:
        def __init__(self, **kwargs) -> None:
            self.closed = False
            self.closed_event = threading.Event()
            self.aborted = False
            self.start_calls = 0
            self.index = len(streams)
            streams.append(self)
            self._barrier("construct")

        def _barrier(self, phase: str) -> None:
            if self.index == 0 and barrier_phase == phase and not entered.is_set():
                entered.set()
                if not release.wait(timeout=2.0):
                    raise TimeoutError("test did not release audio backend")

        def start(self) -> None:
            self.start_calls += 1
            if cancellation_started.is_set():
                late_starts.append(self.index)
            self._barrier("start" if self.start_calls == 1 else "restart")

        def write(self, samples: np.ndarray) -> None:
            writes.append((self.index, int(samples.shape[0])))

        def stop(self) -> None:
            self._barrier("drain")

        def abort(self) -> None:
            self.aborted = True

        def close(self) -> None:
            self.closed = True
            self.closed_event.set()

    monkeypatch.setattr(sd, "OutputStream", ControlledStream)
    player = AudioPlayer(sample_rate=24000, backend=SounddeviceBackend())
    await player.start()
    try:
        receipt = await player.enqueue(chunk("backend-cancel", 0))
        if barrier_phase in {"drain", "restart"}:
            assert await asyncio.wait_for(receipt, timeout=2.0) is True
            receipt = await player.enqueue(chunk("backend-cancel", 1, is_final=True))
        assert await asyncio.to_thread(entered.wait, 1.0), "backend phase was not entered"
        writes_before_cancel = list(writes)
        cancellation_started.set()
        # Opening/draining PortAudio may block. Cancellation cannot wait for its
        # metadata lock or for a slow stream constructor to finish first.
        cancel_started_at = time.perf_counter()
        await asyncio.wait_for(player.cancel_current("backend-cancel"), timeout=1.0)
        assert time.perf_counter() - cancel_started_at < 1.0
        release.set()
        assert await asyncio.wait_for(receipt, timeout=2.0) is False
        # Cancellation may fail the receipt immediately while the PortAudio
        # worker is still unwinding its slow constructor/start call.
        assert await asyncio.to_thread(streams[0].closed_event.wait, 1.0)
        assert writes == writes_before_cancel
        assert late_starts == []
        assert streams[0].closed is True

        cancellation_started.clear()
        fresh = await player.enqueue(chunk("fresh-after-backend-cancel", 0))
        assert await asyncio.wait_for(fresh, timeout=2.0) is True
        assert writes[-1][0] > 0
    finally:
        release.set()
        await player.stop()


class TestFinalChunk:
    async def test_final_empty_chunk_resets_current(self) -> None:
        be = FakeBackend(per_chunk_delay_s=0.01)
        p = AudioPlayer(sample_rate=24000, backend=be)
        await p.start()
        try:
            await p.enqueue(chunk("r1", 0))
            final = await p.enqueue(chunk("r1", 1, is_final=True))
            await _wait_played(p, 1)
            assert await asyncio.wait_for(final, timeout=2.0) is True  # worker xử final xong
            assert p.is_playing is False
        finally:
            await p.stop()


class CapturingBackend:
    """Ghi lại chính mảng samples đã phát (để kiểm pitch-shift áp đúng)."""

    def __init__(self) -> None:
        self.samples: list[np.ndarray] = []

    def play_blocking(self, samples, sample_rate):
        self.samples.append(np.asarray(samples, dtype=np.float32).copy())

    def stop(self):
        pass


def _sine(freq: float, sr: int, n: int) -> np.ndarray:
    t = np.arange(n) / sr
    return np.sin(2 * np.pi * freq * t).astype(np.float32)


def _dominant_hz(sig: np.ndarray, sr: int) -> float:
    spectrum = np.abs(np.fft.rfft(sig))
    return float(np.fft.rfftfreq(sig.size, 1 / sr)[int(np.argmax(spectrum))])


class TestPitchShift:
    def test_clamp_bounds(self) -> None:
        from services.tts.pitch import clamp_semitones
        assert clamp_semitones(99) == 12.0
        assert clamp_semitones(-99) == -12.0
        assert clamp_semitones(3.5) == 3.5

    def test_zero_is_noop_identity(self) -> None:
        from services.tts.pitch import pitch_shift_samples
        x = _sine(220.0, 22050, 4096)
        out = pitch_shift_samples(x, 22050, 0.0)
        assert out is x  # fast path: trả nguyên object, không tốn CPU

    def test_pitch_up_one_octave_doubles_frequency(self) -> None:
        from services.tts.pitch import pitch_shift_samples
        sr, f0 = 22050, 220.0
        x = _sine(f0, sr, 22050)  # 1s
        up = pitch_shift_samples(x, sr, 12.0)  # +1 octave
        assert up.shape == x.shape  # giữ nguyên độ dài
        assert abs(_dominant_hz(up, sr) - 2 * f0) < 20.0  # ~440Hz

    def test_player_metric_reports_and_clamps(self) -> None:
        p = AudioPlayer(sample_rate=48000, pitch_semitones=50.0, backend=FakeBackend())
        assert p.get_metrics()["audio_pitch_semitones"] == 12.0  # clamped
        p2 = AudioPlayer(sample_rate=48000, pitch_semitones=3.0, backend=FakeBackend())
        assert p2.get_metrics()["audio_pitch_semitones"] == 3.0

    async def test_player_applies_pitch_when_nonzero(self) -> None:
        sr = 24000
        raw = _sine(200.0, sr, 4096)
        ch = AudioChunk(request_id="r1", chunk_index=0, audio_bytes=raw.tobytes(),
                        is_final=False, duration_ms=int(1000 * raw.size / sr))
        be = CapturingBackend()
        p = AudioPlayer(sample_rate=sr, backend=be, pitch_semitones=5.0)
        await p.start()
        try:
            await p.enqueue(ch)
            deadline = asyncio.get_event_loop().time() + 2.0
            while not be.samples and asyncio.get_event_loop().time() < deadline:
                await asyncio.sleep(0.01)
            assert be.samples, "chunk chưa được phát"
            played = be.samples[0]
            assert played.shape == raw.shape          # độ dài giữ nguyên
            assert not np.allclose(played, raw)       # cao độ đã đổi
        finally:
            await p.stop()

    async def test_player_zero_pitch_passes_through(self) -> None:
        sr = 24000
        raw = _sine(200.0, sr, 4096)
        ch = AudioChunk(request_id="r1", chunk_index=0, audio_bytes=raw.tobytes(),
                        is_final=False, duration_ms=int(1000 * raw.size / sr))
        be = CapturingBackend()
        p = AudioPlayer(sample_rate=sr, backend=be, pitch_semitones=0.0)
        await p.start()
        try:
            await p.enqueue(ch)
            deadline = asyncio.get_event_loop().time() + 2.0
            while not be.samples and asyncio.get_event_loop().time() < deadline:
                await asyncio.sleep(0.01)
            assert be.samples, "chunk chưa được phát"
            assert np.array_equal(be.samples[0], raw)  # no-op: y hệt input
        finally:
            await p.stop()


async def test_pitch_warmup_never_reaches_audio_sink() -> None:
    backend = CapturingBackend()
    player = AudioPlayer(sample_rate=24000, backend=backend, pitch_semitones=1.5)
    await player.start()
    try:
        assert backend.samples == []
        assert player.get_metrics()["audio_pitch_warmup_ms"] is not None
    finally:
        await player.stop()
