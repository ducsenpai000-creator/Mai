from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from services.relationship.store import RelationshipStore
from services.data.sanitize import pseudonymize_viewer_id, metadata_reference


def _store() -> RelationshipStore:
    conn = sqlite3.connect(":memory:")
    sql = (Path(__file__).resolve().parents[2] / "migrations" / "005_add_relationship_tables.sql").read_text(encoding="utf-8")
    conn.executescript(sql)
    return RelationshipStore(conn=conn)


def test_profile_insert_and_event_dedup() -> None:
    store = _store()
    now = datetime(2026, 8, 8, tzinfo=timezone.utc)
    first, inserted = store.observe_profile(
        viewer_id="v_123", event_id="chat-1", occurred_at=now, expires_at=now,
    )
    second, duplicated = store.observe_profile(
        viewer_id="v_123", event_id="chat-1", occurred_at=now, expires_at=now,
    )
    assert inserted is True and duplicated is False
    assert first.interaction_count == second.interaction_count == 1


def test_profile_never_contains_raw_identity_fields() -> None:
    store = _store()
    now = datetime(2026, 8, 8, tzinfo=timezone.utc)
    profile, _ = store.observe_profile(
        viewer_id="v_safe", event_id="chat-1", occurred_at=now, expires_at=now,
    )
    assert set(profile.to_dict()) == {
        "viewer_id", "interaction_count", "first_seen", "last_seen", "expires_at",
        "confirmed_preferences", "boundaries", "tone",
    }


def test_audit_does_not_persist_operator_transcript_reason() -> None:
    store = _store()
    now = datetime(2026, 10, 17, tzinfo=timezone.utc)
    viewer = pseudonymize_viewer_id("synthetic-raw-viewer")
    store.write_audit(
        audit_id="synthetic-audit", action="note_create", viewer_id=viewer,
        target_id="synthetic-note", reason="SYNTHETIC_CHAT_REPLY_AND_OPERATOR_REASON", created_at=now,
    )
    rows = store._conn.execute("SELECT * FROM relationship_audit").fetchall()
    assert "SYNTHETIC_CHAT_REPLY_AND_OPERATOR_REASON" not in str([tuple(row) for row in rows])
    assert rows[0]["reason"] == "metadata_only"
    assert rows[0]["viewer_id"] == viewer
    assert rows[0]["target_id"] == metadata_reference("synthetic-note")

