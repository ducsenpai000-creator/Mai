"""M0.2 integration: output filter is wired into the real stream runtime factory."""
from __future__ import annotations

import asyncio
import shutil
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any, AsyncIterator

import pytest
import yaml
import httpx

import orchestrator.stream_runtime as stream_runtime_module
from interfaces.base import HealthStatus
from interfaces.compatibility import ActionRequest
from interfaces.input import InputEvent, InputService
from interfaces.llm import LLMRequest, LLMToken
from orchestrator.config_loader import ConfigLoader
from orchestrator.features import FeatureStatus
from orchestrator.stream_runtime import StreamRuntime, StreamRuntimeConfig
from services.tts.subtitle_fallback import SubtitleFallbackService

REPO_ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
async def ephemeral_subtitle_transport(monkeypatch: pytest.MonkeyPatch) -> AsyncIterator[list[SubtitleFallbackService]]:
    original_factory = SubtitleFallbackService.from_loader
    created: list[SubtitleFallbackService] = []

    class TransportLoader:
        def __init__(self, loader: Any) -> None:
            self.loader = loader

        def get(self, name: str, key: str, default: Any = None) -> Any:
            if (name, key) == ("models", "tts_fallback.overlay_port"):
                return 0
            return self.loader.get(name, key, default)

    def factory(cls: type[SubtitleFallbackService], loader: Any, **kwargs: Any) -> SubtitleFallbackService:
        service = original_factory(TransportLoader(loader), **kwargs)
        created.append(service)
        return service

    monkeypatch.setattr(SubtitleFallbackService, "from_loader", classmethod(factory))
    yield created
    for service in reversed(created):
        await service.stop()


BAD_OUTPUT = "Tớ chỉ là một chương trình thôi, tớ không có cảm xúc."
CLEAN_OUTPUT = "Ừ, hỏi gì thì hỏi đi."


class ScriptedStreamLLM:
    service_id = "llm_main"

    def __init__(self, outputs: list[str]) -> None:
        self.outputs = list(outputs)
        self.requests: list[LLMRequest] = []
        self.started = False
        self.stopped = False

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def health_check(self) -> HealthStatus:
        return HealthStatus.healthy(self.service_id)

    async def generate_stream(self, request: LLMRequest):
        self.requests.append(request)
        if not self.outputs:
            raise AssertionError("Fake LLM ran out of scripted outputs")
        text = self.outputs.pop(0)
        yield LLMToken(request_id=request.request_id, token=text, is_final=False)
        yield LLMToken(request_id=request.request_id, token="", is_final=True)

    async def cancel(self, request_id: str) -> None:
        return None

    def get_metrics(self) -> dict[str, Any]:
        return {}


class CaptureWriter:
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []

    def write(self, record: dict[str, Any]) -> None:
        self.records.append(record)


class FakeInputService(InputService):
    service_id = "fake_input"

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def health_check(self) -> HealthStatus:
        return HealthStatus.healthy(self.service_id)

    def get_metrics(self) -> dict[str, Any]:
        return {}

    async def event_stream(self) -> AsyncIterator[InputEvent]:
        await asyncio.Event().wait()
        if False:
            yield  # pragma: no cover


def _loader(
    tmp_path: Path, *, filter_enabled: bool, kernel_mode: str = "shadow",
) -> ConfigLoader:
    config_dir = tmp_path / "config"
    shutil.copytree(REPO_ROOT / "config", config_dir)
    features_path = config_dir / "features.yaml"
    features = yaml.safe_load(features_path.read_text(encoding="utf-8"))
    features["features"]["filter_rule"]["enabled"] = filter_enabled
    features_path.write_text(
        yaml.safe_dump(features, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    kernel_path = config_dir / "kernel.yaml"
    kernel = yaml.safe_load(kernel_path.read_text(encoding="utf-8"))
    kernel["rollout_mode"] = kernel_mode
    kernel_path.write_text(
        yaml.safe_dump(kernel, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    operations_path = config_dir / "operations.yaml"
    operations = yaml.safe_load(operations_path.read_text(encoding="utf-8"))
    operations["shutdown"]["snapshot_file"] = str(tmp_path / "last_runtime_snapshot.json")
    operations["dashboard_standalone"]["operator_audit_file"] = str(
        tmp_path / "operator_audit.jsonl"
    )
    operations["incident_log"]["file"] = str(tmp_path / "incidents.jsonl")
    operations_path.write_text(
        yaml.safe_dump(operations, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    loader = ConfigLoader(config_dir)
    loader.load_all()
    loader._data["models"]["tts_fallback"]["output_file"] = None
    return loader


async def _build_runtime(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    outputs: list[str],
    *,
    filter_enabled: bool,
    kernel_mode: str = "shadow",
    dashboard_capture: dict[str, Any] | None = None,
) -> tuple[StreamRuntime, ScriptedStreamLLM, CaptureWriter]:
    fake_llm = ScriptedStreamLLM(outputs)
    pref_writer = CaptureWriter()
    monkeypatch.setattr(
        stream_runtime_module,
        "LlamaCppLLMService",
        SimpleNamespace(from_loader=lambda _loader: fake_llm),
    )
    monkeypatch.setattr(
        stream_runtime_module,
        "setup_from_config",
        lambda _loader, metrics=None: None,
    )
    monkeypatch.setattr(
        stream_runtime_module,
        "_make_pref_logger",
        lambda _loader: pref_writer,
    )

    class FakeProcessManager:
        def __init__(self, _config) -> None:
            self.started = False

        async def start(self) -> None:
            self.started = True

        async def stop(self) -> None:
            self.started = False

        async def restart(self) -> None:
            self.started = True

    monkeypatch.setattr(stream_runtime_module, "LlamaServerProcessManager", FakeProcessManager)

    enable_dashboard = dashboard_capture is not None
    if dashboard_capture is not None:
        monkeypatch.setenv(
            "MAI_DASHBOARD_CONTROL_TOKEN", "test-dashboard-control-token-123456",
        )
        import dashboard.dashboard_server as dashboard_module

        class FakeDashboard:
            def __init__(self, **kwargs: Any) -> None:
                dashboard_capture.update(kwargs)

            async def serve(self) -> None:
                await asyncio.sleep(0)

        monkeypatch.setattr(dashboard_module, "DashboardServer", FakeDashboard)

    runtime = await stream_runtime_module.build_stream_runtime(
        loader=_loader(
            tmp_path, filter_enabled=filter_enabled, kernel_mode=kernel_mode,
        ),
        sources=[FakeInputService()],
        cfg=StreamRuntimeConfig(
            enable_tts=False,
            enable_memory=False,
            enable_autonomy=False,
            enable_dashboard=enable_dashboard,
        ),
    )
    return runtime, fake_llm, pref_writer


class TestRuntimeFilterWiring:
    async def test_no_tts_runtime_still_delivers_and_commits_subtitle(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ) -> None:
        from interfaces.input import EventSource

        runtime, _llm, _pref = await _build_runtime(
            monkeypatch, tmp_path, [CLEAN_OUTPUT], filter_enabled=True,
        )
        try:
            await runtime.start()
            await runtime._router._process(InputEvent(
                event_id="subtitle-live", timestamp=datetime.now(timezone.utc),
                source=EventSource.CHAT_YOUTUBE, user_id="local-viewer",
                content="Mai ơi, chào nhé!",
            ))
            async with asyncio.timeout(30):
                while runtime.get_metrics()["continuity_commit_total"] == 0:
                    await asyncio.sleep(0.1)
            assert runtime._tts_svc is None
            assert runtime._audio_player is None
            assert runtime._tts_pipeline.get_metrics()["tts_pipeline_last_delivery_mode"] == "subtitle"
            async with httpx.AsyncClient(base_url=runtime._subtitle_svc.overlay_url, trust_env=False) as client:
                assert (await client.get("/subtitle")).json()["text"] == CLEAN_OUTPUT
            assert not (tmp_path / "subtitle.txt").exists()
            assert runtime.get_metrics()["continuity_inconsistency_total"] == 0
        finally:
            await runtime.stop()

    async def test_public_brain_canary_requires_dependencies_and_toggles_real_kernel(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        runtime, _, _ = await _build_runtime(
            monkeypatch,
            tmp_path,
            [BAD_OUTPUT],
            filter_enabled=True,
            kernel_mode="brain",
        )
        try:
            blocked = await runtime._feature_manager.enable(
                "cognitive_brain_public", user="test",
            )
            assert blocked.ok is False
            assert "cognitive_brain_shadow" in blocked.reason

            shadow = await runtime._feature_manager.enable(
                "cognitive_brain_shadow", user="test",
            )
            assert shadow.ok is True
            public = await runtime._feature_manager.enable(
                "cognitive_brain_public", user="test",
            )
            assert public.ok is True
            assert runtime._turn_kernel.public_brain_enabled is True
            assert runtime.operations_snapshot()["turn_kernel"][
                "turn_kernel_public_owner"
            ] == "BRAIN_CANARY"

            disable_shadow = await runtime._feature_manager.disable(
                "cognitive_brain_shadow", user="test",
            )
            assert disable_shadow.ok is False
            assert "cognitive_brain_public" in disable_shadow.reason
            assert (await runtime._feature_manager.disable(
                "cognitive_brain_public", user="test",
            )).ok is True
            assert runtime._turn_kernel.public_brain_enabled is False
            assert (await runtime._feature_manager.disable(
                "cognitive_brain_shadow", user="test",
            )).ok is True
        finally:
            await runtime.stop()

    async def test_kernel_off_rejects_brain_worker_activation(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        runtime, _, _ = await _build_runtime(
            monkeypatch,
            tmp_path,
            [BAD_OUTPUT],
            filter_enabled=False,
            kernel_mode="off",
        )
        try:
            result = await runtime._feature_manager.enable(
                "cognitive_brain_shadow", user="test",
            )
            assert result.ok is False
            assert "kernel rollout is OFF" in result.reason
            assert runtime._cognitive_scheduler.snapshot().running is False
        finally:
            await runtime.stop()

    async def test_enabled_filter_regenerates_and_runtime_toggle_is_real(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        dashboard: dict[str, Any] = {}
        runtime, llm, pref = await _build_runtime(
            monkeypatch,
            tmp_path,
            [BAD_OUTPUT, CLEAN_OUTPUT, BAD_OUTPUT, BAD_OUTPUT, CLEAN_OUTPUT],
            filter_enabled=True,
            dashboard_capture=dashboard,
        )
        await runtime.start()
        try:
            assert runtime._turn_kernel._task is not None
            assert runtime._turn_kernel._task.get_name() == "turn_kernel"
            assert runtime._director_loop._task is None
            assert runtime._director_loop._running is True
            assert runtime.operations_snapshot()["turn_kernel"][
                "turn_kernel_public_owner"
            ] == "COMPATIBILITY"
            parsed, level = await runtime._runner.run_turn("r1", "chào")
            assert level == 0
            assert parsed.text == CLEAN_OUTPUT
            assert len(llm.requests) == 2
            assert runtime._runner.last_filter_verdict is not None
            assert runtime._runner.last_filter_verdict.passed is True

            metrics = runtime._metrics.filter_snapshot()
            assert metrics["checks_total"] == 1
            assert metrics["hits_total"] == 1
            assert metrics["by_category"] == {"persona_break": 1}
            assert runtime._regenerator.get_metrics()["filter_regen_recovered_total"] == 1
            prometheus = runtime._metrics.prometheus_text().decode("utf-8")
            assert 'mai_filter_regen_total{result="recovered"} 1.0' in prometheus
            assert len(pref.records) == 1
            assert pref.records[0]["rejected"] is None
            assert pref.records[0]["chosen"] is None
            assert pref.records[0]["reason"] is None
            assert pref.records[0]["record_type"] == "preference_metadata"

            assert dashboard["operations_surface"] is runtime._operations_surface
            assert dashboard["metrics"] is runtime._metrics
            assert "feature_manager" not in dashboard
            assert "goal_manager" not in dashboard
            assert runtime._cognitive_scheduler.snapshot().running is False
            cognitive_enabled = await runtime._feature_manager.enable(
                "cognitive_brain_shadow", user="test",
            )
            assert cognitive_enabled.ok is True
            assert runtime._cognitive_scheduler.snapshot().running is True
            cognitive_disabled = await runtime._feature_manager.disable(
                "cognitive_brain_shadow", user="test",
            )
            assert cognitive_disabled.ok is True
            assert runtime._cognitive_scheduler.snapshot().running is False
            assert set(runtime._health_supervisor.snapshot()["targets"]) == {
                "dashboard", "input_router", "llm_main", "obs_perception_adapter",
                "obs_websocket", "outcome_committer", "execution_coordinator",
                "continuity_state", "turn_journal", "operations_surface",
                "tts",
            }
            assert runtime._tts_svc is None
            tts_health = await runtime._tts_pipeline.health_check()
            assert tts_health.is_ok is True
            assert tts_health.details["delivery_mode"] == "subtitle"
            assert tts_health.details["audio_available"] is False
            assert "tts_primary" not in runtime._health_supervisor.snapshot()["targets"]
            assert [
                adapter.service_id for adapter in runtime._perception_adapters
            ] == [
                "chat_perception_adapter",
                "system_perception_adapter",
                "obs_perception_adapter",
            ]
            assert runtime._external_executor_registry.snapshot()["bindings"] == [{
                "executor_id": "obs_scene",
                "verifier_id": "obs_scene_state",
                "feature_id": "obs_scene_executor",
                "health_target_id": "obs_websocket",
            }]
            assert runtime._external_action_loop.enabled is False
            assert runtime.operations_snapshot()["external_actions"]["recent"] == []
            assert runtime._llama_process_manager.started is True
            assert "control_plane" not in dashboard
            assert runtime.agent_state.snapshot().active_goal_ref is None
            assert runtime.goal_proposal.enabled is False

            proposal_toggle = await runtime._feature_manager.enable("goal_proposals", user="test")
            assert proposal_toggle.ok is True
            assert runtime.goal_proposal.enabled is True
            proposal_toggle = await runtime._feature_manager.disable("goal_proposals", user="test")
            assert proposal_toggle.ok is True
            assert runtime.goal_proposal.enabled is False

            result = await runtime._feature_manager.disable("filter_rule", user="test")
            assert result.ok is True
            assert result.status is FeatureStatus.DISABLED
            assert runtime._runner.filter_enabled is False
            unfiltered, _ = await runtime._runner.run_turn("r2", "chào lại")
            assert unfiltered.text == BAD_OUTPUT
            assert runtime._runner.last_filter_verdict is None
            assert runtime._metrics.filter_snapshot()["checks_total"] == 1

            result = await runtime._feature_manager.enable("filter_rule", user="test")
            assert result.ok is True
            assert result.status is FeatureStatus.ENABLED
            assert runtime._runner.filter_enabled is True
            filtered_again, _ = await runtime._runner.run_turn("r3", "lần nữa")
            assert filtered_again.text == CLEAN_OUTPUT
            assert runtime._metrics.filter_snapshot()["checks_total"] == 2
            assert len(pref.records) == 2
        finally:
            await runtime.stop()
        snapshot_path = tmp_path / "last_runtime_snapshot.json"
        assert snapshot_path.exists()
        shutdown_snapshot = yaml.safe_load(snapshot_path.read_text(encoding="utf-8"))
        assert shutdown_snapshot["agent"] is not None
        assert runtime._shutdown_coordinator.get_metrics()["shutdown_completed"] is True

    async def test_disabled_feature_is_backward_compatible(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        runtime, llm, pref = await _build_runtime(
            monkeypatch,
            tmp_path,
            [BAD_OUTPUT],
            filter_enabled=False,
        )
        try:
            cognitive = runtime._cognitive_scheduler.snapshot()
            assert cognitive.running is False
            assert cognitive.queue_depth == 0
            assert cognitive.inflight_count == 0
            assert cognitive.retained_record_count == 0
            assert runtime.operations_snapshot()["cognitive_brain_shadow"] == {
                "running": False, "healthy": False, "queue_depth": 0,
                "inflight_count": 0, "retained_record_count": 0,
                "last_outcome": None,
            }
            parsed, level = await runtime._runner.run_turn("r1", "chào")
            assert level == 0
            assert parsed.text == BAD_OUTPUT
            assert len(llm.requests) == 1
            assert runtime._runner.filter_enabled is False
            assert runtime._runner.last_filter_verdict is None
            assert runtime._metrics.filter_snapshot()["checks_total"] == 0
            assert pref.records == []
        finally:
            await runtime.stop()

    async def test_filter_exception_fails_open_and_is_observable(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        from services.filter.rule_filter import RuleFilter

        class ExplodingFilter:
            async def start(self) -> None:
                return None

            async def stop(self) -> None:
                return None

            async def health_check(self) -> HealthStatus:
                return HealthStatus.healthy("filter")

            async def check(self, text: str, context: dict[str, Any] | None = None):
                raise RuntimeError("filter exploded")

            def get_metrics(self) -> dict[str, Any]:
                return {"filter_fail_open_total": 1}

        monkeypatch.setattr(
            RuleFilter,
            "from_config",
            classmethod(lambda cls, loader, event_bus=None: ExplodingFilter()),
        )
        runtime, _llm, pref = await _build_runtime(
            monkeypatch,
            tmp_path,
            [BAD_OUTPUT],
            filter_enabled=True,
        )
        try:
            parsed, level = await runtime._runner.run_turn("r1", "chào")
            assert level == 0
            assert parsed.text == BAD_OUTPUT
            assert runtime._runner.last_filter_verdict is not None
            assert runtime._runner.last_filter_verdict.passed is True
            assert runtime._runner.last_filter_verdict.reason.startswith("fail-open")
            metrics = runtime._metrics.filter_snapshot()
            assert metrics["checks_total"] == 1
            assert metrics["fail_open_total"] == 1
            assert pref.records == []
        finally:
            await runtime.stop()


@pytest.mark.asyncio
async def test_local_action_adapters_are_composed_with_independent_feature_lifecycle(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    runtime, _llm, _pref = await _build_runtime(
        monkeypatch, tmp_path, [], filter_enabled=False,
    )
    boundary = runtime._action_adapter_boundary
    assert boundary is not None
    assert boundary.snapshot() == {
        "running": False,
        "speech_enabled": True,
        "avatar_enabled": True,
        "idempotency_records": 0,
        "outcomes": {},
    }
    assert runtime._external_executor_registry.executor_for("speech_delivery") is None
    assert "speech_delivery" not in runtime._action_mock_loop._executors
    assert runtime.operations_snapshot()["embodiment"] == {
        "running": False,
        "enabled": True,
        "active_level": None,
        "active_action_id": None,
        "active_gesture_id": None,
        "counts": {},
        "recent": [],
    }

    await runtime.start()
    try:
        assert boundary.snapshot()["running"] is True
        assert (await boundary.health_check()).state.value == "healthy"
        assert runtime._world_model.query("stream.runtime") is not None
        perception = runtime.operations_snapshot()["perception"]
        assert perception["ingress"]["perception_recent_events"] == 1
        assert perception["adapters"]["chat_perception_adapter"][
            "chat_perception_running"
        ] is True
        assert perception["adapters"]["obs_perception_adapter"][
            "obs_perception_enabled"
        ] is False
        avatar_disabled = await runtime._feature_manager.disable("avatar_action_adapter")
        assert avatar_disabled.ok is True
        assert boundary.avatar_enabled is False
        avatar_enabled = await runtime._feature_manager.enable("avatar_action_adapter")
        assert avatar_enabled.ok is True
        assert boundary.avatar_enabled is True
        speech_disabled = await runtime._feature_manager.disable("speech_action_adapter")
        assert speech_disabled.ok is True
        assert boundary.speech_enabled is False
        speech_enabled = await runtime._feature_manager.enable("speech_action_adapter")
        assert speech_enabled.ok is True
        assert boundary.speech_enabled is True
        assert runtime.operations_snapshot()["local_action_adapters"]["running"] is True
        assert runtime.operations_snapshot()["embodiment"]["running"] is True
        assert runtime.operations_snapshot()["embodiment"]["enabled"] is True
        assert runtime.get_metrics()["embodiment_policy_running"] is True
        avatar_disabled = await runtime._feature_manager.disable("avatar_action_adapter")
        assert avatar_disabled.ok is True
        avatar_result = await runtime.execute_avatar_action(ActionRequest(
            schema_version=1,
            action_id="avatar-disabled",
            capability_id="AVATAR_GESTURE",
            action_type="AVATAR_GESTURE",
            target=None,
            arguments={"gesture_id": "wave"},
            intention_id=None,
            evidence_refs=("event-1",),
            idempotency_key="avatar-disabled",
            priority=0.0,
            requested_at=datetime(2026, 8, 20, tzinfo=timezone.utc),
            transaction_policy="none",
        ))
        assert avatar_result.error_code == "adapter_disabled"
    finally:
        await runtime.stop()
    assert boundary.snapshot()["running"] is False
    assert runtime.operations_snapshot()["embodiment"]["running"] is False


@pytest.mark.asyncio
async def test_late_composition_failure_rolls_back_llm_process_and_dashboard(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv(
        "MAI_DASHBOARD_CONTROL_TOKEN", "test-dashboard-control-token-123456",
    )
    fake_llm = ScriptedStreamLLM([])
    process_events: list[str] = []
    dashboard_events: list[str] = []

    monkeypatch.setattr(
        stream_runtime_module,
        "LlamaCppLLMService",
        SimpleNamespace(from_loader=lambda _loader: fake_llm),
    )
    monkeypatch.setattr(
        stream_runtime_module,
        "setup_from_config",
        lambda _loader, metrics=None: None,
    )
    monkeypatch.setattr(stream_runtime_module, "_make_pref_logger", lambda _loader: None)

    class FakeProcessManager:
        def __init__(self, _config: Any) -> None:
            return None

        async def start(self) -> None:
            process_events.append("start")

        async def stop(self) -> None:
            process_events.append("stop")

    class FakeDashboard:
        async def serve(self) -> None:
            await asyncio.Event().wait()

        async def shutdown(self) -> None:
            dashboard_events.append("shutdown")

    dashboard = FakeDashboard()

    def fake_start_dashboard(**_kwargs: Any):
        task = asyncio.create_task(dashboard.serve(), name="test_dashboard")
        return task, {"task": task, "server": dashboard}, dashboard

    def fail_after_dashboard(**_kwargs: Any) -> None:
        raise LookupError("late composition failure")

    monkeypatch.setattr(
        stream_runtime_module,
        "LlamaServerProcessManager",
        FakeProcessManager,
    )
    monkeypatch.setattr(stream_runtime_module, "start_dashboard", fake_start_dashboard)
    monkeypatch.setattr(
        stream_runtime_module,
        "configure_shutdown_coordinator",
        fail_after_dashboard,
    )

    with pytest.raises(LookupError, match="late composition failure"):
        await stream_runtime_module.build_stream_runtime(
            loader=_loader(tmp_path, filter_enabled=False),
            sources=[FakeInputService()],
            cfg=StreamRuntimeConfig(
                enable_tts=False,
                enable_memory=False,
                enable_autonomy=False,
                enable_dashboard=True,
            ),
        )

    assert fake_llm.started is True
    assert fake_llm.stopped is True
    assert process_events == ["start", "stop"]
    assert dashboard_events == ["shutdown"]


async def test_feature_wiring_failure_after_tts_stack_closes_started_http_overlay(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, ephemeral_subtitle_transport,
) -> None:
    original_status = stream_runtime_module.FeatureManager.get_status

    async def fail_at_phrase_wiring(self, feature_id: str):
        if feature_id == "tts_phrase_synthesis":
            assert ephemeral_subtitle_transport
            assert ephemeral_subtitle_transport[-1].get_metrics()["tts_subtitle_http_running"]
            raise LookupError("failed immediately after TTS stack")
        return await original_status(self, feature_id)

    monkeypatch.setattr(stream_runtime_module.FeatureManager, "get_status", fail_at_phrase_wiring)
    with pytest.raises(LookupError, match="immediately after TTS stack"):
        await _build_runtime(monkeypatch, tmp_path, [], filter_enabled=False)
    subtitle = ephemeral_subtitle_transport[-1]
    assert subtitle.get_metrics()["tts_subtitle_http_running"] is False
    assert subtitle._server_task is None and subtitle._socket is None
