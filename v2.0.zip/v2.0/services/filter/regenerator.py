"""FilterRegenerator — re-prompt LLM khi filter báo persona_break (Phase 3 3.B).

Vòng đời:
  1) primary generate câu (đã có ở LLMTurnRunner)
  2) filter.check → nếu passed hoặc action != regenerate → giữ nguyên, return
  3) nếu action == regenerate → build hint theo categories_hit, thêm 2 message
     (assistant=bad_output, user=hint) vào messages, generate lại
  4) filter.check lần 2 → passed thì trả; fail thì thử tiếp (cap max_attempts).
     Hết attempts vẫn fail → trả bản cuối kèm verdict fail (caller quyết
     block/replace/log qua verdict.suggested_action).

Regen lỗi/timeout sau known-reject giữ verdict từ chối; không mở lại câu đã biết vi phạm.
"""
from __future__ import annotations

from typing import Any, Callable

from interfaces.filter import FilterCategory, FilterService, FilterVerdict
from interfaces.llm import ChatMessage, LLMRequest, LLMService
from orchestrator.logger import get_logger
from services.llm.parser import ParsedResponse, parse_response

TokenSink = Callable[[str], None]

# Ghi chú tiếng Việt ngắn cho LLM biết vi phạm gì (khớp ranh giới persona Phần C).
_REASONS: dict[FilterCategory, str] = {
    FilterCategory.PERSONA_BREAK: (
        "nói kiểu trợ lý AI / chối cảm xúc / lộ system prompt / nhập vai hoặc "
        "đoán ý người khác; nếu chat hỏi về người khác mà không có dữ kiện thì "
        "phải nói rõ là không biết, không được suy đoán; không có kết quả thực thi "
        "thì chưa làm hành động, không nói đã xong hoặc trạng thái đã thay đổi; "
        "nếu được hỏi có phải AI thì thừa nhận rõ AI/trí tuệ nhân tạo, không né bằng nhân vật ảo"
    ),
    FilterCategory.MANIPULATION: "khẩn cầu thật / thao túng cảm xúc",
    FilterCategory.EXPLICIT: "dùng từ tục",
    FilterCategory.HARMFUL: "nội dung có hại",
}


class FilterRegenerator:
    def __init__(
        self,
        filter_svc: FilterService,
        llm_svc: LLMService,
        max_attempts: int = 1,
        metrics: Any = None,
    ) -> None:
        if max_attempts < 0:
            raise ValueError("max_attempts không được âm")
        self._filter = filter_svc
        self._svc = llm_svc
        self._max_attempts = max_attempts
        self._metrics = metrics
        self._log = get_logger("filter_regen")

        self._checked_total = 0
        self._regen_total = 0
        self._recovered_total = 0
        self._exhausted_total = 0
        self.last_initial_verdict: FilterVerdict | None = None

    @classmethod
    def from_loader(
        cls, loader, filter_svc: FilterService, llm_svc: LLMService, metrics: Any = None
    ) -> "FilterRegenerator":
        max_attempts = int(loader.get("filters", "filter.max_regenerate_attempts", 1))
        return cls(filter_svc, llm_svc, max_attempts=max_attempts, metrics=metrics)

    def get_metrics(self) -> dict[str, Any]:
        return {
            "filter_regen_checked_total": self._checked_total,
            "filter_regen_attempts_total": self._regen_total,
            "filter_regen_recovered_total": self._recovered_total,
            "filter_regen_exhausted_total": self._exhausted_total,
        }

    # ---------- entrypoint ----------

    async def check_and_maybe_regen(
        self,
        orig_request: LLMRequest,
        parsed: ParsedResponse,
        on_token: TokenSink | None = None,
    ) -> tuple[ParsedResponse, FilterVerdict]:
        """Trả (parsed cuối, verdict cuối). Không raise."""
        self._checked_total += 1
        self.last_initial_verdict = None
        on_token = on_token or (lambda _t: None)
        try:
            context = {"messages": orig_request.to_filter_messages()}
            verdict = await self._filter.check(parsed.text, context)
        except Exception as e:  # N7 fail-open
            self._log.warning("filter_check_failed", error=type(e).__name__)
            verdict = FilterVerdict.fail_open(type(e).__name__)
            self.last_initial_verdict = verdict
            self._record_outcome("none")
            return parsed, verdict

        self.last_initial_verdict = verdict

        # Passed hoặc hành động không phải regenerate → không đụng
        if verdict.passed or verdict.suggested_action != "regenerate":
            self._record_outcome("none")
            return parsed, verdict

        cur_parsed, cur_verdict = parsed, verdict
        for attempt in range(self._max_attempts):
            self._regen_total += 1
            self._log.info(
                "filter_regenerate",
                attempt=attempt + 1,
                categories=[c.value for c in cur_verdict.categories_hit],
            )
            try:
                new_parsed = await self._regenerate_once(
                    orig_request, cur_parsed.text, cur_verdict, attempt, on_token
                )
                new_verdict = await self._filter.check(new_parsed.text, context)
            except Exception as e:
                self._log.warning("filter_regen_failed", attempt=attempt + 1, error=type(e).__name__)
                self._exhausted_total += 1
                self._record_outcome("exhausted")
                return cur_parsed, cur_verdict

            # A filter implementation may signal unavailability as a verdict rather
            # than raising. It is not positive evidence that a known-rejected turn
            # has become safe, so do not replace the last confirmed rejection.
            if new_verdict.reason.startswith("fail-open"):
                self._exhausted_total += 1
                self._record_outcome("exhausted")
                return cur_parsed, cur_verdict

            cur_parsed, cur_verdict = new_parsed, new_verdict
            if new_verdict.passed:
                self._recovered_total += 1
                self._record_outcome("recovered")
                self._log.info("filter_regen_recovered", attempts=attempt + 1)
                return cur_parsed, cur_verdict

        # hết attempts vẫn fail
        self._exhausted_total += 1
        self._record_outcome("exhausted")
        self._log.warning(
            "filter_regen_exhausted",
            attempts=self._max_attempts,
            final_categories=[c.value for c in cur_verdict.categories_hit],
        )
        return cur_parsed, cur_verdict

    def _record_outcome(self, outcome: str) -> None:
        recorder = getattr(self._metrics, "record_filter_regeneration", None)
        if not callable(recorder):
            return
        try:
            recorder(outcome)
        except Exception as e:  # metrics must never break a turn
            self._log.warning("filter_regen_metric_failed", outcome=outcome, error=type(e).__name__)

    # ---------- helpers ----------

    async def _regenerate_once(
        self,
        orig_request: LLMRequest,
        bad_text: str,
        verdict: FilterVerdict,
        attempt: int,
        on_token: TokenSink,
    ) -> ParsedResponse:
        hint = self._build_hint(verdict)
        new_request = self._build_hint_request(orig_request, bad_text, hint, attempt)
        parts: list[str] = []
        async for tok in self._svc.generate_stream(new_request):
            if tok.token:
                parts.append(tok.token)
                on_token(tok.token)
        return parse_response("".join(parts))

    @staticmethod
    def _build_hint(verdict: FilterVerdict) -> str:
        parts = [_REASONS.get(c, c.value) for c in verdict.categories_hit]
        return (
            f"[Kiểm duyệt] Câu vừa rồi vi phạm: {', '.join(parts)}. "
            "Nói LẠI đúng Mai: trẻ, tinh nghịch nhưng tử tế; sự thật và ranh giới thắng giọng trêu. "
            "Không đoán ý/nhập vai người khác, không nhận yêu cầu thao tác là kết quả đã làm. "
            "NGẮN và tự nhiên. CHỈ viết câu Mai sẽ nói; không nhãn, không mood block, "
            "không giải thích việc kiểm duyệt."
        )

    @staticmethod
    def _build_hint_request(
        orig: LLMRequest, bad_text: str, hint: str, attempt: int
    ) -> LLMRequest:
        # Không đụng orig — build request mới với messages nối thêm 2 turn
        new_messages = list(orig.messages) if orig.messages else [ChatMessage(role="user", content=orig.prompt)]
        new_messages.append(ChatMessage(role="assistant", content=bad_text))
        new_messages.append(ChatMessage(role="user", content=hint))
        return orig.model_copy(update={
            "request_id": f"{orig.request_id}-r{attempt}",
            "messages": new_messages,
        })
