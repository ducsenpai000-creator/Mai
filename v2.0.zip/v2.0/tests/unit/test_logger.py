"""Test logger: JSONL sink, rotation, turn schema (ARCHITECTURE 9.3, 13.8)."""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

import pytest

from orchestrator.config_loader import ConfigLoader
from orchestrator.logger import (
    JsonlWriter,
    TurnLogger,
    bind_log_session,
    get_logger,
    setup_from_config,
    setup_logging,
)
from services.data.sanitize import metadata_record, metadata_reference

REPO_ROOT = Path(__file__).resolve().parents[2]
PRIVATE_TEXT = "SYNTHETIC_RUNTIME_CHAT Nguyễn Mẫu viewer@example.invalid 0900000000"


def _turn_record(turn_id: int, **overrides):
    record = {
        "schema_version": 3,
        "turn_id": turn_id,
        "request_id": f"request-{turn_id}",
        "kind": "chat_reply",
    }
    record.update(overrides)
    return record


class TestJsonlWriter:
    def test_write_appends_one_line_per_record(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        w = JsonlWriter(path)
        w.write({"turn_id": 1})
        w.write({"turn_id": 2})
        lines = path.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 2
        first = json.loads(lines[0])
        second = json.loads(lines[1])
        assert first["turn_id"] == 1 and second["turn_id"] == 2
        for record in (first, second):
            assert record["schema_version"] == 1
            assert record["source"] == "events"
            assert record["timestamp"].endswith("+00:00")
            assert "session_id" in record

    def test_creates_parent_dir(self, tmp_path: Path) -> None:
        path = tmp_path / "nested" / "deep" / "events.jsonl"
        JsonlWriter(path).write({"turn_id": 1})
        assert path.exists()

    def test_ordinary_vietnamese_chat_is_not_persisted_even_without_pii(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        JsonlWriter(path).write({"user_text": "Xin chào Mai", "mai_text": "Chào cậu nhé"})
        encoded = path.read_text(encoding="utf-8")
        assert "Xin chào Mai" not in encoded and "Chào cậu nhé" not in encoded
        assert json.loads(encoded)["user_text"] is None
        assert json.loads(encoded)["mai_text"] is None

    def test_arbitrary_objects_are_dropped_without_stringification(self, tmp_path: Path) -> None:
        class PrivateObject:
            def __str__(self) -> str:
                raise AssertionError("private object must not reach serialization")

        path = tmp_path / "events.jsonl"
        JsonlWriter(path).write({"obj": PrivateObject(), "user_text": PrivateObject()})
        record = json.loads(path.read_text(encoding="utf-8").strip())
        assert "obj" not in record
        assert record["user_text"] is None

    def test_free_form_event_fields_are_omitted_not_only_pii_masked(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        JsonlWriter(path).write({
            "event": "failed",
            "error": "token sk_live_abcdefghij1234567890xyz for @real_user",
            "viewer_id": "raw-platform-id",
        })
        record = json.loads(path.read_text(encoding="utf-8"))
        assert record["error"] is None
        assert record["viewer_id"].startswith("v_")

    def test_rotation_when_size_exceeded(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        # max_size 0 MB → mọi write sau lần đầu đều rotate
        w = JsonlWriter(path, max_size_mb=0, keep_files=3)
        w.write({"turn_id": 1})
        w.write({"turn_id": 2})
        assert path.exists()
        assert path.with_suffix(".jsonl.1").exists()
        assert json.loads(path.read_text(encoding="utf-8").strip())["turn_id"] == 2
        assert json.loads(path.with_suffix(".jsonl.1").read_text(encoding="utf-8").strip())["turn_id"] == 1

    def test_rotation_respects_keep_files(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        w = JsonlWriter(path, max_size_mb=0, keep_files=2)
        for i in range(5):
            w.write({"turn_id": i})
        assert path.with_suffix(".jsonl.1").exists()
        assert path.with_suffix(".jsonl.2").exists()
        # keep_files=2 → không được tạo .3
        assert not path.with_suffix(".jsonl.3").exists()
        archives = list(tmp_path.glob("events.jsonl.archive.*"))
        assert len(archives) == 2
        records = [path, path.with_suffix(".jsonl.1"), path.with_suffix(".jsonl.2"),
                   *archives]
        assert sorted(json.loads(p.read_text(encoding="utf-8"))["turn_id"] for p in records) == list(range(5))

    def test_rotation_disabled_keeps_appending(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        w = JsonlWriter(path, max_size_mb=0, keep_files=3, rotation_enabled=False)
        w.write({"turn_id": 1})
        w.write({"turn_id": 2})
        assert not path.with_suffix(".jsonl.1").exists()
        assert len(path.read_text(encoding="utf-8").strip().split("\n")) == 2

    def test_permission_failure_is_buffered_and_recovers(
        self, tmp_path: Path, monkeypatch,
    ) -> None:
        path = tmp_path / "events.jsonl"
        errors: list[tuple[str, str]] = []
        writer = JsonlWriter(
            path,
            degraded_buffer_records=2,
            error_callback=lambda sink, error: errors.append((sink, error)),
        )
        original_open = Path.open
        blocked = True

        def guarded_open(target, *args, **kwargs):
            if blocked and target == path:
                raise PermissionError("read-only log directory")
            return original_open(target, *args, **kwargs)

        monkeypatch.setattr(Path, "open", guarded_open)
        assert writer.write({"turn_id": 1}) is False
        metrics = writer.get_metrics()
        assert metrics["logging_sink_degraded"] is True
        assert metrics["logging_sink_buffered_records"] == 1
        assert errors == [("events", "PermissionError")]

        blocked = False
        assert writer.flush() is True
        assert json.loads(path.read_text(encoding="utf-8"))["turn_id"] == 1
        assert writer.get_metrics()["logging_sink_degraded"] is False

    def test_degraded_buffer_is_bounded(self, tmp_path: Path, monkeypatch) -> None:
        path = tmp_path / "events.jsonl"
        writer = JsonlWriter(path, degraded_buffer_records=2)

        def fail_open(target, *args, **kwargs):
            raise PermissionError("blocked")

        monkeypatch.setattr(Path, "open", fail_open)
        for value in range(3):
            assert writer.write({"turn_id": value}) is False
        metrics = writer.get_metrics()
        assert metrics["logging_sink_buffered_records"] == 2
        assert metrics["logging_sink_buffer_dropped_total"] == 1
        assert metrics["logging_sink_errors_total"] == 3

    def test_nested_transcript_dpo_context_and_private_keys_never_reach_disk(self, tmp_path: Path) -> None:
        private_fields = (
            "user_text", "mai_text", "context_block", "chosen", "rejected", "original",
            "corrected", "reason", "summary", "error", "exception",
        )
        source = {
            **{key: PRIVATE_TEXT for key in private_fields},
            "session_id": PRIVATE_TEXT, "request_id": PRIVATE_TEXT, "event_id": PRIVATE_TEXT,
            "incident_id": PRIVATE_TEXT, "event": PRIVATE_TEXT, "source": PRIVATE_TEXT, "kind": PRIVATE_TEXT,
            "turn_id": 8, "latency_ms": 1.5, "parse_ok": True,
            "filter_verdict": {"passed": True, "reason": PRIVATE_TEXT, PRIVATE_TEXT: 1},
            "mood_cause": {"event_id": PRIVATE_TEXT, "alias": PRIVATE_TEXT, "summary": PRIVATE_TEXT},
            "prompt_ref": {"context_block": PRIVATE_TEXT, "user_text": PRIVATE_TEXT},
            "messages": [{"role": "user", "content": PRIVATE_TEXT}],
            PRIVATE_TEXT: {"turn_id": 99},
        }
        before = deepcopy(source)
        path = tmp_path / "events.jsonl"
        writer = JsonlWriter(path)

        assert writer.write(source) is True
        encoded = path.read_text(encoding="utf-8")
        record = json.loads(encoded)

        assert source == before
        for marker in ("SYNTHETIC_RUNTIME_CHAT", "Nguyễn Mẫu", "viewer@example.invalid", "0900000000"):
            assert marker not in encoded
        assert record["turn_id"] == 8 and record["latency_ms"] == 1.5 and record["parse_ok"] is True
        assert all(record[key] is None for key in private_fields)
        for key in ("session_id", "request_id", "event_id", "incident_id", "event", "source", "kind"):
            assert record[key] == metadata_reference(PRIVATE_TEXT)
        assert record["filter_verdict"]["passed"] is True
        assert record["filter_verdict"]["reason"] is None
        assert "messages" not in record or record["messages"] is None
        metrics = writer.get_metrics()
        assert metrics["logging_sink_metadata_only"] is True
        assert metrics["logging_sink_projected_total"] == 1
        assert metrics["logging_sink_dropped_fields_total"] > 0

    def test_metadata_projection_is_closed_finite_and_reference_idempotent(self) -> None:
        source = {
            "session_id": "private-session", "request_id": "private-session",
            "viewer_id": "private-viewer", "turn_id": 3,
            "latency_ms": float("inf"), "ttft_ms": float("nan"),
            "parse_ok": True, "mood_dominant": "vui", "level_used": 0,
            "unknown_field": {"description": PRIVATE_TEXT},
        }
        original = deepcopy(source)
        # NaN is not equal to itself, so compare its original identity separately.
        projected = metadata_record(source)
        assert projected == metadata_record(projected)
        assert projected["session_id"] == projected["request_id"] == metadata_reference("private-session")
        assert projected["viewer_id"].startswith("v_") and projected["viewer_id"] != "private-viewer"
        assert projected["turn_id"] == 3 and projected["parse_ok"] is True
        assert projected["mood_dominant"] == "vui" and projected["level_used"] == 0
        assert "unknown_field" not in projected
        assert projected.get("latency_ms") is None and projected.get("ttft_ms") is None
        assert source.keys() == original.keys() and source["session_id"] == original["session_id"]
        assert source["unknown_field"] == original["unknown_field"]

    def test_all_known_nested_containers_discard_text_and_unknown_keys(self) -> None:
        from services.data.sanitize import _METADATA_CONTAINERS

        for key in _METADATA_CONTAINERS:
            source = {key: {"count": 2, "text": PRIVATE_TEXT, "reason": PRIVATE_TEXT,
                            "details": {"summary": PRIVATE_TEXT, PRIVATE_TEXT: True},
                            PRIVATE_TEXT: {"total": 4}}}
            before = deepcopy(source)
            projected = metadata_record(source)
            assert projected[key]["count"] == 2
            assert projected[key]["text"] is None and projected[key]["reason"] is None
            assert "SYNTHETIC_RUNTIME_CHAT" not in json.dumps(projected, ensure_ascii=False)
            assert source == before

    def test_finite_diagnostic_codes_remain_useful_without_arbitrary_text(self) -> None:
        projected = metadata_record({
            "event": "state_transition", "from": "IDLE", "to": "THINKING",
            "error": "ValueError", "filter_verdict": {
                "passed": False, "categories": ["persona_break", "harmful", PRIVATE_TEXT],
                "reason": PRIVATE_TEXT,
            },
        })
        assert projected["event"] == "state_transition"
        assert projected["from"] == "IDLE" and projected["to"] == "THINKING"
        assert projected["error"] == "ValueError"
        assert projected["filter_verdict"]["categories"] == [
            "persona_break", "harmful", metadata_reference(PRIVATE_TEXT),
        ]
        assert projected["filter_verdict"]["reason"] is None
        assert metadata_record({"error": PRIVATE_TEXT})["error"] is None

    def test_degraded_buffer_and_flush_contain_metadata_only(self, tmp_path: Path, monkeypatch) -> None:
        path = tmp_path / "events.jsonl"
        writer = JsonlWriter(path)
        real_open = Path.open
        blocked = True

        def guarded_open(target, *args, **kwargs):
            if target == path and blocked:
                raise PermissionError(PRIVATE_TEXT)
            return real_open(target, *args, **kwargs)

        monkeypatch.setattr(Path, "open", guarded_open)
        assert writer.write({"turn_id": 1, "user_text": PRIVATE_TEXT, "error": PRIVATE_TEXT}) is False
        assert len(writer._buffer) == 1
        assert PRIVATE_TEXT not in writer._buffer[0]
        blocked = False
        assert writer.flush() is True
        encoded = path.read_text(encoding="utf-8")
        assert PRIVATE_TEXT not in encoded
        assert json.loads(encoded)["user_text"] is None

    def test_new_runtime_write_does_not_rewrite_existing_historical_rows(self, tmp_path: Path) -> None:
        path = tmp_path / "turns.jsonl"
        historical = b'{"user_text":"SYNTHETIC_OLD_CONSENTED_DATA"}\n'
        path.write_bytes(historical)
        JsonlWriter(path, rotation_enabled=False).write({"turn_id": 2, "user_text": PRIVATE_TEXT})
        assert path.read_bytes().startswith(historical)
        assert PRIVATE_TEXT not in path.read_text(encoding="utf-8").splitlines()[-1]

    def test_projection_failure_does_not_serialize_or_buffer_raw_record(self, tmp_path: Path, monkeypatch) -> None:
        from services.data import sanitize

        path = tmp_path / "events.jsonl"
        errors: list[tuple[str, str]] = []
        writer = JsonlWriter(path, error_callback=lambda source, error: errors.append((source, error)))

        def unavailable(_record):
            raise ValueError(PRIVATE_TEXT)

        monkeypatch.setattr(sanitize, "metadata_record", unavailable)
        assert writer.write({"user_text": PRIVATE_TEXT}) is False
        assert not path.exists()
        assert list(writer._buffer) == []
        assert errors == [("events", "ValueError")]
        assert writer.get_metrics()["logging_sink_errors_total"] == 1


class TestTurnLogger:
    def test_custom_attempt_and_delivery_writers_only_receive_metadata(self) -> None:
        attempts: list[dict] = []
        outcomes: list[dict] = []

        class Capture:
            def __init__(self, records: list[dict]) -> None:
                self.records = records

            def write(self, record: dict) -> bool:
                self.records.append(deepcopy(record))
                return True

        logger = TurnLogger(Capture(attempts), Capture(outcomes))
        source = _turn_record(1, user_text=PRIVATE_TEXT, mai_text=PRIVATE_TEXT,
                              context_block=PRIVATE_TEXT, session_id="private-session")
        before = deepcopy(source)
        logger.log_turn(source)
        logger.log_delivery({"schema_version": 1, "record_type": "delivery_outcome",
                             "session_id": "private-session", "request_id": "request-1",
                             "turn_id": 1, "delivered": True})
        assert source == before
        assert attempts[0]["user_text"] is None and attempts[0]["mai_text"] is None
        assert attempts[0]["context_block"] is None
        assert PRIVATE_TEXT not in json.dumps([attempts, outcomes], ensure_ascii=False)
        assert outcomes[0]["delivered"] is True
        assert outcomes[0]["session_id"] == attempts[0]["session_id"] == metadata_reference("private-session")
        assert outcomes[0]["request_id"] == attempts[0]["request_id"] == metadata_reference("request-1")

    def test_log_turn_adds_timestamp(self, tmp_path: Path) -> None:
        path = tmp_path / "turns.jsonl"
        tl = TurnLogger(JsonlWriter(path))
        tl.log_turn(_turn_record(1, user_text="hi"))
        record = json.loads(path.read_text(encoding="utf-8").strip())
        assert record["turn_id"] == 1
        assert "timestamp" in record

    def test_log_turn_preserves_given_timestamp(self, tmp_path: Path) -> None:
        path = tmp_path / "turns.jsonl"
        tl = TurnLogger(JsonlWriter(path))
        tl.log_turn(_turn_record(2, timestamp="2026-07-30T00:00:00Z"))
        record = json.loads(path.read_text(encoding="utf-8").strip())
        assert record["timestamp"] == "2026-07-30T00:00:00+00:00"

    def test_session_binding_propagates_to_writer(self, tmp_path: Path) -> None:
        path = tmp_path / "events.jsonl"
        bind_log_session("session-test")
        JsonlWriter(path).write({"event": "x"})
        bind_log_session(None)
        record = json.loads(path.read_text(encoding="utf-8"))
        assert record["session_id"] == metadata_reference("session-test")

    def test_turn_schema_fields_roundtrip(self, tmp_path: Path) -> None:
        """Schema ARCHITECTURE 9.3 — nested dict/list phải giữ nguyên."""
        path = tmp_path / "turns.jsonl"
        tl = TurnLogger(JsonlWriter(path))
        turn = _turn_record(
            12345,
            mood_state={"vui": 7, "buon": 0},
            mood_cause={"event_id": "chat-1", "alias": "viewer"},
            filter_verdict={"passed": True, "categories": []},
        )
        tl.log_turn(turn)
        record = json.loads(path.read_text(encoding="utf-8").strip())
        assert record["mood_state"]["vui"] == 7
        assert record["mood_cause"]["event_id"] == metadata_reference("chat-1")
        assert record["mood_cause"]["alias"] is None
        assert record["filter_verdict"]["passed"] is True


class TestSetupLogging:
    def test_events_go_to_jsonl(self, tmp_path: Path) -> None:
        setup_logging(log_dir=tmp_path, console_enabled=False)
        log = get_logger("test")
        log.info("state_transition", **{"from": "IDLE", "to": "THINKING"})
        content = (tmp_path / "events.jsonl").read_text(encoding="utf-8")
        record = json.loads(content.strip().split("\n")[-1])
        assert record["event"] == "state_transition"
        assert record["from"] == "IDLE" and record["to"] == "THINKING"
        assert record["level"] == "info"
        assert "timestamp" in record
        assert record["schema_version"] == 1
        assert record["source"] == "events"

    def test_level_filter_drops_debug_when_info(self, tmp_path: Path) -> None:
        setup_logging(level="INFO", log_dir=tmp_path, console_enabled=False)
        log = get_logger("test")
        log.debug("should_not_appear")
        log.info("should_appear")
        content = (tmp_path / "events.jsonl").read_text(encoding="utf-8")
        assert metadata_reference("should_not_appear") not in content
        assert metadata_reference("should_appear") in content

    @pytest.mark.parametrize("console_enabled", [True, False])
    def test_console_and_jsonl_exception_paths_do_not_persist_or_print_transcript(
        self, tmp_path: Path, capsys, console_enabled: bool,
    ) -> None:
        setup_logging(log_dir=tmp_path, console_enabled=console_enabled, console_colors=False)
        logger = get_logger("metadata-test")
        try:
            raise ValueError(PRIVATE_TEXT)
        except ValueError:
            logger.exception("runtime_failure", user_text=PRIVATE_TEXT, context_block=PRIVATE_TEXT,
                             error=PRIVATE_TEXT, stack_info=True, **{PRIVATE_TEXT: True})
        captured = capsys.readouterr()
        encoded = (tmp_path / "events.jsonl").read_text(encoding="utf-8")
        for output in (captured.out, captured.err, encoded):
            for marker in ("SYNTHETIC_RUNTIME_CHAT", "viewer@example.invalid", "0900000000"):
                assert marker not in output
        record = json.loads(encoded.strip().splitlines()[-1])
        assert record["user_text"] is None and record["context_block"] is None
        assert record["error"] is None

    def test_jsonl_disabled_writes_no_events_file(self, tmp_path: Path) -> None:
        setup_logging(log_dir=tmp_path, console_enabled=False, jsonl_enabled=False)
        get_logger("test").info("nowhere")
        assert not (tmp_path / "events.jsonl").exists()

    def test_returns_working_turn_logger(self, tmp_path: Path) -> None:
        turn_logger = setup_logging(log_dir=tmp_path, console_enabled=False)
        turn_logger.log_turn(_turn_record(7))
        record = json.loads((tmp_path / "turns.jsonl").read_text(encoding="utf-8").strip())
        assert record["turn_id"] == 7

    def test_setup_from_config_uses_real_yaml(self, tmp_path: Path) -> None:
        loader = ConfigLoader(REPO_ROOT / "config")
        loader.load_all()
        # config thật trỏ log_dir="logs"; test không ghi vào repo nên chỉ verify
        # setup chạy được và trả TurnLogger, còn ghi file test riêng ở trên.
        assert loader.get("logging", "jsonl.turns_file") == "turns.jsonl"
        assert loader.get("logging", "level") == "INFO"
        assert loader.get("logging", "rotation.max_size_mb") == 100

    def test_setup_from_config_creates_local_privacy_salt(self, tmp_path: Path) -> None:
        salt_path = tmp_path / "private" / "salt.bin"

        class Loader:
            def get(self, name, key, default=None):
                if (name, key) == ("data_privacy", "privacy.viewer_hash_salt_file"):
                    return str(salt_path)
                if (name, key) == ("logging", "jsonl.dir"):
                    return str(tmp_path / "logs")
                return default

        setup_from_config(Loader())
        assert salt_path.exists()
        assert len(salt_path.read_bytes()) >= 32
