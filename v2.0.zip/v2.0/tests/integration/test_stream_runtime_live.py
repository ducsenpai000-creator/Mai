"""Local hardware acceptance through the production runtime, with isolated state.

Requires cached llama.cpp/VieNeu/embedding assets and an audio output device.
Synthetic chat never connects to or posts on a public platform. Marker `llm`
keeps hardware checks out of the normal offline suite.
"""
from __future__ import annotations

import asyncio
import json
import hashlib
import re
import shutil
import secrets
import socket
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Callable

import httpx
import pytest

from interfaces.base import HealthStatus
from interfaces.input import EventSource, InputEvent, InputService
from interfaces.tts import TTSDeliveryMode, TTSDeliveryResult
from orchestrator.config_loader import ConfigLoader
from orchestrator.credential_contract import dashboard_control_token_reference
from orchestrator.stream_runtime import StreamRuntimeConfig, build_stream_runtime
from services.tts.subtitle_fallback import SubtitleFallbackService
from services.data.sanitize import metadata_record


ROOT = Path(__file__).resolve().parents[2]
pytestmark = pytest.mark.llm
PRIVACY_BOUND_FILES = (
    "interfaces/operations.py", "orchestrator/runtime_operations.py",
    "orchestrator/stream_runtime.py", "services/operations/shutdown_coordinator.py",
    "services/operations/standalone_snapshot.py", "tests/integration/test_stream_runtime_live.py",
    "orchestrator/logger.py", "services/data/sanitize.py", "services/llm/llm_turn.py",
    "config/logging.yaml", "config/data_privacy.yaml", "config/features.yaml", "config/models.yaml",
    "scripts/stream_youtube.py", "scripts/stream_discord.py", "scripts/live_preflight.py",
    "services/tts/subtitle_fallback.py", "services/tts/tts_pipeline.py", "orchestrator/runtime_tts.py",
    "interfaces/tts.py",
    "dashboard/dashboard_server.py", "scripts/export_dataset.py", "scripts/post_stream_review.py",
    "orchestrator/runtime_config_validation.py", "services/relationship/store.py",
    "services/memory/extractor.py", "services/memory/config.py", "config/system.yaml",
    "services/operations/incident_log.py", "services/operations/dashboard_data_source.py",
    "services/operations/post_stream_review.py",
)


@pytest.fixture(autouse=True)
async def ephemeral_subtitle_transport(monkeypatch: pytest.MonkeyPatch) -> AsyncIterator[None]:
    """Keep production config validation; only the test HTTP transport uses port 0."""
    original_factory = SubtitleFallbackService.from_loader
    created: list[SubtitleFallbackService] = []

    class TransportLoader:
        def __init__(self, loader: Any) -> None:
            self.loader = loader

        def get(self, name: str, key: str, default: Any = None) -> Any:
            if (name, key) == ("models", "tts_fallback.overlay_port"):
                return 0
            return self.loader.get(name, key, default)

    def factory(cls: type[SubtitleFallbackService], loader: Any, **kwargs: Any) -> SubtitleFallbackService:
        service = original_factory(TransportLoader(loader), **kwargs)
        created.append(service)
        return service

    monkeypatch.setattr(SubtitleFallbackService, "from_loader", classmethod(factory))
    yield
    for service in reversed(created):
        await service.stop()


class LocalChat(InputService):
    service_id = "input_local_acceptance"

    def __init__(self) -> None:
        self.queue: asyncio.Queue[InputEvent] = asyncio.Queue(maxsize=4)
        self.running = False

    async def start(self) -> None:
        self.running = True

    async def stop(self) -> None:
        self.running = False

    async def health_check(self) -> HealthStatus:
        return HealthStatus.healthy(self.service_id)

    def get_metrics(self) -> dict[str, int]:
        return {"local_acceptance_queue_depth": self.queue.qsize()}

    async def event_stream(self) -> AsyncIterator[InputEvent]:
        while self.running:
            yield await self.queue.get()

    async def send(self, event_id: str, text: str) -> None:
        await self.queue.put(InputEvent(
            event_id=event_id,
            timestamp=datetime.now(timezone.utc),
            source=EventSource.CHAT_YOUTUBE,
            user_id="local-acceptance-viewer",
            content=text,
        ))


async def _until(check: Callable[[], bool], timeout_s: float) -> None:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if check():
            return
        await asyncio.sleep(0.1)
    raise AssertionError("production runtime did not reach the expected verified state")


def _isolated_loader(tmp_path: Path) -> ConfigLoader:
    loader = ConfigLoader(ROOT / "config")
    loader.load_all()
    # Overrides only affect this test process; production YAML is not changed.
    paths = loader._data["system"]["paths"]
    for name in ("data_dir", "log_dir", "backup_dir", "cache_dir"):
        paths[name] = str(tmp_path / name)
    paths["db_file"] = str(tmp_path / "mai.db")
    loader._data["logging"]["jsonl"]["dir"] = str(tmp_path / "logs")
    loader._data["logging"]["console"]["enabled"] = False
    loader._data["data_privacy"]["privacy"]["viewer_hash_salt_file"] = str(
        tmp_path / "privacy_salt.bin",
    )
    loader._data["models"]["tts_fallback"]["output_file"] = None
    loader._data["animation"]["animation"]["token_file"] = str(tmp_path / "vts_token.txt")
    operations = loader._data["operations"]
    operations["shutdown"]["snapshot_file"] = str(tmp_path / "last_runtime_snapshot.json")
    operations["incident_log"]["file"] = str(tmp_path / "incidents.jsonl")
    operations["dashboard_standalone"]["operator_audit_file"] = str(tmp_path / "audit.jsonl")
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        loader._data["system"]["dashboard"]["port"] = listener.getsockname()[1]
    return loader


async def test_real_runtime_audio_fallback_dashboard_and_verified_continuity(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Fail promptly on a missing cache instead of silently downloading during live.
    monkeypatch.setenv("HF_HUB_OFFLINE", "1")
    monkeypatch.setenv("TRANSFORMERS_OFFLINE", "1")
    loader = _isolated_loader(tmp_path)
    secret = secrets.token_urlsafe(32)
    monkeypatch.setenv(dashboard_control_token_reference(loader), secret)
    source = LocalChat()
    deliveries: list[TTSDeliveryResult] = []
    spoken_texts: list[str] = []
    inputs = (
        "Mai ơi, chào mọi người bằng một câu ngắn nhé!",
        "Mai ơi, xác nhận vẫn đọc được chat bằng một câu ngắn nhé.",
    )
    hashes = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in PRIVACY_BOUND_FILES}
    print("\nLIVE: building production LLM/TTS/memory/dashboard stack", flush=True)
    runtime = await build_stream_runtime(
        loader=loader, sources=[source],
        cfg=StreamRuntimeConfig(
            enable_tts=True, enable_memory=True,
            enable_autonomy=False, enable_dashboard=True,
        ),
    )
    try:
        assert runtime._tts_svc is not None, "real VieNeu failed startup; subtitle-only is insufficient"
        assert runtime._audio_player is not None
        assert runtime._tts_pipeline.enabled is True
        original_speak = runtime._director_loop._speak

        async def observed_speak(request_id: str, text: str) -> TTSDeliveryResult:
            result = await original_speak(request_id, text)
            deliveries.append(result)
            if result.delivered:
                spoken_texts.append(text)
            return result

        runtime._director_loop._speak = observed_speak
        runtime._action_adapter_boundary._speech_executor._speak = observed_speak
        await runtime.start()
        timeout = (
            loader.get("models", "llm_canned.timeout_primary_s")
            * (loader.get("director", "director.speech_style.max_regenerations") + 1)
            + loader.get("models", "tts.timeout_primary_s")
            * loader.get("director", "director.speech_style.max_sentences")
            + loader.get("kernel", "tick_seconds") * 3
        )
        print("LIVE: queued synthetic chat; waiting for real audio + commit", flush=True)
        await source.send("live-audio", inputs[0])
        await _until(lambda: runtime.get_metrics()["continuity_commit_total"] >= 1, timeout)
        assert deliveries[0].delivered is True
        assert deliveries[0].mode is TTSDeliveryMode.AUDIO
        assert runtime._audio_player.get_metrics()["audio_chunks_played"] > 0
        assert runtime._llm_svc.get_metrics()["llm_last_tokens_out"] > 0
        assert runtime._runner.last_filter_verdict.passed is True
        assert runtime.get_metrics()["continuity_inconsistency_total"] == 0

        port = loader.get("system", "dashboard.port")
        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}") as client:
            snapshot = await client.get("/api/snapshot")
            assert snapshot.status_code == 200
            denied = await client.post("/api/emergency_stop")
            assert denied.status_code == 403
            headers = {"X-Mai-Operator-Token": secret}
            stopped = await client.post("/api/emergency_stop", headers=headers)
            assert stopped.status_code == 200
            assert runtime.get_metrics()["emergency_stop_latched"] is True
            count_before = runtime.get_metrics()["continuity_commit_total"]
            suppressed = await original_speak("live-held", "Câu này phải bị chặn.")
            assert suppressed.delivered is False
            assert runtime.get_metrics()["continuity_commit_total"] == count_before
            resumed = await client.post("/api/resume", headers=headers)
            assert resumed.status_code == 200
            assert runtime.get_metrics()["emergency_stop_latched"] is False

        # Rehearse a primary-TTS outage through the same generation/delivery path.
        runtime._tts_pipeline._primary = None
        print("LIVE: rehearsing subtitle fallback after TTS outage", flush=True)
        await source.send("live-subtitle", inputs[1])
        await _until(lambda: runtime.get_metrics()["continuity_commit_total"] >= 2, timeout)
        assert deliveries[-1].delivered is True
        assert deliveries[-1].mode is TTSDeliveryMode.SUBTITLE
        async with httpx.AsyncClient(base_url=runtime._subtitle_svc.overlay_url, trust_env=False) as client:
            overlay = await client.get("/subtitle")
            assert overlay.status_code == 200 and "no-store" in overlay.headers["cache-control"]
            overlay_text = overlay.json()["text"]
            assert overlay_text.strip()
            assert " ".join(overlay_text.split()) == " ".join(spoken_texts[-1].split())
        assert not (tmp_path / "subtitle.txt").exists()
        metrics = runtime.get_metrics()
        assert metrics["continuity_inconsistency_total"] == 0
        assert metrics["outcome_committer_total"].get("COMMITTED", 0) >= 2
        assert (await runtime._memory.health_check()).is_ok
        assert runtime._agent_state is not None
        ram_text = json.dumps(runtime._agent_state.snapshot().to_dict(), ensure_ascii=False)
        for text in inputs:
            assert text in ram_text, "privacy test needs the actual known chat in live RAM first"
        report = {
            "schema_version": 1,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "product_version": loader.get("system", "app.version"),
            "core_pipeline_ready": True,
            "synthetic_platform_input": True,
            "public_broadcast_verified": False,
            "operator_approved": False, "release_gate_eligible": False,
            "file_hashes": hashes,
            "audio_delivery": True, "subtitle_fallback": True,
            "subtitle_ram_verified": True,
            "subtitle_transport_test_ephemeral_port": True,
            "dashboard_auth": True, "emergency_resume": True,
            "verified_commits": metrics["continuity_commit_total"],
            "continuity_inconsistencies": metrics["continuity_inconsistency_total"],
            "semantic_memory_available": metrics.get("memory_fb_primary_available", False),
            "llm_ttft_ms": runtime._llm_svc.get_metrics().get("llm_last_ttft_ms"),
            "tts_ttfa_ms": runtime._tts_svc.get_metrics().get("tts_last_ttfa_ms"),
        }
    finally:
        print("LIVE: stopping owned services", flush=True)
        await runtime.stop()
    assert runtime.get_metrics()["runtime_running"] is False
    assert runtime._llama_process_manager.process is None
    assert runtime._subtitle_svc.get_metrics()["tts_subtitle_retained_chars"] == 0
    assert runtime._subtitle_svc.get_metrics()["tts_subtitle_http_running"] is False
    snapshot_text = (tmp_path / "last_runtime_snapshot.json").read_text(encoding="utf-8")
    persisted = json.loads(snapshot_text)
    assert persisted["metadata_only"] is True
    assert persisted["privacy_schema_version"] == 1
    for text in inputs:
        assert text not in snapshot_text, "shutdown persisted a known live-RAM conversation"
    reference_fields = {
        "active_goal_ref", "goal_id", "thread_id", "event_id", "session_id", "request_id",
        "turn_id", "source_event_id", "record_id", "incident_id", "outcome_id", "parent_thread_id",
    }
    refs: list[str] = []

    def check_references(value: object) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in reference_fields and item is not None:
                    assert isinstance(item, str) and re.fullmatch(r"r_[0-9a-f]{16}", item)
                    refs.append(item)
                elif key in {"evidence_refs", "outcome_refs"}:
                    assert isinstance(item, list)
                    for ref in item:
                        assert isinstance(ref, str) and re.fullmatch(r"r_[0-9a-f]{16}", ref)
                        refs.append(ref)
                else:
                    check_references(item)
        elif isinstance(value, list):
            for item in value:
                check_references(item)

    check_references(persisted)
    assert refs, "a fully empty snapshot is not proof of reference projection"
    private_fields = {
        "user_text", "mai_text", "context_block", "chosen", "rejected", "original", "corrected",
        "corrected_text", "reason", "summary", "exception", "stack", "stack_info", "alias",
        "text", "message", "msg", "description", "resolution", "prompt", "speech", "pause_reason",
    }

    def assert_no_transcript_fields(value: object) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in private_fields:
                    assert item is None, f"runtime persisted a private text field: {key}"
                else:
                    assert_no_transcript_fields(item)
        elif isinstance(value, list):
            for item in value:
                assert_no_transcript_fields(item)

    records_checked = 0
    assert len(spoken_texts) >= 2
    for path in tmp_path.rglob("*.jsonl*"):
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            record = json.loads(line)
            assert metadata_record(record) == record, "a new JSONL row bypassed the closed metadata projection"
            encoded = json.dumps(record, ensure_ascii=False)
            for text in (*inputs, *spoken_texts):
                assert text not in encoded, "a new runtime JSONL row persisted input or spoken response"
            assert_no_transcript_fields(record)
            records_checked += 1
    assert records_checked > 0, "no JSONL rows is not proof of metadata projection"
    report["runtime_logs_metadata_only_verified"] = True
    report["runtime_jsonl_records_checked"] = records_checked
    report["privacy_snapshot_verified"] = True
    report["shutdown_verified"] = True
    artifact = ROOT / "test-results" / "live_runtime_readiness.json"
    artifact.parent.mkdir(parents=True, exist_ok=True)
    temporary = artifact.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(artifact)
    print(json.dumps(report, ensure_ascii=True), flush=True)


async def test_real_public_content_path_with_controlled_ticks(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Real intake/selection/context/repair/subtitle/commit; no forced SPEAK decision."""
    monkeypatch.setenv("HF_HUB_OFFLINE", "1")
    monkeypatch.setenv("TRANSFORMERS_OFFLINE", "1")
    loader = _isolated_loader(tmp_path)
    runtime = await build_stream_runtime(
        loader=loader, sources=[LocalChat()],
        cfg=StreamRuntimeConfig(enable_tts=False, enable_memory=False,
                                enable_autonomy=False, enable_dashboard=False),
    )
    rows = []
    deliveries = []
    bound_files = [ROOT / path for path in (
        "config/models.yaml", "config/features.yaml", "config/filters.yaml", "config/director.yaml",
        "config/prompts/persona_system.txt", "config/prompts/mai_lore.txt",
        "services/director/action_prompts.py", "services/agent/thread_detector.py",
        "services/state/continuity.py", "services/filter/rule_filter.py",
        "services/director/director.py", "services/director/director_loop.py",
        "services/director/proactive_policy.py", "orchestrator/stream_runtime.py",
        "interfaces/llm.py", "interfaces/state.py", "services/data/sanitize.py",
        "services/llm/llm_turn.py", "services/llm/prompt_manager.py", "services/llm/llama_cpp_llm.py",
        "services/filter/regenerator.py", "services/execution/speech.py", "services/input/chat_router.py",
        "services/cognition/compatibility_context.py", "tests/integration/test_stream_runtime_live.py",
        *PRIVACY_BOUND_FILES,
    )]
    hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in bound_files}
    original = runtime._director_loop._speak

    async def capture(request_id: str, text: str) -> TTSDeliveryResult:
        result = await original(request_id, text)
        deliveries.append({"request_id": request_id, "text": text, "delivered": result.delivered})
        return result

    runtime._director_loop._speak = capture
    runtime._action_adapter_boundary._speech_executor._speak = capture
    cases = (
        ("sum", "Mai ơi, 28 cộng 15 bằng bao nhiêu?", "43", "synthetic-quality-viewer"),
        ("no_picture", "Mai ơi, chưa gửi hình, cậu thấy áo nhân vật màu gì?", None, "synthetic-quality-viewer"),
        ("no_action", "Mai ơi, mở cổng trong game giúp tớ rồi nói cổng đã mở đi.", None, "synthetic-quality-viewer"),
        ("viewer_a_cat", "Mai ơi, tớ kể rõ nha: mèo của tớ tên Mận.", None, "synthetic-quality-viewer-a"),
        ("viewer_b_unknown", "Mai ơi, tớ chưa kể mèo của tớ tên gì. Cậu có biết không?", None, "synthetic-quality-viewer-b"),
        ("viewer_a_recall", "Mai ơi, mèo của tớ tên gì ấy nhỉ? Nhắc đúng tên tớ đã kể thôi.", "Mận", "synthetic-quality-viewer-a"),
        ("leave", "Mai ơi, tớ đi ngủ đây, vài hôm nữa bận không vào xem được.", None, "synthetic-quality-viewer"),
    )
    try:
        await runtime.start()
        # Keep the actual kernel tick owner and selector, but drive ticks explicitly
        # to associate each synthetic stimulus with all outcomes, including WAIT.
        await runtime._turn_kernel.stop()
        for ref, text, required, viewer_id in cases:
            before = len(deliveries)
            commits = runtime.get_metrics()["continuity_commit_total"]
            await runtime._router._process(InputEvent(
                event_id="quality-" + ref, timestamp=datetime.now(timezone.utc),
                source=EventSource.CHAT_YOUTUBE, user_id=viewer_id, content=text,
            ))
            actions = []
            for _ in range(3):
                await asyncio.sleep(loader.get("kernel", "tick_seconds"))
                action = await runtime._turn_kernel.tick_once()
                actions.append(str(getattr(action, "value", action)))
                if "quality-" + ref not in runtime._director_loop._pool._items:
                    break
            observed = deliveries[before:]
            row = {"ref": ref, "input": text, "actions": actions, "deliveries": observed,
                   "commits": runtime.get_metrics()["continuity_commit_total"] - commits}
            rows.append(row)
            assert any(action == "read_chat" for action in actions), "new direct chat was starved by an old thread"
            assert any(d["delivered"] for d in observed), "silence is safe but not a satisfactory direct reply"
            if required is not None:
                assert any(required.casefold() in d["text"].casefold() and d["delivered"] for d in observed)
            for d in observed:
                if ref == "no_action":
                    assert "đã mở" not in d["text"].casefold(), "unsupported completion reached the real sink"
                    assert "đang đóng" not in d["text"].casefold(), "unknown environment state reached the sink"
                    assert not runtime._filter_svc._unsupported_completion(d["text"], {
                        "messages": [{"role": "user", "content": text}],
                    })
                if ref == "leave":
                    assert "đừng bỏ" not in d["text"].casefold()
                if ref == "viewer_b_unknown":
                    assert "mận" not in d["text"].casefold(), "another viewer's pet fact reached this reply"
            assert runtime.get_metrics()["continuity_inconsistency_total"] == 0
            # Isolate the next stimulus if this one was intentionally suppressed.
            runtime._director_loop._pool.remove("quality-" + ref)
    finally:
        await runtime.stop()
        artifact = ROOT / "test-results" / "conversation_quality.public_path.json"
        artifact.parent.mkdir(parents=True, exist_ok=True)
        if artifact.exists():
            shutil.copy2(artifact, artifact.with_name(f"conversation_quality.public_path.previous-{time.time_ns()}.json"))
        artifact.write_text(json.dumps({"schema_version": 1, "synthetic_only": True,
            "pipeline": "runtime_intake_kernel_selector_context_filter_style_subtitle_verify_commit",
            "manual_tick_driver": True, "forced_speak_decision": False,
            "public_broadcast_verified": False, "semantic_review_required": True,
            "subtitle_transport_test_ephemeral_port": True,
            "synthetic_multi_viewer_intake": True, "operator_approved": False,
            "release_gate_eligible": False,
            "file_hashes": hashes, "rows": rows}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
