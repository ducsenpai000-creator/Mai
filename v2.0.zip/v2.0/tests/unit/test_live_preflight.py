from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest
import yaml

from orchestrator.config_loader import ConfigLoader
from scripts.live_preflight import _write_json_atomic, run_preflight


def test_audio_preflight_rejects_unavailable_device_before_launch(tmp_path, monkeypatch) -> None:
    import sounddevice as sd

    def unavailable(**_kwargs):
        raise sd.PortAudioError("device missing")

    monkeypatch.setattr(sd, "check_output_settings", unavailable)
    report = run_preflight(
        _loader(tmp_path), platform_name="youtube", video_id="video123",
        tts_enabled=True, check_server_health=False, repo_root=tmp_path,
        os_name="Windows", python_version=(3, 11, 9), now_utc=NOW,
    )
    assert report["ready"] is False
    check = next(item for item in report["checks"] if item["name"] == "audio_output")
    assert check["passed"] is False
    assert "PortAudioError" in check["detail"]


def test_subtitle_only_preflight_does_not_require_audio_hardware(tmp_path, monkeypatch) -> None:
    import sounddevice as sd

    def forbidden(**_kwargs):
        raise AssertionError("subtitle-only preflight must not inspect audio")

    monkeypatch.setattr(sd, "check_output_settings", forbidden)
    report = run_preflight(
        _loader(tmp_path), platform_name="youtube", video_id="video123",
        tts_enabled=False, check_server_health=False, repo_root=tmp_path,
        os_name="Windows", python_version=(3, 11, 9), now_utc=NOW,
    )
    assert report["ready"] is True
    assert "audio_output" not in {item["name"] for item in report["checks"]}


NOW = datetime(2026, 8, 14, 8, 0, tzinfo=timezone.utc)


def _loader(tmp_path: Path) -> ConfigLoader:
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    files = {
        "models.yaml": {
            "llm_main": {
                "binary": str(tmp_path / "llama-server.exe"),
                "model_path": str(tmp_path / "model.gguf"),
                "host": "127.0.0.1", "port": 8080,
            },
            "tts": {"reference_audio": str(tmp_path / "voice.wav")},
            "tts_fallback": {
                "enabled": True, "require_delivery": True,
                "output_file": None, "overlay_host": "127.0.0.1", "overlay_port": 7862,
                "overlay_ttl_s": 15.0, "overlay_max_chars": 4000, "overlay_poll_s": 0.1,
            },
        },
        "features.yaml": {"features": {
            "mood_v2_prompt": {"enabled": True},
            "action_transactions": {"enabled": True},
            "decision_records": {"enabled": True},
        }},
        "chat_sources.yaml": {"discord": {
            "token_env_var": "DISCORD_BOT_TOKEN", "channel_ids": [123],
        }},
        "system.yaml": {"app": {"version": "1.4.3"}},
    }
    for name, content in files.items():
        (config_dir / name).write_text(yaml.safe_dump(content), encoding="utf-8")
    for name in ("llama-server.exe", "model.gguf", "voice.wav"):
        (tmp_path / name).write_bytes(b"ok")
    (tmp_path / "logs").mkdir()
    loader = ConfigLoader(config_dir, required=())
    loader.load_all()
    return loader


@pytest.mark.parametrize("key,value", [
    ("output_file", "forbidden_subtitle.txt"), ("overlay_host", "0.0.0.0"),
    ("overlay_port", 0), ("overlay_port", 65536),
    ("overlay_ttl_s", 0), ("overlay_max_chars", 0),
    ("overlay_max_clients", 0),
])
def test_subtitle_preflight_rejects_disk_or_unbounded_unsafe_overlay(
    tmp_path: Path, key: str, value,
) -> None:
    loader = _loader(tmp_path)
    loader._data["models"]["tts_fallback"][key] = value
    report = run_preflight(
        loader, platform_name="youtube", video_id="video123", tts_enabled=False,
        check_server_health=False, repo_root=tmp_path,
        os_name="Windows", python_version=(3, 11, 9), now_utc=NOW,
    )
    assert report["ready"] is False
    assert next(item for item in report["checks"] if item["name"] == "subtitle_overlay")["passed"] is False
    assert not (tmp_path / "forbidden_subtitle.txt").exists()


def test_youtube_preflight_ready_without_running_server(tmp_path: Path) -> None:
    report = run_preflight(
        _loader(tmp_path), platform_name="youtube", video_id="video123",
        check_server_health=False, repo_root=tmp_path,
        os_name="Windows", python_version=(3, 11, 9), now_utc=NOW,
    )
    assert report["ready"] is True
    assert report["marker"] == "mai_live_preflight"
    assert report["sanitized"] is True
    assert report["product_version"] == "1.4.3"
    assert report["generated_at_utc"] == "2026-08-14T08:00:00+00:00"
    assert all("token" not in item["detail"].lower() or "variable" in item["detail"].lower()
               for item in report["checks"])


def test_discord_preflight_requires_token_but_never_exposes_it(tmp_path: Path) -> None:
    loader = _loader(tmp_path)
    missing = run_preflight(
        loader, platform_name="discord", check_server_health=False,
        repo_root=tmp_path, environ={}, os_name="Windows", python_version=(3, 11, 0),
        now_utc=NOW,
    )
    assert missing["ready"] is False
    secret = "super-secret-token"
    ready = run_preflight(
        loader, platform_name="discord", check_server_health=False,
        repo_root=tmp_path, environ={"DISCORD_BOT_TOKEN": secret},
        os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    assert ready["ready"] is True
    assert secret not in str(ready)


def test_dashboard_preflight_requires_long_control_token_without_exposing_it(
    tmp_path: Path,
) -> None:
    loader = _loader(tmp_path)
    missing = run_preflight(
        loader, platform_name="youtube", video_id="x", dashboard_enabled=True,
        check_server_health=False, repo_root=tmp_path, environ={},
        os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    assert missing["ready"] is False
    secret = "dashboard-control-token-123456"
    ready = run_preflight(
        loader, platform_name="youtube", video_id="x", dashboard_enabled=True,
        check_server_health=False, repo_root=tmp_path,
        environ={"MAI_DASHBOARD_CONTROL_TOKEN": secret},
        os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    assert ready["ready"] is True
    assert secret not in str(ready)


def test_discord_preflight_rejects_malformed_secret_without_trimming(
    tmp_path: Path,
) -> None:
    secret = " raw-secret "
    report = run_preflight(
        _loader(tmp_path), platform_name="discord", check_server_health=False,
        repo_root=tmp_path, environ={"DISCORD_BOT_TOKEN": secret},
        os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    check = next(item for item in report["checks"] if item["name"] == "discord_token")
    assert report["ready"] is False
    assert check["passed"] is False
    assert "invalid" in check["detail"]
    assert secret not in str(report)


def test_obs_credential_is_required_only_when_feature_is_enabled(tmp_path: Path) -> None:
    loader = _loader(tmp_path)
    loader._data["features"]["features"]["obs_scene_executor"] = {"enabled": True}

    missing = run_preflight(
        loader, platform_name="youtube", video_id="x", check_server_health=False,
        repo_root=tmp_path, environ={}, os_name="Windows",
        python_version=(3, 11, 0), now_utc=NOW,
    )
    assert missing["ready"] is False
    assert next(
        item for item in missing["checks"] if item["name"] == "obs_password"
    )["passed"] is False

    secret = "obs-secret"
    ready = run_preflight(
        loader, platform_name="youtube", video_id="x", check_server_health=False,
        repo_root=tmp_path, environ={"OBS_WEBSOCKET_PASSWORD": secret},
        os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    assert ready["ready"] is True
    assert secret not in str(ready)


def test_invalid_credential_reference_fails_preflight_without_reading_secret(
    tmp_path: Path,
) -> None:
    loader = _loader(tmp_path)
    loader._data["chat_sources"]["discord"]["token_env_var"] = "bad-name"
    report = run_preflight(
        loader, platform_name="youtube", video_id="x", check_server_health=False,
        repo_root=tmp_path, environ={"bad-name": "raw-secret"}, os_name="Windows",
        python_version=(3, 11, 0), now_utc=NOW,
    )
    check = next(
        item for item in report["checks"] if item["name"] == "credential_contract"
    )
    assert report["ready"] is False
    assert check["passed"] is False
    assert "raw-secret" not in str(report)


def test_preflight_fails_when_transaction_contract_is_disabled(tmp_path: Path) -> None:
    loader = _loader(tmp_path)
    loader._data["features"]["features"]["action_transactions"]["enabled"] = False
    report = run_preflight(
        loader, platform_name="youtube", video_id="x", check_server_health=False,
        repo_root=tmp_path, os_name="Windows", python_version=(3, 11, 0), now_utc=NOW,
    )
    assert report["ready"] is False
    assert next(item for item in report["checks"] if item["name"] == "transactions")["passed"] is False


def test_preflight_atomic_write_preserves_existing_destination_on_replace_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    destination = tmp_path / "preflight.json"
    destination.write_text("old-valid-report", encoding="utf-8")

    def fail_replace(self: Path, target: Path) -> Path:
        raise OSError("replace failed")

    monkeypatch.setattr(Path, "replace", fail_replace)
    with pytest.raises(OSError, match="replace failed"):
        _write_json_atomic(destination, '{"ready": true}\n')

    assert destination.read_text(encoding="utf-8") == "old-valid-report"
    assert not destination.with_suffix(".json.tmp").exists()
