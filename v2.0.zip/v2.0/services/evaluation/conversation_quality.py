"""Offline content checks and explicitly non-independent agent self-review.

Expectations are never model instructions. Generation evidence is preserved even
when checks fail; neither report can serve as blind/operator release approval.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from services.data.sanitize import mask_pii
from services.director.speech_style import SpeechStyleGuard

CONTENT_DIMENSIONS = ("language", "presence", "context", "character", "spontaneity")


@dataclass(frozen=True)
class ContentPolicy:
    limits: Mapping[str, Any]
    weights: Mapping[str, float]
    forbidden_patterns: Mapping[str, tuple[str, ...]]
    style: Mapping[str, Any]

    @classmethod
    def from_loader(cls, loader: Any) -> ContentPolicy:
        limits = loader.get("evaluation", "evaluation.conversation_quality", {})
        keys = {
            "schema_version", "corpus_file", "output_file", "seed", "min_sessions", "max_sessions",
            "min_turns", "max_turns", "max_turns_per_session", "max_input_chars", "max_output_chars",
            "max_note_chars", "minimum_self_score", "max_automatic_violations", "max_critical_failures",
        }
        if not isinstance(limits, dict) or set(limits) != keys or limits["schema_version"] != 1:
            raise ValueError("invalid conversation quality policy")
        for key in keys - {"corpus_file", "output_file", "minimum_self_score"}:
            if type(limits[key]) is not int or limits[key] < (0 if key.startswith("max_") and
                key in {"max_automatic_violations", "max_critical_failures"} else 1):
                raise ValueError(f"invalid conversation quality bound: {key}")
        for key in ("corpus_file", "output_file"):
            if not isinstance(limits[key], str) or not limits[key].strip():
                raise ValueError(f"invalid conversation quality path: {key}")
        threshold = limits["minimum_self_score"]
        if type(threshold) not in (int, float) or not math.isfinite(threshold) or not 0 <= threshold <= 10:
            raise ValueError("invalid self-score threshold")
        if limits["min_sessions"] > limits["max_sessions"] or limits["min_turns"] > limits["max_turns"]:
            raise ValueError("invalid conversation quality minimum/maximum")
        dimensions = loader.get("evaluation", "evaluation.human_like.dimensions", {})
        if not isinstance(dimensions, dict) or set(dimensions) != {*CONTENT_DIMENSIONS, "timing"}:
            raise ValueError("invalid canonical content dimensions")
        weights = {key: value for key, value in dimensions.items() if key != "timing"}
        if set(weights) != set(CONTENT_DIMENSIONS) or any(
            type(value) not in (int, float) or not math.isfinite(value) or value <= 0
            for value in weights.values()
        ):
            raise ValueError("invalid content rubric weights")
        total = sum(weights.values())
        patterns = loader.get("evaluation", "evaluation.youtube_llm_stress.forbidden_patterns", {})
        if not isinstance(patterns, dict) or not patterns or any(
            not isinstance(key, str) or not isinstance(values, list) or not values
            or any(not isinstance(value, str) or not value.strip() for value in values)
            for key, values in patterns.items()
        ):
            raise ValueError("invalid content guard patterns")
        style = loader.get("director", "director.speech_style", {})
        # Reuse the canonical guard/config; do not add a content-specific blacklist.
        _style_guard(style)
        return cls(dict(limits), {key: value / total for key, value in weights.items()},
                   {key: tuple(values) for key, values in patterns.items()}, dict(style))


def _style_guard(style: Mapping[str, Any]) -> SpeechStyleGuard:
    return SpeechStyleGuard(
        recent_window=style["recent_window"], formula_openers=tuple(style["formula_openers"]),
        max_formula_openers=style["max_formula_openers"], max_same_opener=style["max_same_opener"],
        language_integrity_fragments=tuple(style["language_integrity_fragments"]),
        malformed_token_fragments=tuple(style["malformed_token_fragments"]),
        malformed_token_allowlist=tuple(style["malformed_token_allowlist"]),
        malformed_mixed_case_min_prefix_chars=style["malformed_mixed_case_min_prefix_chars"],
        max_questions=style["max_questions"], question_endings=tuple(style["question_endings"]),
        max_sentences=style["max_sentences"], max_words=style["max_words"],
    )


def _text(value: Any, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError("content field is empty, invalid or exceeds bound")
    return value


def load_corpus(path: Path, policy: ContentPolicy) -> list[dict[str, Any]]:
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or set(raw) != {"schema_version", "synthetic_only", "sessions"}:
        raise ValueError("invalid conversation corpus root")
    sessions = raw["sessions"]
    if type(raw["schema_version"]) is not int or raw["schema_version"] != 1 or raw["synthetic_only"] is not True:
        raise ValueError("only versioned synthetic content corpora are accepted")
    if not isinstance(sessions, list) or not policy.limits["min_sessions"] <= len(sessions) <= policy.limits["max_sessions"]:
        raise ValueError("session count outside bound")
    refs: set[str] = set()
    turns_total = 0
    for session in sessions:
        if not isinstance(session, dict) or set(session) != {"id", "topic", "turns"}:
            raise ValueError("invalid session")
        session_id = _text(session["id"], policy.limits["max_input_chars"])
        _text(session["topic"], policy.limits["max_input_chars"])
        turns = session["turns"]
        if not isinstance(turns, list) or not 1 <= len(turns) <= policy.limits["max_turns_per_session"]:
            raise ValueError("session turn count outside bound")
        if session_id in refs:
            raise ValueError("duplicate session reference")
        refs.add(session_id)
        for turn in turns:
            if not isinstance(turn, dict) or set(turn) != {"id", "input", "category", "expectations", "critical"}:
                raise ValueError("invalid turn")
            ref = session_id + "/" + _text(turn["id"], policy.limits["max_input_chars"])
            if ref in refs:
                raise ValueError("duplicate turn reference")
            refs.add(ref)
            _text(turn["input"], policy.limits["max_input_chars"])
            _text(turn["category"], policy.limits["max_input_chars"])
            expected = turn["expectations"]
            if not isinstance(expected, dict) or not expected:
                raise ValueError("expectations required before generation")
            for key, value in expected.items():
                _text(key, policy.limits["max_input_chars"])
                _text(value, policy.limits["max_note_chars"])
            critical = turn["critical"]
            if not isinstance(critical, list) or any(not isinstance(key, str) for key in critical) or len(set(critical)) != len(critical) or not set(critical) <= set(expected):
                raise ValueError("critical expectations must refer to declared expectations")
            turns_total += 1
    if not policy.limits["min_turns"] <= turns_total <= policy.limits["max_turns"]:
        raise ValueError("corpus turn count outside bound")
    return sessions


def turn_map(sessions: Sequence[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    return {session["id"] + "/" + turn["id"]: turn for session in sessions for turn in session["turns"]}


def automatic_checks(rows: Sequence[Mapping[str, Any]], policy: ContentPolicy) -> dict[str, Any]:
    """Finite lexical/technical guards, deliberately not a semantic score."""
    violations: list[dict[str, str]] = []
    texts: Counter[str] = Counter()
    style = _style_guard(policy.style)
    for row in rows:
        ref, text = str(row["ref"]), row["output"]
        if not isinstance(text, str):
            raise ValueError("output must be text")
        lower = text.casefold()
        if not text.strip():
            violations.append({"ref": ref, "kind": "empty"})
        if row.get("parsed_ok") is not True:
            violations.append({"ref": ref, "kind": "parse_invalid"})
        if len(text) > policy.limits["max_output_chars"]:
            violations.append({"ref": ref, "kind": "output_bound"})
        if row.get("fallback_level") != 0:
            violations.append({"ref": ref, "kind": "fallback"})
        verdict = row.get("filter")
        if not isinstance(verdict, dict) or verdict.get("passed") is not True or str(verdict.get("reason", "")).startswith("fail-open"):
            violations.append({"ref": ref, "kind": "filter_unverified"})
        for kind, patterns in policy.forbidden_patterns.items():
            if any(pattern.casefold() in lower for pattern in patterns):
                violations.append({"ref": ref, "kind": kind})
        for kind, match in (
            ("language_integrity", style.language_fragment_for(text)),
            ("malformed_token", style.malformed_token_for(text, grounding_text=str(row.get("input", "")))),
        ):
            if match is not None:
                violations.append({"ref": ref, "kind": kind})
        normalized = re.sub(r"\W+", " ", lower).strip()
        if normalized:
            texts[normalized] += 1
            if texts[normalized] > 1:
                violations.append({"ref": ref, "kind": "exact_repetition"})
    return {
        "status": "passed" if len(violations) <= policy.limits["max_automatic_violations"] else "failed",
        "semantic_quality_assessed": False, "violation_count": len(violations), "violations": violations,
    }


def finalize_self_review(
    generation_path: Path, review: Mapping[str, Any], sessions: Sequence[Mapping[str, Any]],
    policy: ContentPolicy,
) -> dict[str, Any]:
    """Bind every subjective score/check to actual preserved generation evidence."""
    digest = hashlib.sha256(generation_path.read_bytes()).hexdigest()
    if set(review) != {"reviewer", "generation_sha256", "rows"} or review["reviewer"] != "coding_agent_self_review" or review["generation_sha256"] != digest:
        raise ValueError("self-review identity or generation digest mismatch")
    generation = json.loads(generation_path.read_text(encoding="utf-8"))
    expected = turn_map(sessions)
    source_rows = generation.get("rows", [])
    source = {row["ref"]: row for row in source_rows}
    source_list = generation.get("corpus", {})
    if (generation.get("marker") != "mai_content_generation" or generation.get("status") != "complete"
        or len(source_rows) != len(source)
        or set(source) != set(expected) or source_list.get("sha256") != hashlib.sha256(
            yaml.safe_dump(list(sessions), allow_unicode=True, sort_keys=True).encode("utf-8")
        ).hexdigest()):
        raise ValueError("generation corpus coverage/identity mismatch")
    rows = review["rows"]
    if not isinstance(rows, list) or len(rows) != len(expected):
        raise ValueError("incomplete self-review")
    seen: set[str] = set()
    averages = {key: 0.0 for key in CONTENT_DIMENSIONS}
    failures: list[str] = []
    critical: list[str] = []
    checked_rows: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict) or set(row) != {"ref", "scores", "checks", "evidence", "note"}:
            raise ValueError("invalid self-review row")
        ref = row["ref"]
        if ref not in expected or ref in seen:
            raise ValueError("unknown/duplicate self-review reference")
        seen.add(ref)
        scores, checks = row["scores"], row["checks"]
        if not isinstance(scores, dict) or set(scores) != set(CONTENT_DIMENSIONS) or any(
            type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 5
            for value in scores.values()
        ):
            raise ValueError("invalid content scores; timing cannot be inferred from text")
        if not isinstance(checks, dict) or set(checks) != set(expected[ref]["expectations"]) or any(type(value) is not bool for value in checks.values()):
            raise ValueError("review must check every declared expectation")
        evidence = row["evidence"]
        if not isinstance(evidence, str) or len(evidence) > policy.limits["max_output_chars"] or (not evidence and source[ref]["output"]):
            raise ValueError("review evidence is invalid")
        if evidence not in source[ref]["output"]:
            raise ValueError("review evidence must quote the actual output")
        note = _text(row["note"], policy.limits["max_note_chars"])
        for key in CONTENT_DIMENSIONS:
            averages[key] += scores[key] / len(rows)
        for key, passed in checks.items():
            if not passed:
                failures.append(ref + ":" + key)
                if key in expected[ref]["critical"]:
                    critical.append(ref + ":" + key)
        checked_rows.append({**row, "evidence": mask_pii(evidence), "note": mask_pii(note)})
    score = sum(averages[key] * policy.weights[key] for key in CONTENT_DIMENSIONS) * 2
    guards = automatic_checks(source_rows, policy)
    passed = score >= policy.limits["minimum_self_score"] and len(critical) <= policy.limits["max_critical_failures"] and guards["status"] == "passed"
    return {
        "schema_version": 1, "marker": "mai_content_agent_self_review",
        "reviewer": "coding_agent_self_review", "independent": False, "blind": False,
        "operator_approved": False, "release_gate_eligible": False,
        "generation_sha256": digest, "reviewed_turns": len(rows), "unassessed": ["timing", "audio", "live_director_and_memory"],
        "rubric": {"scale": "0 absent/harmful; 1 poor; 2 weak; 3 acceptable; 4 good; 5 excellent", "weights": dict(policy.weights)},
        "dimension_averages": {key: round(value, 3) for key, value in averages.items()},
        "score_out_of_10": round(score, 3), "expectation_failures": failures,
        "critical_failures": critical, "automatic": guards,
        "status": "passed_self_review" if passed else "failed_self_review", "rows": checked_rows,
    }


def main() -> int:
    """Reproducibly bind a manually authored review to preserved generation."""
    import argparse

    from orchestrator.config_loader import ConfigLoader

    parser = argparse.ArgumentParser(description="Validate non-independent content self-review")
    parser.add_argument("--generation", type=Path, required=True)
    parser.add_argument("--review", type=Path, required=True)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    loader = ConfigLoader(root / "config")
    loader.load_all()
    policy = ContentPolicy.from_loader(loader)
    sessions = load_corpus(args.corpus, policy)
    review = json.loads(args.review.read_text(encoding="utf-8"))
    report = finalize_self_review(args.generation, review, sessions, policy)
    if args.output.resolve() in {args.generation.resolve(), args.review.resolve(), args.corpus.resolve()}:
        raise ValueError("output must not overwrite evidence")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(json.dumps({key: report[key] for key in (
        "status", "score_out_of_10", "critical_failures", "independent", "release_gate_eligible",
    )}, ensure_ascii=True))
    return 0 if report["status"] == "passed_self_review" else 1


if __name__ == "__main__":
    raise SystemExit(main())
