"""Integration TTSPipeline (Phase 4, 4.E) — không cần GPU/loa thật.

Verify DoD P4:
- Không audio overlap giữa turns (AudioPlayer sequential)
- TTFA measured end-to-end
- Primary fail → subtitle fallback triggered
- Cancel dừng sạch
"""
from __future__ import annotations

import asyncio
import threading
import time
from pathlib import Path
from typing import Any, AsyncIterator

import numpy as np
import pytest
import httpx

from interfaces.base import HealthStatus
from interfaces.tts import AudioChunk, TTSDeliveryMode, TTSRequest
from orchestrator.fallback_manager import FallbackManager
from services.operations.metrics import MetricsCollector
from services.tts.audio_player import AudioPlayer
from services.tts.subtitle_fallback import SubtitleFallbackService
from services.tts.tts_pipeline import TTSPipeline


class FakeTTS:
    """TTS giả yield chunks tuần tự với delay."""

    service_id = "tts_fake"

    def __init__(self, chunks_per_sentence: int = 3, chunk_samples: int = 2400,
                 chunk_delay_s: float = 0.02, raise_at: int | None = None,
                 raise_on_call: int | None = None):
        self.chunks_per_sentence = chunks_per_sentence
        self.chunk_samples = chunk_samples
        self.chunk_delay_s = chunk_delay_s
        self.raise_at = raise_at
        self.raise_on_call = raise_on_call
        self.calls = 0
        self.cancelled: set[str] = set()

    async def synthesize_stream(self, request: TTSRequest) -> AsyncIterator[AudioChunk]:
        self.calls += 1
        if self.raise_on_call is not None and self.calls == self.raise_on_call:
            raise RuntimeError("boom")
        for i in range(self.chunks_per_sentence):
            if self.raise_at is not None and i == self.raise_at:
                raise RuntimeError("mid-boom")
            if request.request_id in self.cancelled:
                break
            if self.chunk_delay_s:
                await asyncio.sleep(self.chunk_delay_s)
            samples = np.ones(self.chunk_samples, dtype=np.float32) * 0.1
            yield AudioChunk(
                request_id=request.request_id, chunk_index=i,
                audio_bytes=samples.tobytes(), is_final=False,
                duration_ms=int(1000 * self.chunk_samples / 24000),
            )
        yield AudioChunk(
            request_id=request.request_id, chunk_index=self.chunks_per_sentence,
            audio_bytes=b"", is_final=True, duration_ms=0,
        )

    async def cancel(self, request_id: str) -> None:
        self.cancelled.add(request_id)


class FakePlayerBackend:
    def __init__(self, per_chunk_delay_s: float = 0.02):
        self.play_events: list[tuple[float, str]] = []  # (t, tag=start|end)
        self._delay = per_chunk_delay_s
        self._lock = threading.Lock()

    def play_blocking(self, samples, sample_rate):
        with self._lock:
            self.play_events.append((time.perf_counter(), "start"))
        time.sleep(self._delay)
        with self._lock:
            self.play_events.append((time.perf_counter(), "end"))

    def stop(self):
        pass


def make_pipeline(primary=None, chunk_delay=0.02, timeout_primary=3.0):
    metrics = MetricsCollector()
    fb = FallbackManager()
    subtitle = SubtitleFallbackService(on_subtitle=lambda _rid, _text: None)
    backend = FakePlayerBackend(per_chunk_delay_s=chunk_delay)
    player = AudioPlayer(sample_rate=24000, backend=backend)
    p = primary or FakeTTS(chunks_per_sentence=2, chunk_delay_s=chunk_delay)
    pipe = TTSPipeline(
        primary=p, subtitle=subtitle, player=player, fallback=fb,
        timeout_primary_s=timeout_primary, timeout_subtitle_s=0.5, metrics=metrics,
    )
    return pipe, p, player, backend, metrics


async def _wait(cond, timeout=2.0, poll=0.02):
    deadline = asyncio.get_event_loop().time() + timeout
    while not cond() and asyncio.get_event_loop().time() < deadline:
        await asyncio.sleep(poll)


async def test_phrase_synthesis_merges_then_flag_off_restores_sentences() -> None:
    pipe, primary, player, _, _ = make_pipeline(chunk_delay=0)
    await player.start()
    try:
        pipe.set_enabled(True)
        result = await pipe.speak("phrase", "Chào cậu. Bánh ngon nhé!")
        assert primary.calls == 1
        assert result.delivered and result.audio_sentences == 2
        assert pipe.get_metrics()["tts_pipeline_merged_sentences_total"] == 1
        pipe.set_enabled(False)
        result = await pipe.speak("rollback", "Chào cậu. Bánh ngon nhé!")
        assert primary.calls == 3
        assert result.delivered and result.sentences_delivered == 2
    finally:
        await player.stop()


async def test_valid_async_iterator_does_not_need_aclose() -> None:
    class Iterator:
        def __init__(self, stream):
            self.stream = stream

        def __aiter__(self):
            return self

        async def __anext__(self):
            return await anext(self.stream)

    class Service(FakeTTS):
        def synthesize_stream(self, request):
            return Iterator(super().synthesize_stream(request))

    pipe, _, player, _, _ = make_pipeline(primary=Service(chunk_delay_s=0), chunk_delay=0)
    await player.start()
    try:
        result = await pipe.speak("iterator", "Chào cậu.")
        assert result.delivered and result.mode is TTSDeliveryMode.AUDIO
    finally:
        await player.stop()


async def test_phrase_bound_and_fallback_count_original_sentences() -> None:
    pipe, primary, player, _, _ = make_pipeline(primary=FakeTTS(raise_on_call=1), chunk_delay=0)
    pipe._phrase_max_chars = 25
    pipe.set_enabled(True)
    assert pipe._phrases(["Chào cậu.", "Bánh ngon!", "Câu dài vượt quá giới hạn hai mươi lăm ký tự."]) == [
        ("Chào cậu. Bánh ngon!", 2), ("Câu dài vượt quá giới hạn hai mươi lăm ký tự.", 1),
    ]
    await player.start()
    try:
        result = await pipe.speak("fallback", "Chào cậu. Bánh ngon!")
        assert primary.calls == 1
        assert result.delivered and result.subtitle_sentences == 2
    finally:
        await player.stop()


class TestBasicPipeline:
    async def test_pipeline_health_requires_running_audio_worker_or_real_subtitle_sink(
        self, tmp_path: Path,
    ) -> None:
        class HealthyPrimary(FakeTTS):
            async def health_check(self) -> HealthStatus:
                return HealthStatus.healthy("tts_primary")

        player = AudioPlayer(sample_rate=24000, backend=FakePlayerBackend())
        pipeline = TTSPipeline(
            primary=HealthyPrimary(), subtitle=None, player=player, fallback=FallbackManager(),
        )
        assert not (await pipeline.health_check()).is_ok
        await player.start()
        try:
            status = await pipeline.health_check()
            assert status.is_ok and status.details["delivery_mode"] == "audio"
        finally:
            await player.stop()
        assert not (await pipeline.health_check()).is_ok

        pipeline._subtitle = SubtitleFallbackService(
            on_subtitle=lambda _rid, _text: None, require_delivery=True,
        )
        status = await pipeline.health_check()
        assert status.is_ok and status.details["delivery_mode"] == "subtitle"
        assert status.details["audio_available"] is False

    @pytest.mark.parametrize("primary_failure", ["unhealthy", "exception"])
    async def test_primary_outage_keeps_healthy_subtitle_delivery_route(
        self, tmp_path: Path, primary_failure: str,
    ) -> None:
        class BrokenPrimary(FakeTTS):
            async def health_check(self) -> HealthStatus:
                if primary_failure == "exception":
                    raise RuntimeError("primary probe failed")
                return HealthStatus.unhealthy("tts_primary", "model unavailable")

        player = AudioPlayer(sample_rate=24000, backend=FakePlayerBackend())
        pipeline = TTSPipeline(
            primary=BrokenPrimary(),
            subtitle=SubtitleFallbackService(on_subtitle=lambda _rid, _text: None, require_delivery=True),
            player=player, fallback=FallbackManager(),
        )
        await player.start()
        try:
            status = await pipeline.health_check()
            assert status.is_ok and status.details["delivery_mode"] == "subtitle"
            pipeline._subtitle = SubtitleFallbackService(require_delivery=True)
            assert not (await pipeline.health_check()).is_ok
        finally:
            await player.stop()

    async def test_speak_splits_and_synths(self) -> None:
        pipe, primary, player, backend, metrics = make_pipeline()
        await player.start()
        try:
            result = await pipe.speak("r1", "Chào cậu. Khoẻ không?")
            assert primary.calls == 2   # 2 câu → 2 lần synthesize_stream
            await _wait(lambda: len(backend.play_events) >= 4)
        finally:
            await player.stop()
        assert pipe.get_metrics()["tts_pipeline_sentences_total"] == 2
        assert result.delivered is True
        assert result.mode is TTSDeliveryMode.AUDIO
        assert metrics.tts_snapshot()["turns_total"] == 1

    async def test_ttfa_measured(self) -> None:
        pipe, *_rest, metrics = make_pipeline(chunk_delay=0.03)
        await _rest[1].start() if False else None  # player already started below
        pipe_player = _rest[1]
        await pipe_player.start()
        try:
            await pipe.speak("r1", "chào")
        finally:
            await pipe_player.stop()
        ttfa = pipe.get_metrics()["tts_pipeline_last_ttfa_ms"]
        assert ttfa is not None and ttfa > 0


class TestNoOverlap:
    async def test_two_sentences_do_not_overlap(self) -> None:
        # chunk_delay lớn để dễ đo — nếu overlap, sẽ có 2 "start" liên tiếp không có "end" giữa
        pipe, _primary, player, backend, _metrics = make_pipeline(chunk_delay=0.05)
        await player.start()
        try:
            await pipe.speak("r1", "Câu một. Câu hai.")
            await _wait(lambda: len(backend.play_events) >= 8)  # 2 câu × 2 chunk × (start+end)
        finally:
            await player.stop()

        # Kiểm bất cứ chunk nào cũng có (start, end) xen kẽ, không có 2 start liên tiếp
        tags = [tag for _, tag in backend.play_events]
        # Bỏ đuôi nếu chưa flush hết
        n = (len(tags) // 2) * 2
        tags = tags[:n]
        for i in range(0, n, 2):
            assert tags[i] == "start" and tags[i + 1] == "end", f"overlap tại i={i}: {tags}"


class TestFallbackToSubtitle:
    @pytest.mark.parametrize("phrase_enabled", [False, True])
    async def test_real_overlay_retains_all_sentences_and_resets_for_next_turn(
        self, tmp_path: Path, phrase_enabled: bool,
    ) -> None:
        subtitle = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, require_delivery=True)
        await subtitle.start()
        pipeline = TTSPipeline(
            primary=None, subtitle=subtitle, player=None, fallback=FallbackManager(),
        )
        pipeline.set_enabled(phrase_enabled)
        text = "Chào cậu. Bắp là vịt bông. Áo nhân vật màu đỏ. Chúc ngủ ngon!"
        try:
            async with httpx.AsyncClient(base_url=subtitle.overlay_url, trust_env=False) as client:
                result = await pipeline.speak("multi-sentence", text)
                assert result.delivered is True
                assert result.mode is TTSDeliveryMode.SUBTITLE
                assert result.sentences_delivered == 4
                assert result.subtitle_sentences == 4
                assert (await client.get("/subtitle")).json()["text"] == text

                next_result = await pipeline.speak("fresh-turn", "Một lượt mới.")
                assert next_result.delivered is True
                assert (await client.get("/subtitle")).json()["text"] == "Một lượt mới."
                assert pipeline.get_metrics()["tts_pipeline_pending_invocations"] == 0
                await pipeline.cancel_all()
                assert (await client.get("/subtitle")).json()["text"] == ""
                assert list(tmp_path.iterdir()) == []
        finally:
            await subtitle.stop()

    async def test_cancel_all_clears_completed_overlay_even_if_player_cancel_fails(self) -> None:
        class BrokenPlayer:
            async def cancel_all(self) -> None:
                raise RuntimeError("player unavailable")

        subtitle = SubtitleFallbackService(overlay_host="127.0.0.1", overlay_port=0, require_delivery=True)
        await subtitle.start()
        pipeline = TTSPipeline(primary=None, subtitle=subtitle, player=BrokenPlayer(), fallback=FallbackManager())
        try:
            result = await pipeline.speak("already-completed", "Clear this after emergency.")
            assert result.delivered
            assert pipeline.get_metrics()["tts_pipeline_pending_invocations"] == 0
            try:
                await pipeline.cancel_all()
            except RuntimeError as exc:
                assert str(exc) == "player unavailable"
            async with httpx.AsyncClient(base_url=subtitle.overlay_url, trust_env=False) as client:
                assert (await client.get("/subtitle")).json()["text"] == ""
        finally:
            await subtitle.stop()

    async def test_audio_device_failure_cannot_be_committed_as_audio_delivery(self) -> None:
        class BrokenBackend(FakePlayerBackend):
            def play_blocking(self, samples, sample_rate):
                raise OSError("audio device disconnected")

        seen = []
        player = AudioPlayer(sample_rate=24000, backend=BrokenBackend())
        pipe = TTSPipeline(
            primary=FakeTTS(chunks_per_sentence=1),
            subtitle=SubtitleFallbackService(
                on_subtitle=lambda _rid, text: seen.append(text), require_delivery=True,
            ),
            player=player, fallback=FallbackManager(),
        )
        await player.start()
        try:
            result = await pipe.speak("device-failure", "Câu phải tới subtitle.")
            assert result.mode is TTSDeliveryMode.SUBTITLE
            assert result.delivered is True
            assert seen == ["Câu phải tới subtitle."]
            assert player.get_metrics()["audio_chunks_failed"] == 1
        finally:
            await player.stop()

    async def test_no_delivery_when_playback_and_subtitle_both_fail(self) -> None:
        class BrokenBackend(FakePlayerBackend):
            def play_blocking(self, samples, sample_rate):
                raise OSError("audio device disconnected")

        player = AudioPlayer(sample_rate=24000, backend=BrokenBackend())
        pipe = TTSPipeline(
            primary=FakeTTS(chunks_per_sentence=1),
            subtitle=SubtitleFallbackService(require_delivery=True),
            player=player, fallback=FallbackManager(),
        )
        await player.start()
        try:
            result = await pipe.speak("all-delivery-failed", "Câu chưa được giao.")
            assert result.delivered is False
            assert result.failed_sentences == 1
        finally:
            await player.stop()

    async def test_primary_error_falls_to_subtitle(self) -> None:
        # primary raise ngay call đầu → chain rơi xuống subtitle (Level 1)
        primary = FakeTTS(chunks_per_sentence=2, raise_on_call=1)
        pipe, _p, player, _backend, metrics = make_pipeline(primary=primary)
        await player.start()
        try:
            result = await pipe.speak("r1", "chào cậu")
        finally:
            await player.stop()
        assert pipe.get_metrics()["tts_pipeline_last_level_max"] == 1
        assert result.delivered is True
        assert result.mode is TTSDeliveryMode.SUBTITLE
        assert metrics.tts_snapshot()["subtitle_fallback_total"] == 1

    async def test_subtitle_sink_receives_text(self) -> None:
        seen = []
        subtitle = SubtitleFallbackService(on_subtitle=lambda rid, txt: seen.append((rid, txt)))
        metrics = MetricsCollector()
        fb = FallbackManager()
        backend = FakePlayerBackend()
        player = AudioPlayer(sample_rate=24000, backend=backend)
        primary = FakeTTS(raise_on_call=1)
        pipe = TTSPipeline(
            primary=primary, subtitle=subtitle, player=player, fallback=fb,
            timeout_primary_s=1.0, timeout_subtitle_s=0.5, metrics=metrics,
        )
        await player.start()
        try:
            await pipe.speak("r1", "hello")
        finally:
            await player.stop()
        # 1 câu duy nhất, subtitle nhận được
        assert len(seen) == 1
        assert seen[0][1] == "hello"


class TestEdges:
    def _blocking_pipeline(self):
        class BlockingPrimary(FakeTTS):
            def __init__(self) -> None:
                super().__init__(chunks_per_sentence=1, chunk_delay_s=0)
                self.entered = asyncio.Event()
                self.release = asyncio.Event()
                self.requests = []

            async def synthesize_stream(self, request):
                self.requests.append(request.request_id)
                self.entered.set()
                await self.release.wait()
                async for item in super().synthesize_stream(request):
                    yield item

            async def cancel(self, request_id):
                await super().cancel(request_id)
                self.release.set()

        primary = BlockingPrimary()
        pipe, _, player, _, _ = make_pipeline(primary=primary, chunk_delay=0)
        return pipe, primary, player

    @pytest.mark.parametrize("operation", ["cancel_b", "cancel_all", "cancel_task_b"])
    async def test_cancellation_owns_queued_invocations_before_the_speech_lock(
        self, operation: str,
    ) -> None:
        pipe, primary, player = self._blocking_pipeline()
        tasks = []
        await player.start()
        try:
            task_a = asyncio.create_task(pipe.speak("a", "Lượt A."))
            tasks.append(task_a)
            await asyncio.wait_for(primary.entered.wait(), timeout=1)
            task_b = asyncio.create_task(pipe.speak("b", "Lượt B không được phát."))
            tasks.append(task_b)
            await _wait(lambda: pipe.get_metrics()["tts_pipeline_pending_invocations"] == 2)
            assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 2
            assert primary.requests == ["a#0"]
            await pipe.cancel("unknown-request")
            assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 2
            assert primary.cancelled == set()

            if operation == "cancel_all":
                await pipe.cancel_all()
            elif operation == "cancel_task_b":
                task_b.cancel()
                with pytest.raises(asyncio.CancelledError):
                    await task_b
                assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 1
            else:
                await pipe.cancel("b")
                assert primary.cancelled == set(), "queued cancellation must not interrupt active A"

            primary.release.set()
            result_a = await asyncio.wait_for(task_a, timeout=2)
            if operation == "cancel_all":
                assert result_a.mode is TTSDeliveryMode.CANCELLED and not result_a.delivered
            else:
                assert result_a.delivered is True
            if operation != "cancel_task_b":
                result_b = await asyncio.wait_for(task_b, timeout=2)
                assert result_b.mode is TTSDeliveryMode.CANCELLED
                assert not result_b.delivered and result_b.sentences_delivered == 0
            assert primary.requests == ["a#0"], "queued cancelled B must never reach synthesis"
            assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 0
        finally:
            primary.release.set()
            await asyncio.gather(*tasks, return_exceptions=True)
            await player.stop()

    async def test_concurrent_duplicate_request_is_rejected_without_replacing_active_owner(self) -> None:
        pipe, primary, player = self._blocking_pipeline()
        task = None
        await player.start()
        try:
            task = asyncio.create_task(pipe.speak("same-id", "Lượt gốc."))
            await asyncio.wait_for(primary.entered.wait(), timeout=1)
            with pytest.raises(ValueError, match="already pending"):
                await pipe.speak("same-id", "Không được ghi đè lượt đang phát.")
            assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 1
            assert primary.requests == ["same-id#0"]
            primary.release.set()
            assert (await asyncio.wait_for(task, timeout=2)).delivered is True
            assert pipe.get_metrics()["tts_pipeline_pending_invocations"] == 0
        finally:
            primary.release.set()
            if task is not None:
                await asyncio.gather(task, return_exceptions=True)
            await player.stop()

    async def test_empty_text_noop(self) -> None:
        pipe, primary, player, _backend, _metrics = make_pipeline()
        await player.start()
        try:
            await pipe.speak("r1", "   \n  ")
        finally:
            await player.stop()
        assert primary.calls == 0
        assert pipe.get_metrics()["tts_pipeline_sentences_total"] == 0

    async def test_audio_and_subtitle_failure_is_not_delivered(self) -> None:
        primary = FakeTTS(raise_on_call=1)
        subtitle = SubtitleFallbackService(require_delivery=True)
        player = AudioPlayer(sample_rate=24000, backend=FakePlayerBackend())
        pipe = TTSPipeline(
            primary=primary,
            subtitle=subtitle,
            player=player,
            fallback=FallbackManager(),
            timeout_primary_s=1.0,
            timeout_subtitle_s=0.5,
        )
        await player.start()
        try:
            result = await pipe.speak("r-fail", "không tới được output")
        finally:
            await player.stop()
        assert result.delivered is False
        assert result.mode is TTSDeliveryMode.NONE
        assert result.failed_sentences == 1

    async def test_mixed_audio_and_subtitle_counts_as_delivered(self) -> None:
        primary = FakeTTS(chunks_per_sentence=1, raise_on_call=2)
        subtitle = SubtitleFallbackService(on_subtitle=lambda _rid, _text: None)
        player = AudioPlayer(sample_rate=24000, backend=FakePlayerBackend())
        pipe = TTSPipeline(
            primary=primary,
            subtitle=subtitle,
            player=player,
            fallback=FallbackManager(),
            timeout_primary_s=1.0,
            timeout_subtitle_s=0.5,
        )
        await player.start()
        try:
            result = await pipe.speak("r-mixed", "câu một. câu hai.")
        finally:
            await player.stop()
        assert result.delivered is True
        assert result.mode is TTSDeliveryMode.MIXED
        assert result.audio_sentences == 1
        assert result.subtitle_sentences == 1

    async def test_cancel_stops_pipeline(self) -> None:
        # 3 câu, cancel giữa
        pipe, primary, player, _backend, _m = make_pipeline(chunk_delay=0.03)
        await player.start()
        try:
            task = asyncio.create_task(pipe.speak("r1", "một. hai. ba."))
            await asyncio.sleep(0.02)   # để bắt đầu câu 1
            await pipe.cancel("r1")
            await asyncio.wait_for(task, timeout=2.0)
        finally:
            await player.stop()
        # ít nhất 1 câu bắt đầu; ít hơn 3 câu xong nếu cancel kịp
        assert primary.calls <= 3

    async def test_cancel_all_uses_active_turn_id_and_cancels_sentence_synthesis(self) -> None:
        pipe, primary, player, _backend, _m = make_pipeline(chunk_delay=0.03)
        await player.start()
        try:
            task = asyncio.create_task(pipe.speak("r-live", "mot. hai. ba."))
            await asyncio.sleep(0.02)
            await pipe.cancel_all()
            result = await asyncio.wait_for(task, timeout=2.0)
            await asyncio.sleep(0)
        finally:
            await player.stop()
        assert "r-live#0" in primary.cancelled
        assert player.get_metrics()["audio_queue_size"] == 0
        assert result.delivered is False
        assert result.mode is TTSDeliveryMode.CANCELLED


class _RealtimeBackend:
    """Blocks for each chunk's real duration like a device write; cancellable."""

    def __init__(self, *, stuck: bool = False) -> None:
        self.played_s = 0.0
        self._stuck = stuck

    def play_cancellable(self, samples, sample_rate, cancelled) -> bool:
        duration = 10.0 if self._stuck else len(samples) / sample_rate
        started = time.perf_counter()
        while time.perf_counter() - started < duration:
            if cancelled.is_set():
                self.played_s += time.perf_counter() - started
                return False
            time.sleep(0.005)
        self.played_s += duration
        return True

    def play_blocking(self, samples, sample_rate) -> None:
        self.play_cancellable(samples, sample_rate, threading.Event())

    def stop(self) -> None:
        pass


class _BudgetPrimary:
    """Synthesizes far faster than real time; optionally stalls after the first chunk."""

    service_id = "tts_budget_fake"
    sample_rate = 1000

    def __init__(self, *, chunks: int, chunk_s: float, stall_s: float = 0.0,
                 drain_s: float = 0.0, events: list[str] | None = None) -> None:
        self.chunks = chunks
        self.chunk_s = chunk_s
        self.stall_s = stall_s
        self.drain_s = drain_s
        self.events = events if events is not None else []

    def _chunk(self, request: TTSRequest, index: int) -> AudioChunk:
        samples = int(self.sample_rate * self.chunk_s)
        return AudioChunk(
            request_id=request.request_id, chunk_index=index,
            audio_bytes=np.zeros(samples, dtype=np.float32).tobytes(),
            is_final=False, duration_ms=int(1000 * self.chunk_s),
        )

    async def synthesize_stream(self, request: TTSRequest) -> AsyncIterator[AudioChunk]:
        try:
            for index in range(self.chunks):
                await asyncio.sleep(0.005)
                yield self._chunk(request, index)
                if self.stall_s:
                    await asyncio.sleep(self.stall_s)  # inference stalls mid-phrase
            yield AudioChunk(
                request_id=request.request_id, chunk_index=self.chunks,
                audio_bytes=b"", is_final=True, duration_ms=0,
            )
        finally:
            if self.drain_s:
                # Mirrors VieNeu: iterator cleanup waits for the producer thread.
                self.events.append("producer_drain_started")
                await asyncio.sleep(self.drain_s)
                self.events.append("producer_drain_finished")

    async def cancel(self, request_id: str) -> None:
        return None


class _RecordingPlayer(AudioPlayer):
    def __init__(self, events: list[str], **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.events = events

    async def cancel_current(self, request_id: str) -> None:
        self.events.append("player_cancel_current")
        await super().cancel_current(request_id)


class TestPrimaryBudgets:
    """Synthesis budget and playback budget are separate; neither is unbounded."""

    async def _speak(self, primary: _BudgetPrimary, backend: _RealtimeBackend, *,
                     events: list[str] | None = None, timeout_primary_s: float,
                     playback_margin_s: float):
        seen: list[str] = []
        player = _RecordingPlayer(
            events if events is not None else [], sample_rate=primary.sample_rate,
            backend=backend,
        )
        pipe = TTSPipeline(
            primary=primary,
            subtitle=SubtitleFallbackService(
                on_subtitle=lambda _rid, text: seen.append(text), require_delivery=True,
            ),
            player=player, fallback=FallbackManager(),
            timeout_primary_s=timeout_primary_s, timeout_subtitle_s=0.5,
            playback_margin_s=playback_margin_s,
        )
        await player.start()
        started = time.perf_counter()
        try:
            result = await pipe.speak("budget", "Một câu cần kiểm tra budget.")
        finally:
            elapsed = time.perf_counter() - started
            await player.stop()
        return result, pipe.get_metrics(), seen, elapsed

    async def test_playback_longer_than_synthesis_budget_is_still_audio(self) -> None:
        # 1.0 s of audio, synthesized in ~20 ms; the synthesis budget is only 0.3 s.
        backend = _RealtimeBackend()
        result, metrics, seen, _ = await self._speak(
            _BudgetPrimary(chunks=4, chunk_s=0.25), backend,
            timeout_primary_s=0.3, playback_margin_s=0.5,
        )
        assert result.mode is TTSDeliveryMode.AUDIO
        assert result.delivered is True
        assert result.audio_sentences == 1 and result.subtitle_sentences == 0
        assert seen == []
        assert backend.played_s == pytest.approx(1.0, abs=0.05), "audio must not be cut"
        assert metrics["tts_pipeline_synthesis_timeouts_total"] == 0
        assert metrics["tts_pipeline_playback_timeouts_total"] == 0

    async def test_real_synthesis_timeout_silences_player_before_producer_drain(self) -> None:
        events: list[str] = []
        backend = _RealtimeBackend()
        primary = _BudgetPrimary(
            chunks=2, chunk_s=0.5, stall_s=5.0, drain_s=0.2, events=events,
        )
        result, metrics, seen, elapsed = await self._speak(
            primary, backend, events=events, timeout_primary_s=0.2, playback_margin_s=0.5,
        )
        assert result.mode is TTSDeliveryMode.SUBTITLE
        assert result.delivered is True
        assert seen == ["Một câu cần kiểm tra budget."]
        assert metrics["tts_pipeline_synthesis_timeouts_total"] == 1
        assert metrics["tts_pipeline_playback_timeouts_total"] == 0
        assert events[0] == "player_cancel_current", events
        assert events.index("player_cancel_current") < events.index("producer_drain_started")
        assert "producer_drain_finished" in events
        assert backend.played_s < 0.4, "stale audio kept playing during the producer drain"
        assert elapsed < 2.0

    async def test_unconfirmed_playback_is_bounded_by_duration_plus_margin(self) -> None:
        events: list[str] = []
        backend = _RealtimeBackend(stuck=True)
        result, metrics, seen, elapsed = await self._speak(
            _BudgetPrimary(chunks=1, chunk_s=0.1), backend, events=events,
            timeout_primary_s=1.0, playback_margin_s=0.2,
        )
        assert result.mode is TTSDeliveryMode.SUBTITLE
        assert result.delivered is True
        assert seen == ["Một câu cần kiểm tra budget."]
        assert metrics["tts_pipeline_playback_timeouts_total"] == 1
        assert metrics["tts_pipeline_synthesis_timeouts_total"] == 0
        assert "player_cancel_current" in events
        assert elapsed < 2.0, "playback wait must stop at duration + margin (0.3 s)"

    @pytest.mark.parametrize("value", [0, -1.0, float("inf"), float("nan"), True])
    def test_budgets_must_be_finite_and_positive(self, value: float) -> None:
        with pytest.raises(ValueError):
            TTSPipeline(None, None, None, FallbackManager(), playback_margin_s=value)
        with pytest.raises(ValueError):
            TTSPipeline(None, None, None, FallbackManager(), timeout_primary_s=value)
