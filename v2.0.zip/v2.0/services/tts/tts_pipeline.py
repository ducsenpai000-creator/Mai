"""TTSPipeline — text → sentence split → TTS chain → AudioPlayer (Phase 4 4.E).

Ghép 4.B/4.C/4.D + FallbackManager (0.D) thành pipeline hoàn chỉnh:

  text
    → split_vn → list[sentence]
    → cho từng câu: FallbackManager.execute("tts", TTSRequest)
         Level 0: VieNeuTtsService.synthesize_stream (primary) — synthesis bounded by
                  timeout_primary_s, playback receipts bounded by audio duration + margin
         Level 1: SubtitleFallbackService.synthesize_stream (subtitle overlay)
       forward AudioChunk → AudioPlayer.enqueue (no-overlap)
    → đo TTFA end-to-end (từ speak() gọi tới AudioChunk đầu tiên non-empty)

N7 fail-safe: primary lỗi → fallback qua chain; sentence này lỗi hết chain → skip,
tiếp câu sau (không giết cả turn). Cancel qua flag + audio_player.cancel_current.
"""
from __future__ import annotations

import asyncio
import math
import time
from typing import Any, AsyncIterator

from interfaces.base import HealthStatus
from interfaces.tts import (
    AudioChunk,
    TTSDeliveryMode,
    TTSDeliveryResult,
    TTSRequest,
    PlaybackReceipt,
)
from orchestrator.fallback_manager import FallbackManager
from orchestrator.logger import get_logger
from services.tts.sentence_splitter import split_vn

_CHAIN_ID = "tts"


async def _close_stream(stream: AsyncIterator[AudioChunk]) -> None:
    """Close async generators without requiring aclose on the service contract."""
    close = getattr(stream, "aclose", None)
    if callable(close):
        await close()


def _receipt_confirmed(receipt: PlaybackReceipt) -> bool:
    return receipt.done() and not receipt.cancelled() and receipt.exception() is None and receipt.result() is True


class TTSPipeline:
    def __init__(
        self,
        primary,                    # TTSService | None (VieNeuTtsService)
        subtitle,                   # TTSService | None (SubtitleFallbackService)
        player,                     # AudioPlayer | None
        fallback: FallbackManager,
        # Bounds synthesis + enqueue of one phrase only. Playback is bounded separately
        # by the phrase's audio duration + playback_margin_s, so long speech is not cut
        # off and demoted to subtitle merely because it plays longer than synthesis.
        timeout_primary_s: float = 15.0,
        timeout_subtitle_s: float = 0.5,
        metrics: Any = None,
        phrase_max_chars: int = 200,
        phrase_max_sentences: int = 2,
        playback_margin_s: float = 3.0,
    ) -> None:
        self._primary = primary
        self._subtitle = subtitle
        self._player = player
        self._fb = fallback
        self._metrics = metrics
        if phrase_max_chars < 1 or phrase_max_sentences < 1:
            raise ValueError("invalid phrase bounds")
        for name, value in (
            ("timeout_primary_s", timeout_primary_s),
            ("playback_margin_s", playback_margin_s),
        ):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        self._timeout_primary_s = float(timeout_primary_s)
        self._playback_margin_s = float(playback_margin_s)
        self._synthesis_timeouts_total = 0
        self._playback_timeouts_total = 0
        self._phrase_max_chars = phrase_max_chars
        self._phrase_max_sentences = phrase_max_sentences
        self._phrase_enabled = False
        self._phrases_total = 0
        self._merged_sentences_total = 0
        self._active_subrequest: str | None = None
        self._subtitle_text = ""
        self._log = get_logger("tts_pipeline")

        self._invocations: dict[str, asyncio.Event] = {}
        self._active_request_id: str | None = None

        self._requests_total = 0
        self._sentences_total = 0
        self._last_ttfa_ms: float | None = None
        self._last_level_max = 0     # tầng fallback cao nhất đã dùng trong turn cuối
        self._last_delivery = TTSDeliveryResult(request_id="")
        self._delivery_counts: dict[str, int] = {}
        # State cho đo TTFA đúng chỗ: mark khi chunk audio ĐẦU TIÊN được enqueue
        self._speak_t0: float | None = None
        self._speak_first_marked: bool = False
        # Serialize speak() calls — viXTTS model KHÔNG thread-safe cho concurrent
        # inference. Lock lazy tạo trong event loop (asyncio.Lock() cần loop từ 3.10-).
        self._speak_lock: asyncio.Lock | None = None
        self._fb.register_chain(
            _CHAIN_ID,
            [self._synth_primary, self._synth_subtitle],
            # Primary bounds its own synthesis and playback phases (see _synth_primary);
            # an outer fixed timeout would again cap playback at the synthesis budget.
            [None, timeout_subtitle_s],
        )

    @classmethod
    def from_loader(cls, loader, primary, subtitle, player, fallback, metrics=None) -> "TTSPipeline":
        return cls(
            primary, subtitle, player, fallback,
            timeout_primary_s=float(loader.get("models", "tts.timeout_primary_s", 15.0)),
            timeout_subtitle_s=float(loader.get("models", "tts.timeout_subtitle_s", 0.5)),
            metrics=metrics,
            phrase_max_chars=int(loader.get("models", "tts.phrase_max_chars", 200)),
            phrase_max_sentences=int(loader.get("models", "tts.phrase_max_sentences", 2)),
            playback_margin_s=float(loader.get("models", "tts.playback_margin_s", 3.0)),
        )

    def set_enabled(self, enabled: bool) -> None:
        """Toggle phrase synthesis only; delivery verification is never optional."""
        self._phrase_enabled = enabled

    @property
    def enabled(self) -> bool:
        return self._phrase_enabled

    async def health_check(self) -> HealthStatus:
        """Report a usable delivery route, not just model availability."""
        if self._primary is not None and self._player is not None and getattr(self._player, "is_running", False):
            try:
                if (await self._primary.health_check()).is_ok:
                    return HealthStatus.healthy("tts", delivery_mode="audio")
            except Exception:
                pass
        if self._subtitle is not None:
            try:
                if (await self._subtitle.health_check()).is_ok:
                    return HealthStatus.healthy("tts", delivery_mode="subtitle", audio_available=False)
            except Exception:
                pass
        return HealthStatus.unhealthy("tts", "no healthy audio or subtitle delivery route")

    def _phrases(self, sentences: list[str]) -> list[tuple[str, int]]:
        groups: list[tuple[str, int]] = []
        for sentence in sentences:
            if self._phrase_enabled and groups:
                text, count = groups[-1]
                merged = text + " " + sentence
                if count < self._phrase_max_sentences and len(merged) <= self._phrase_max_chars:
                    groups[-1] = (merged, count + 1)
                    continue
            groups.append((sentence, 1))
        return groups

    # ---------- fallback level handlers ----------
    # Handler nhận request, tự stream + push chunk vào player, trả level marker.

    async def _synth_primary(self, request: TTSRequest) -> int:
        """Two bounded phases: synthesis/enqueue, then verified playback of that audio."""
        if self._primary is None:
            raise RuntimeError("TTS primary unavailable")
        if self._player is None:
            raise RuntimeError("audio player unavailable")
        # A watchdog, not asyncio.timeout: a deadline delivered as cancellation lands inside
        # the engine iterator, whose cleanup drains the producer thread before any outer
        # handler runs. Silence queued audio first, then cancel and await that drain.
        consumer = asyncio.ensure_future(
            self._stream_to_player(self._primary, request, enqueue_audio=True),
        )
        try:
            done, _pending = await asyncio.wait({consumer}, timeout=self._timeout_primary_s)
            if not done:
                self._synthesis_timeouts_total += 1
                raise TimeoutError("TTS synthesis exceeded its budget")
            first_chunk, receipts, audio_ms = consumer.result()
        except BaseException:
            if not consumer.done():
                await self._player.cancel_current(request.request_id)
                consumer.cancel()
                await asyncio.gather(consumer, return_exceptions=True)
            raise
        if first_chunk is None or not receipts:
            await self._player.cancel_current(request.request_id)
            raise RuntimeError("TTS produced no audio")
        await self._await_playback(request, receipts, audio_ms)
        return 0

    async def _await_playback(
        self, request: TTSRequest, receipts: list[PlaybackReceipt], audio_ms: int,
    ) -> None:
        # Playback already overlaps synthesis, so the full phrase duration measured
        # from the end of synthesis is an upper bound; the margin covers DSP/drain.
        budget_s = audio_ms / 1000.0 + self._playback_margin_s
        try:
            _done, pending = await asyncio.wait(receipts, timeout=budget_s)
        except BaseException:
            await self._player.cancel_current(request.request_id)
            raise
        if pending:
            self._playback_timeouts_total += 1
            await self._player.cancel_current(request.request_id)
            raise TimeoutError("audio playback exceeded its duration budget")
        if not all(_receipt_confirmed(receipt) for receipt in receipts):
            await self._player.cancel_current(request.request_id)
            raise RuntimeError("audio playback did not complete")

    async def _synth_subtitle(self, request: TTSRequest) -> int:
        if self._subtitle is None:
            raise RuntimeError("subtitle fallback unavailable")
        if self._is_cancelled(self._active_request_id):
            raise RuntimeError("speech cancelled before subtitle delivery")
        # Latest-text overlays replace their contents. Retain every subtitle-delivered
        # phrase of this speak() call, rather than acknowledging text overwritten
        # by the next phrase almost immediately. No cross-turn transcript cache.
        text = " ".join(part for part in (self._subtitle_text, request.text) if part)
        await self._stream_to_player(
            self._subtitle, request.model_copy(update={"text": text}), enqueue_audio=False,
        )
        self._subtitle_text = text
        return 1

    async def _stream_to_player(
        self,
        svc,
        request: TTSRequest,
        *,
        enqueue_audio: bool,
    ) -> tuple[AudioChunk | None, list[PlaybackReceipt], int]:
        first_chunk: AudioChunk | None = None
        receipts: list[PlaybackReceipt] = []
        audio_ms = 0
        stream = svc.synthesize_stream(request)
        try:
            async for chunk in stream:
                if self._is_cancelled(self._active_request_id):
                    await svc.cancel(request.request_id)
                    raise RuntimeError("speech cancelled before delivery")
                if chunk.audio_bytes and first_chunk is None:
                    first_chunk = chunk
                if enqueue_audio:
                    receipt = await self._player.enqueue(chunk)
                    if not isinstance(receipt, asyncio.Future):
                        raise RuntimeError("audio sink did not return a playback receipt")
                    receipts.append(receipt)
                    if chunk.audio_bytes:
                        audio_ms += max(0, int(chunk.duration_ms))
                if chunk.audio_bytes and not self._speak_first_marked and self._speak_t0 is not None:
                    self._speak_first_marked = True
                    self._last_ttfa_ms = (time.perf_counter() - self._speak_t0) * 1000
        except BaseException:
            if enqueue_audio:
                # Silence first: closing the iterator may wait for a running inference
                # thread to drain, and queued audio must not keep playing meanwhile.
                await self._player.cancel_current(request.request_id)
            raise
        finally:
            await _close_stream(stream)
        return first_chunk, receipts, audio_ms

    # ---------- public ----------

    async def speak(self, request_id: str, text: str) -> TTSDeliveryResult:
        """Return only after verified audio playback or successful subtitle delivery.

        TTFA đo từ lúc gọi speak() tới khi chunk audio đầu tiên non-empty được
        enqueue vào player. Metric ghi vào self._last_ttfa_ms.
        """
        if self._speak_lock is None:
            self._speak_lock = asyncio.Lock()
        if request_id in self._invocations:
            raise ValueError("speech request already pending")
        cancelled = asyncio.Event()
        # Register before the lock: queued speech already belongs to cancel/cancel_all.
        self._invocations[request_id] = cancelled
        try:
            async with self._speak_lock:
                self._active_request_id = request_id
                self._subtitle_text = ""
                try:
                    return await self._speak_locked(request_id, text)
                finally:
                    self._active_request_id = None
                    self._active_subrequest = None
                    self._subtitle_text = ""
        finally:
            if self._invocations.get(request_id) is cancelled:
                del self._invocations[request_id]

    def _is_cancelled(self, request_id: str | None) -> bool:
        token = self._invocations.get(request_id) if request_id is not None else None
        return token is not None and token.is_set()

    async def _speak_locked(self, request_id: str, text: str) -> TTSDeliveryResult:
        self._requests_total += 1
        sentences = split_vn(text)
        if self._is_cancelled(request_id):
            return self._finish_delivery(TTSDeliveryResult(
                request_id=request_id, mode=TTSDeliveryMode.CANCELLED,
                sentences_total=len(sentences), cancelled=True,
            ))
        if not sentences:
            return self._finish_delivery(TTSDeliveryResult(request_id=request_id))

        # Reset state cho lượt speak này. TTFA sẽ được mark trong _stream_to_player
        # ngay khi chunk audio đầu tiên được enqueue (chứ KHÔNG phải khi cả câu xong).
        self._speak_t0 = time.perf_counter()
        self._speak_first_marked = False
        self._last_ttfa_ms = None
        max_level = 0
        audio_sentences = 0
        subtitle_sentences = 0
        failed_sentences = 0

        for idx, (sent, count) in enumerate(self._phrases(sentences)):
            if self._is_cancelled(request_id):
                break
            req = TTSRequest(request_id=f"{request_id}#{idx}", text=sent)
            self._active_subrequest = req.request_id
            self._phrases_total += 1
            self._merged_sentences_total += count - 1
            try:
                result = await self._fb.execute(_CHAIN_ID, req)
                max_level = max(max_level, result.level_used)
            except Exception as e:
                self._log.warning("tts_sentence_failed", request_id=request_id, idx=idx, error=type(e).__name__)
                failed_sentences += count
                continue
            if result.level_used == 0:
                audio_sentences += count
            else:
                subtitle_sentences += count
            self._sentences_total += count

        self._last_level_max = max_level
        self._record_metrics(max_level)
        cancelled = self._is_cancelled(request_id)
        delivered_sentences = audio_sentences + subtitle_sentences
        if cancelled:
            mode = TTSDeliveryMode.CANCELLED
        elif audio_sentences and subtitle_sentences:
            mode = TTSDeliveryMode.MIXED
        elif audio_sentences:
            mode = TTSDeliveryMode.AUDIO
        elif subtitle_sentences:
            mode = TTSDeliveryMode.SUBTITLE
        else:
            mode = TTSDeliveryMode.NONE
        result = TTSDeliveryResult(
            request_id=request_id,
            delivered=(
                not cancelled
                and failed_sentences == 0
                and delivered_sentences == len(sentences)
            ),
            mode=mode,
            sentences_total=len(sentences),
            sentences_delivered=delivered_sentences,
            audio_sentences=audio_sentences,
            subtitle_sentences=subtitle_sentences,
            failed_sentences=failed_sentences,
            cancelled=cancelled,
        )
        return self._finish_delivery(result)

    async def cancel(self, request_id: str) -> None:
        token = self._invocations.get(request_id)
        if token is None:
            return
        token.set()
        if self._active_request_id != request_id:
            return
        subrequest_id = self._active_subrequest or request_id
        # Only the current phrase can own queued audio; previous receipts drained.
        if self._player is not None:
            if self._active_subrequest is not None:
                await self._player.cancel_current(subrequest_id)
        for service in (self._primary, self._subtitle):
            if service is not None:
                try:
                    await service.cancel(subrequest_id)
                except Exception as exc:
                    self._log.warning("tts_cancel_failed", error=type(exc).__name__)

    async def cancel_all(self) -> None:
        """Cancel synthesis/playback without stopping the reusable services."""
        for token in self._invocations.values():
            token.set()
        request_id = self._active_request_id
        try:
            if request_id is not None:
                await self.cancel(request_id)
            if self._player is not None and hasattr(self._player, "cancel_all"):
                await self._player.cancel_all()
        finally:
            clear_subtitle = getattr(self._subtitle, "cancel_all", None)
            if callable(clear_subtitle):
                await clear_subtitle()

    def get_metrics(self) -> dict[str, Any]:
        return {
            "tts_pipeline_requests_total": self._requests_total,
            "tts_pipeline_pending_invocations": len(self._invocations),
            "tts_phrase_synthesis_enabled": self._phrase_enabled,
            "tts_pipeline_phrases_total": self._phrases_total,
            "tts_pipeline_merged_sentences_total": self._merged_sentences_total,
            "tts_pipeline_sentences_total": self._sentences_total,
            "tts_pipeline_last_ttfa_ms": self._last_ttfa_ms,
            "tts_pipeline_last_level_max": self._last_level_max,
            "tts_pipeline_synthesis_timeouts_total": self._synthesis_timeouts_total,
            "tts_pipeline_playback_timeouts_total": self._playback_timeouts_total,
            "tts_pipeline_last_delivery_mode": self._last_delivery.mode.value,
            "tts_pipeline_last_delivery_success": self._last_delivery.delivered,
            **{
                f"tts_pipeline_delivery_{mode}_total": count
                for mode, count in sorted(self._delivery_counts.items())
            },
        }

    def _finish_delivery(self, result: TTSDeliveryResult) -> TTSDeliveryResult:
        self._last_delivery = result
        mode = result.mode.value
        self._delivery_counts[mode] = self._delivery_counts.get(mode, 0) + 1
        return result

    def _record_metrics(self, level_used: int) -> None:
        if self._metrics is None:
            return
        rec = getattr(self._metrics, "record_tts_turn", None)
        if callable(rec):
            rec(ttfa_ms=self._last_ttfa_ms, level_used=level_used)
